#include "petzval.h"
#include "ui_petzval.h"
#include <iostream>
#include <cmath>
#include <fstream>
#include <iomanip>
#include <string>
#include <sstream>
#include <QFile>
#include <QMessageBox>

using namespace std;
QVector<double> radius1(1), radius2(1), radius3(1), focal(1), diameter(1), thick1(1), thick2(1), SB1(1), SB2(1), SB3(1), SC1(1), SC2(1), SC3(1);
QVector<string> supplier(1), product(1), Glass1(1), Glass2(1), SGlass(1);
int llines=0;

Petzval::Petzval(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Petzval)
{
    ui->setupUi(this);
    this->setWindowTitle("Petzval Tool");

    ui->lineEdit->setText("LensData.slib");
    ui->lineEdit_4->setText("GlassData.slib");

    ui->doubleSpinBox->setValue(20.0);
    ui->doubleSpinBox_2->setValue(130.0);
    ui->doubleSpinBox_3->setValue(10.0);
    ui->doubleSpinBox_4->setValue(40.0);
    ui->doubleSpinBox_5->setValue(50.0);
    ui->doubleSpinBox_6->setValue(75.0);

    ui->customPlot->axisRect()->setupFullAxesBox(true);

}

Petzval::~Petzval()
{
    delete ui;
}

void Petzval::seData(QString str)
{
    ui->lineEdit_2->setText(str);
}
void Petzval::loadDatabase(){

    QString qLib = ui->lineEdit_2->text()+"/"+ui->lineEdit->text();
    string sbin = qLib.toUtf8().constData();
    ifstream lenses(sbin.c_str());

    QFile qBin(qLib);

    if(!qBin.exists()){
        QMessageBox::information(this, "Error", "Lens database "+qLib+" not present.");
        return;
    }

    else{
        llines=0;
        string zeile1, eins, zwei, drei, vier, fuenf, sechs, sieben, acht, neun, zehn, elf;

        while(std::getline(lenses, zeile1))
        ++ llines;

        lenses.clear();
        lenses.seekg(0, ios::beg);

        radius1.resize(llines);
        radius2.resize(llines);
        radius3.resize(llines);
        focal.resize(llines);
        diameter.resize(llines);
        thick1.resize(llines);
        thick2.resize(llines);
        supplier.resize(llines);
        product.resize(llines);
        Glass1.resize(llines);
        Glass2.resize(llines);

        for(int i=0; i < llines; i++){
            lenses >> eins >> zwei >> drei >> vier >> fuenf >> sechs >> sieben >> acht >> neun >> zehn >> elf;
            istringstream str1(eins);
            str1 >> supplier[i];
            istringstream str2(zwei);
            str2 >> product[i];
            istringstream str3(drei);
            str3 >> diameter[i];
            istringstream str4(vier);
            str4 >> focal[i];
            istringstream str5(fuenf);
            str5 >> radius1[i];
            istringstream str6(sechs);
            str6 >> radius2[i];
            istringstream str7(sieben);
            str7 >> radius3[i];
            istringstream str8(acht);
            str8 >> thick1[i];
            istringstream str9(neun);
            str9 >> thick2[i];
            istringstream str10(zehn);
            str10 >> Glass1[i];
            istringstream str11(elf);
            str11 >> Glass2[i];
        }


    }
}

// load catalog
void Petzval::on_pushButton_3_clicked()
{
    Petzval::loadDatabase();
}

// search combinations
void Petzval::on_pushButton_clicked()
{
    Petzval::loadDatabase();

    ui->comboBox->clear();
    double diam = ui->doubleSpinBox->value();
    double foc = ui->doubleSpinBox_2->value();
    double focup = foc + ui->doubleSpinBox_3->value();
    double foclo = foc - ui->doubleSpinBox_3->value();
    double back = ui->doubleSpinBox_4->value();
    double d2max = ui->doubleSpinBox_5->value();
    double d1max = ui->doubleSpinBox_6->value();

    if(d1max < diam){
        QString Qdi = QString::number(diam);
        QString Qdi1 = QString::number(d1max);
        QMessageBox::information(this, "Warning", "Specified diameter of "+Qdi+" larger than allowed maximum "+Qdi1);
    }
    double tup, tlo, dup, dlo, F1, F2, H2up, H2lo, H1up, H1lo, backup;
    int cnum=0;

    for(int i =0; i<llines; i++){
        if((diameter[i]>= diam) & (diameter[i]<=d1max)){
            F1 = focal[i]/diam;
            for(int e =0; e<llines; e++){
                tup = focal[i]+focal[e]-focal[i]*focal[e]/focup;
                tlo = focal[i]+focal[e]-focal[i]*focal[e]/foclo;
                backup = (foclo-tlo)/(1-tlo/focal[e]);
                if(tup<focal[i] & (backup>=back) & (diameter[e]<d2max)){
                    dup = (focal[i]-tup)/F1;
                    dlo = (focal[i]-tlo)/F1;
                    H2up = -dup*focal[e]/(focal[i]+focal[e]-dup);
                    H2lo = -dlo*focal[e]/(focal[i]+focal[e]-dlo);
                    H1up = dup*focal[i]/(focal[i]+focal[e]-dup);
                    H1lo = dlo*focal[i]/(focal[i]+focal[e]-dlo);
                    if(dlo<=diameter[e]){
                        cout<<product[i]<<"\t\t"<<product[e]<<"\t"<<tup<<"\t"<<tlo<<"\t"<<dup<<"\t"<<dlo<<"\t"<<H1up<<"\t"<<H1lo<<"\t"<<H2up<<"\t"<<H2lo<<"\t"<<backup<<endl;
                        string pro1 = product[i];
                        string pro2 = product[e];
                        QString qstr = QString::fromStdString(pro1.c_str())+" & "+QString::fromStdString(pro2.c_str());
                        ui->comboBox->addItem(qstr);
                        ++cnum;
                    }
                    else{

                    }
                }
                else{

                }
            }
        }
        else{

        }
    }
    ui->lineEdit_3->setText(QString::number(cnum));

}

// Evaluate found combinations
void Petzval::on_pushButton_4_clicked()
{
    ofstream spot("spotdata.dat");
    double r1=50.0, r2=-150.0, t=10.0, d=25.0;
    QVector<double> radi(2), thi(2), ind(3), lambda(5);
    radi[0]=r1;
    radi[1]=r2;
    thi[0]=0;
    thi[1]=t;
    lambda[0]=0.4;
    lambda[1]=0.5;
    lambda[2]=0.6;
    lambda[3]=0.7;
    lambda[4]=0.8;

    double B1=1.34533359, B2=0.209073176, B3=0.937357162, C1=0.0099774387, C2=0.0470450767, C3=111.886764;

    double m=0.0, h1=24.0, alpha1=0, alpha2, a, b, c, h2, ang=0.0;
    double h;

    for(int e =0; e<5; e++){

        ind[0]=1.0;
        ind[1]=sqrt(1+B1*pow(lambda[e],2)/(pow(lambda[e],2)-C1)+B2*pow(lambda[e],2)/(pow(lambda[e],2)-C2)+B3*pow(lambda[e],2)/(pow(lambda[e],2)-C3));
        ind[2]=1.0;
        cout<<"ind: "<<ind[1]<<endl;

        for(int g=0; g<5; g++){
            h=h1/(g+1);
            m=0.0;
            ang=0.0;
            for(int i =0; i<radi.size(); i++){

                a = m*m+1;
                b = 2*h*m-2*radi[i]-2*thi[i];
                c = h*h+2*thi[i]*radi[i]-pow(thi[i],2);

                double x1=(-b+pow((b*b-4*a*c),0.5))/(2*a);
                double x2=(-b-pow((b*b-4*a*c),0.5))/(2*a);

                if(radi[i]>0){
                    if(x1<x2){
                        h2=m*x1+h;
                        spot<<x1<<"\t"<<h2<<endl;
                    }
                    else{
                        h2=m*x2+h;
                        spot<<x2<<"\t"<<h2<<endl;
                    }
                }
                else{
                    if(x1>x2){
                        h2=m*x1+h;
                        spot<<x1<<"\t"<<h2<<endl;
                    }
                    else{
                        h2 = m*x2+h;
                        spot<<x2<<"\t"<<h2<<endl;
                    }
                }

                alpha1 = abs(asin(h2/radi[i])*180/M_PI)+ang;
                alpha2 = asin(ind[i]*sin(alpha1/180*M_PI)/ind[i+1])*180/M_PI;

                m = tan((180+pow((-1),(2+i))*(alpha2-alpha1))/180*M_PI);
                ang=alpha1-alpha2;

                if(radi[i]>0){
                    if(x1<x2){
                        h=h2-m*x1;
                    }
                    else{
                        h=h2-m*x2;
                    }
                }
                else{
                    if(x1>x2){
                        h=h2-m*x1;
                    }
                    else{
                        h=h2-m*x2;
                    }
                }
                cout<<x1<<"\t"<<x2<<"\t"<<alpha1<<"\t"<<alpha2<<"\t"<<m<<"\t"<<h<<"\t"<<ang<<"\t"<<h2<<endl;
            }
            cout<<endl;
            spot<<50<<"\t"<<m*50+h<<endl;
        }
    }
}

// Load glass catalog
void Petzval::on_pushButton_5_clicked()
{
    QString qLib = ui->lineEdit_2->text()+"/"+ui->lineEdit_4->text();
    string sbin = qLib.toUtf8().constData();
    ifstream glass(sbin.c_str());

    QFile qBin(qLib);

    if(!qBin.exists()){
        QMessageBox::information(this, "Error", "Glass database "+qLib+" not present.");
        return;
    }

    else{
        llines=0;
        string zeile1, eins, zwei, drei, vier, fuenf, sechs, sieben;

        while(std::getline(glass, zeile1))
        ++ llines;

        glass.clear();
        glass.seekg(0, ios::beg);

        SB1.resize(llines);
        SB2.resize(llines);
        SB3.resize(llines);
        SC1.resize(llines);
        SC2.resize(llines);
        SC3.resize(llines);
        SGlass.resize(llines);

        for(int i=0; i < llines; i++){
            glass >> eins >> zwei >> drei >> vier >> fuenf >> sechs >> sieben;
            istringstream str1(eins);
            str1 >> SGlass[i];
            istringstream str2(zwei);
            str2 >> SB1[i];
            istringstream str3(drei);
            str3 >> SB2[i];
            istringstream str4(vier);
            str4 >> SB3[i];
            istringstream str5(fuenf);
            str5 >> SC1[i];
            istringstream str6(sechs);
            str6 >> SC2[i];
            istringstream str7(sieben);
            str7 >> SC3[i];
        }
    }
}
