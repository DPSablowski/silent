/****************************************************************************
** Meta object code from reading C++ file 'mainwindow.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.8.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "mainwindow.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mainwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.8.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_MainWindow_t {
    QByteArrayData data[96];
    char stringdata0[2504];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_MainWindow_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_MainWindow_t qt_meta_stringdata_MainWindow = {
    {
QT_MOC_LITERAL(0, 0, 10), // "MainWindow"
QT_MOC_LITERAL(1, 11, 25), // "on_spinBox_4_valueChanged"
QT_MOC_LITERAL(2, 37, 0), // ""
QT_MOC_LITERAL(3, 38, 28), // "on_actionClassical_triggered"
QT_MOC_LITERAL(4, 67, 23), // "on_pushButton_2_clicked"
QT_MOC_LITERAL(5, 91, 31), // "on_doubleSpinBox_4_valueChanged"
QT_MOC_LITERAL(6, 123, 31), // "on_doubleSpinBox_3_valueChanged"
QT_MOC_LITERAL(7, 155, 21), // "on_checkBox_8_clicked"
QT_MOC_LITERAL(8, 177, 21), // "on_checkBox_9_clicked"
QT_MOC_LITERAL(9, 199, 19), // "on_checkBox_clicked"
QT_MOC_LITERAL(10, 219, 23), // "on_pushButton_3_clicked"
QT_MOC_LITERAL(11, 243, 8), // "overview"
QT_MOC_LITERAL(12, 252, 9), // "revectors"
QT_MOC_LITERAL(13, 262, 11), // "Echellogram"
QT_MOC_LITERAL(14, 274, 10), // "parameters"
QT_MOC_LITERAL(15, 285, 29), // "on_doubleSpinBox_valueChanged"
QT_MOC_LITERAL(16, 315, 31), // "on_doubleSpinBox_2_valueChanged"
QT_MOC_LITERAL(17, 347, 23), // "on_pushButton_4_clicked"
QT_MOC_LITERAL(18, 371, 25), // "on_spinBox_5_valueChanged"
QT_MOC_LITERAL(19, 397, 23), // "on_pushButton_5_clicked"
QT_MOC_LITERAL(20, 421, 23), // "on_pushButton_6_clicked"
QT_MOC_LITERAL(21, 445, 29), // "on_actionParameters_triggered"
QT_MOC_LITERAL(22, 475, 31), // "on_doubleSpinBox_5_valueChanged"
QT_MOC_LITERAL(23, 507, 31), // "on_doubleSpinBox_6_valueChanged"
QT_MOC_LITERAL(24, 539, 31), // "on_doubleSpinBox_8_valueChanged"
QT_MOC_LITERAL(25, 571, 31), // "on_doubleSpinBox_7_valueChanged"
QT_MOC_LITERAL(26, 603, 31), // "on_doubleSpinBox_9_valueChanged"
QT_MOC_LITERAL(27, 635, 32), // "on_doubleSpinBox_10_valueChanged"
QT_MOC_LITERAL(28, 668, 32), // "on_doubleSpinBox_12_valueChanged"
QT_MOC_LITERAL(29, 701, 32), // "on_doubleSpinBox_14_valueChanged"
QT_MOC_LITERAL(30, 734, 32), // "on_doubleSpinBox_15_valueChanged"
QT_MOC_LITERAL(31, 767, 32), // "on_doubleSpinBox_16_valueChanged"
QT_MOC_LITERAL(32, 800, 32), // "on_doubleSpinBox_17_valueChanged"
QT_MOC_LITERAL(33, 833, 25), // "on_spinBox_2_valueChanged"
QT_MOC_LITERAL(34, 859, 23), // "on_spinBox_valueChanged"
QT_MOC_LITERAL(35, 883, 25), // "on_spinBox_3_valueChanged"
QT_MOC_LITERAL(36, 909, 25), // "on_spinBox_7_valueChanged"
QT_MOC_LITERAL(37, 935, 25), // "on_spinBox_8_valueChanged"
QT_MOC_LITERAL(38, 961, 22), // "on_checkBox_11_clicked"
QT_MOC_LITERAL(39, 984, 25), // "on_spinBox_6_valueChanged"
QT_MOC_LITERAL(40, 1010, 32), // "on_doubleSpinBox_18_valueChanged"
QT_MOC_LITERAL(41, 1043, 32), // "on_doubleSpinBox_20_valueChanged"
QT_MOC_LITERAL(42, 1076, 32), // "on_doubleSpinBox_21_valueChanged"
QT_MOC_LITERAL(43, 1109, 30), // "on_actionClassical_2_triggered"
QT_MOC_LITERAL(44, 1140, 32), // "on_doubleSpinBox_22_valueChanged"
QT_MOC_LITERAL(45, 1173, 32), // "on_doubleSpinBox_23_valueChanged"
QT_MOC_LITERAL(46, 1206, 32), // "on_doubleSpinBox_24_valueChanged"
QT_MOC_LITERAL(47, 1239, 32), // "on_doubleSpinBox_25_valueChanged"
QT_MOC_LITERAL(48, 1272, 32), // "on_doubleSpinBox_27_valueChanged"
QT_MOC_LITERAL(49, 1305, 32), // "on_doubleSpinBox_28_valueChanged"
QT_MOC_LITERAL(50, 1338, 32), // "on_doubleSpinBox_29_valueChanged"
QT_MOC_LITERAL(51, 1371, 32), // "on_doubleSpinBox_26_valueChanged"
QT_MOC_LITERAL(52, 1404, 34), // "on_action3D_Spectrograph_trig..."
QT_MOC_LITERAL(53, 1439, 21), // "on_action3D_triggered"
QT_MOC_LITERAL(54, 1461, 27), // "on_action3D_Frame_triggered"
QT_MOC_LITERAL(55, 1489, 32), // "on_actionEchelle_Frame_triggered"
QT_MOC_LITERAL(56, 1522, 23), // "on_pushButton_7_clicked"
QT_MOC_LITERAL(57, 1546, 24), // "on_actionAbout_triggered"
QT_MOC_LITERAL(58, 1571, 29), // "on_actionBug_Report_triggered"
QT_MOC_LITERAL(59, 1601, 25), // "on_actionManual_triggered"
QT_MOC_LITERAL(60, 1627, 23), // "on_pushButton_8_clicked"
QT_MOC_LITERAL(61, 1651, 9), // "setvalues"
QT_MOC_LITERAL(62, 1661, 25), // "on_actionBasics_triggered"
QT_MOC_LITERAL(63, 1687, 23), // "on_actionVPHG_triggered"
QT_MOC_LITERAL(64, 1711, 33), // "on_actionOptical_Fibres_trigg..."
QT_MOC_LITERAL(65, 1745, 31), // "on_comboBox_currentIndexChanged"
QT_MOC_LITERAL(66, 1777, 33), // "on_comboBox_2_currentIndexCha..."
QT_MOC_LITERAL(67, 1811, 25), // "on_spinBox_9_valueChanged"
QT_MOC_LITERAL(68, 1837, 32), // "on_doubleSpinBox_33_valueChanged"
QT_MOC_LITERAL(69, 1870, 26), // "on_spinBox_10_valueChanged"
QT_MOC_LITERAL(70, 1897, 26), // "on_spinBox_11_valueChanged"
QT_MOC_LITERAL(71, 1924, 32), // "on_doubleSpinBox_35_valueChanged"
QT_MOC_LITERAL(72, 1957, 32), // "on_doubleSpinBox_34_valueChanged"
QT_MOC_LITERAL(73, 1990, 34), // "on_actionClassical_Frame_trig..."
QT_MOC_LITERAL(74, 2025, 22), // "on_actionTSI_triggered"
QT_MOC_LITERAL(75, 2048, 8), // "warning1"
QT_MOC_LITERAL(76, 2057, 24), // "on_actionNotes_triggered"
QT_MOC_LITERAL(77, 2082, 22), // "on_actionNew_triggered"
QT_MOC_LITERAL(78, 2105, 23), // "on_actionUndo_triggered"
QT_MOC_LITERAL(79, 2129, 23), // "on_actionOpen_triggered"
QT_MOC_LITERAL(80, 2153, 26), // "on_actionSave_AS_triggered"
QT_MOC_LITERAL(81, 2180, 23), // "on_actionSave_triggered"
QT_MOC_LITERAL(82, 2204, 16), // "showPointToolTip"
QT_MOC_LITERAL(83, 2221, 12), // "QMouseEvent*"
QT_MOC_LITERAL(84, 2234, 5), // "event"
QT_MOC_LITERAL(85, 2240, 18), // "showPointToolTip_2"
QT_MOC_LITERAL(86, 2259, 18), // "showPointToolTip_3"
QT_MOC_LITERAL(87, 2278, 18), // "showPointToolTip_4"
QT_MOC_LITERAL(88, 2297, 18), // "showPointToolTip_5"
QT_MOC_LITERAL(89, 2316, 22), // "on_actionFPE_triggered"
QT_MOC_LITERAL(90, 2339, 32), // "on_actionCzerny_Turner_triggered"
QT_MOC_LITERAL(91, 2372, 26), // "on_actionPetzval_triggered"
QT_MOC_LITERAL(92, 2399, 23), // "on_pushButton_9_clicked"
QT_MOC_LITERAL(93, 2423, 33), // "on_comboBox_4_currentIndexCha..."
QT_MOC_LITERAL(94, 2457, 24), // "on_pushButton_10_clicked"
QT_MOC_LITERAL(95, 2482, 21) // "on_checkBox_2_clicked"

    },
    "MainWindow\0on_spinBox_4_valueChanged\0"
    "\0on_actionClassical_triggered\0"
    "on_pushButton_2_clicked\0"
    "on_doubleSpinBox_4_valueChanged\0"
    "on_doubleSpinBox_3_valueChanged\0"
    "on_checkBox_8_clicked\0on_checkBox_9_clicked\0"
    "on_checkBox_clicked\0on_pushButton_3_clicked\0"
    "overview\0revectors\0Echellogram\0"
    "parameters\0on_doubleSpinBox_valueChanged\0"
    "on_doubleSpinBox_2_valueChanged\0"
    "on_pushButton_4_clicked\0"
    "on_spinBox_5_valueChanged\0"
    "on_pushButton_5_clicked\0on_pushButton_6_clicked\0"
    "on_actionParameters_triggered\0"
    "on_doubleSpinBox_5_valueChanged\0"
    "on_doubleSpinBox_6_valueChanged\0"
    "on_doubleSpinBox_8_valueChanged\0"
    "on_doubleSpinBox_7_valueChanged\0"
    "on_doubleSpinBox_9_valueChanged\0"
    "on_doubleSpinBox_10_valueChanged\0"
    "on_doubleSpinBox_12_valueChanged\0"
    "on_doubleSpinBox_14_valueChanged\0"
    "on_doubleSpinBox_15_valueChanged\0"
    "on_doubleSpinBox_16_valueChanged\0"
    "on_doubleSpinBox_17_valueChanged\0"
    "on_spinBox_2_valueChanged\0"
    "on_spinBox_valueChanged\0"
    "on_spinBox_3_valueChanged\0"
    "on_spinBox_7_valueChanged\0"
    "on_spinBox_8_valueChanged\0"
    "on_checkBox_11_clicked\0on_spinBox_6_valueChanged\0"
    "on_doubleSpinBox_18_valueChanged\0"
    "on_doubleSpinBox_20_valueChanged\0"
    "on_doubleSpinBox_21_valueChanged\0"
    "on_actionClassical_2_triggered\0"
    "on_doubleSpinBox_22_valueChanged\0"
    "on_doubleSpinBox_23_valueChanged\0"
    "on_doubleSpinBox_24_valueChanged\0"
    "on_doubleSpinBox_25_valueChanged\0"
    "on_doubleSpinBox_27_valueChanged\0"
    "on_doubleSpinBox_28_valueChanged\0"
    "on_doubleSpinBox_29_valueChanged\0"
    "on_doubleSpinBox_26_valueChanged\0"
    "on_action3D_Spectrograph_triggered\0"
    "on_action3D_triggered\0on_action3D_Frame_triggered\0"
    "on_actionEchelle_Frame_triggered\0"
    "on_pushButton_7_clicked\0"
    "on_actionAbout_triggered\0"
    "on_actionBug_Report_triggered\0"
    "on_actionManual_triggered\0"
    "on_pushButton_8_clicked\0setvalues\0"
    "on_actionBasics_triggered\0"
    "on_actionVPHG_triggered\0"
    "on_actionOptical_Fibres_triggered\0"
    "on_comboBox_currentIndexChanged\0"
    "on_comboBox_2_currentIndexChanged\0"
    "on_spinBox_9_valueChanged\0"
    "on_doubleSpinBox_33_valueChanged\0"
    "on_spinBox_10_valueChanged\0"
    "on_spinBox_11_valueChanged\0"
    "on_doubleSpinBox_35_valueChanged\0"
    "on_doubleSpinBox_34_valueChanged\0"
    "on_actionClassical_Frame_triggered\0"
    "on_actionTSI_triggered\0warning1\0"
    "on_actionNotes_triggered\0"
    "on_actionNew_triggered\0on_actionUndo_triggered\0"
    "on_actionOpen_triggered\0"
    "on_actionSave_AS_triggered\0"
    "on_actionSave_triggered\0showPointToolTip\0"
    "QMouseEvent*\0event\0showPointToolTip_2\0"
    "showPointToolTip_3\0showPointToolTip_4\0"
    "showPointToolTip_5\0on_actionFPE_triggered\0"
    "on_actionCzerny_Turner_triggered\0"
    "on_actionPetzval_triggered\0"
    "on_pushButton_9_clicked\0"
    "on_comboBox_4_currentIndexChanged\0"
    "on_pushButton_10_clicked\0on_checkBox_2_clicked"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_MainWindow[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      92,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,  474,    2, 0x08 /* Private */,
       3,    0,  475,    2, 0x08 /* Private */,
       4,    0,  476,    2, 0x08 /* Private */,
       5,    0,  477,    2, 0x08 /* Private */,
       6,    0,  478,    2, 0x08 /* Private */,
       7,    0,  479,    2, 0x08 /* Private */,
       8,    0,  480,    2, 0x08 /* Private */,
       9,    0,  481,    2, 0x08 /* Private */,
      10,    0,  482,    2, 0x08 /* Private */,
      11,    0,  483,    2, 0x08 /* Private */,
      12,    0,  484,    2, 0x08 /* Private */,
      13,    0,  485,    2, 0x08 /* Private */,
      14,    0,  486,    2, 0x08 /* Private */,
      15,    0,  487,    2, 0x08 /* Private */,
      16,    0,  488,    2, 0x08 /* Private */,
      17,    0,  489,    2, 0x08 /* Private */,
      18,    0,  490,    2, 0x08 /* Private */,
      19,    0,  491,    2, 0x08 /* Private */,
      20,    0,  492,    2, 0x08 /* Private */,
      21,    0,  493,    2, 0x08 /* Private */,
      22,    0,  494,    2, 0x08 /* Private */,
      23,    0,  495,    2, 0x08 /* Private */,
      24,    0,  496,    2, 0x08 /* Private */,
      25,    0,  497,    2, 0x08 /* Private */,
      26,    0,  498,    2, 0x08 /* Private */,
      27,    0,  499,    2, 0x08 /* Private */,
      28,    0,  500,    2, 0x08 /* Private */,
      29,    0,  501,    2, 0x08 /* Private */,
      30,    0,  502,    2, 0x08 /* Private */,
      31,    0,  503,    2, 0x08 /* Private */,
      32,    0,  504,    2, 0x08 /* Private */,
      33,    0,  505,    2, 0x08 /* Private */,
      34,    0,  506,    2, 0x08 /* Private */,
      35,    0,  507,    2, 0x08 /* Private */,
      36,    0,  508,    2, 0x08 /* Private */,
      37,    0,  509,    2, 0x08 /* Private */,
      38,    0,  510,    2, 0x08 /* Private */,
      39,    0,  511,    2, 0x08 /* Private */,
      40,    0,  512,    2, 0x08 /* Private */,
      41,    0,  513,    2, 0x08 /* Private */,
      42,    0,  514,    2, 0x08 /* Private */,
      43,    0,  515,    2, 0x08 /* Private */,
      44,    0,  516,    2, 0x08 /* Private */,
      45,    0,  517,    2, 0x08 /* Private */,
      46,    0,  518,    2, 0x08 /* Private */,
      47,    0,  519,    2, 0x08 /* Private */,
      48,    0,  520,    2, 0x08 /* Private */,
      49,    0,  521,    2, 0x08 /* Private */,
      50,    0,  522,    2, 0x08 /* Private */,
      51,    0,  523,    2, 0x08 /* Private */,
      52,    0,  524,    2, 0x08 /* Private */,
      53,    0,  525,    2, 0x08 /* Private */,
      54,    0,  526,    2, 0x08 /* Private */,
      55,    0,  527,    2, 0x08 /* Private */,
      56,    0,  528,    2, 0x08 /* Private */,
      57,    0,  529,    2, 0x08 /* Private */,
      58,    0,  530,    2, 0x08 /* Private */,
      59,    0,  531,    2, 0x08 /* Private */,
      60,    0,  532,    2, 0x08 /* Private */,
      61,    0,  533,    2, 0x08 /* Private */,
      62,    0,  534,    2, 0x08 /* Private */,
      63,    0,  535,    2, 0x08 /* Private */,
      64,    0,  536,    2, 0x08 /* Private */,
      65,    0,  537,    2, 0x08 /* Private */,
      66,    0,  538,    2, 0x08 /* Private */,
      67,    0,  539,    2, 0x08 /* Private */,
      68,    0,  540,    2, 0x08 /* Private */,
      69,    0,  541,    2, 0x08 /* Private */,
      70,    0,  542,    2, 0x08 /* Private */,
      71,    0,  543,    2, 0x08 /* Private */,
      72,    0,  544,    2, 0x08 /* Private */,
      73,    0,  545,    2, 0x08 /* Private */,
      74,    0,  546,    2, 0x08 /* Private */,
      75,    0,  547,    2, 0x08 /* Private */,
      76,    0,  548,    2, 0x08 /* Private */,
      77,    0,  549,    2, 0x08 /* Private */,
      78,    0,  550,    2, 0x08 /* Private */,
      79,    0,  551,    2, 0x08 /* Private */,
      80,    0,  552,    2, 0x08 /* Private */,
      81,    0,  553,    2, 0x08 /* Private */,
      82,    1,  554,    2, 0x08 /* Private */,
      85,    1,  557,    2, 0x08 /* Private */,
      86,    1,  560,    2, 0x08 /* Private */,
      87,    1,  563,    2, 0x08 /* Private */,
      88,    1,  566,    2, 0x08 /* Private */,
      89,    0,  569,    2, 0x08 /* Private */,
      90,    0,  570,    2, 0x08 /* Private */,
      91,    0,  571,    2, 0x08 /* Private */,
      92,    0,  572,    2, 0x08 /* Private */,
      93,    0,  573,    2, 0x08 /* Private */,
      94,    0,  574,    2, 0x08 /* Private */,
      95,    0,  575,    2, 0x08 /* Private */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 83,   84,
    QMetaType::Void, 0x80000000 | 83,   84,
    QMetaType::Void, 0x80000000 | 83,   84,
    QMetaType::Void, 0x80000000 | 83,   84,
    QMetaType::Void, 0x80000000 | 83,   84,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void MainWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        MainWindow *_t = static_cast<MainWindow *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->on_spinBox_4_valueChanged(); break;
        case 1: _t->on_actionClassical_triggered(); break;
        case 2: _t->on_pushButton_2_clicked(); break;
        case 3: _t->on_doubleSpinBox_4_valueChanged(); break;
        case 4: _t->on_doubleSpinBox_3_valueChanged(); break;
        case 5: _t->on_checkBox_8_clicked(); break;
        case 6: _t->on_checkBox_9_clicked(); break;
        case 7: _t->on_checkBox_clicked(); break;
        case 8: _t->on_pushButton_3_clicked(); break;
        case 9: _t->overview(); break;
        case 10: _t->revectors(); break;
        case 11: _t->Echellogram(); break;
        case 12: _t->parameters(); break;
        case 13: _t->on_doubleSpinBox_valueChanged(); break;
        case 14: _t->on_doubleSpinBox_2_valueChanged(); break;
        case 15: _t->on_pushButton_4_clicked(); break;
        case 16: _t->on_spinBox_5_valueChanged(); break;
        case 17: _t->on_pushButton_5_clicked(); break;
        case 18: _t->on_pushButton_6_clicked(); break;
        case 19: _t->on_actionParameters_triggered(); break;
        case 20: _t->on_doubleSpinBox_5_valueChanged(); break;
        case 21: _t->on_doubleSpinBox_6_valueChanged(); break;
        case 22: _t->on_doubleSpinBox_8_valueChanged(); break;
        case 23: _t->on_doubleSpinBox_7_valueChanged(); break;
        case 24: _t->on_doubleSpinBox_9_valueChanged(); break;
        case 25: _t->on_doubleSpinBox_10_valueChanged(); break;
        case 26: _t->on_doubleSpinBox_12_valueChanged(); break;
        case 27: _t->on_doubleSpinBox_14_valueChanged(); break;
        case 28: _t->on_doubleSpinBox_15_valueChanged(); break;
        case 29: _t->on_doubleSpinBox_16_valueChanged(); break;
        case 30: _t->on_doubleSpinBox_17_valueChanged(); break;
        case 31: _t->on_spinBox_2_valueChanged(); break;
        case 32: _t->on_spinBox_valueChanged(); break;
        case 33: _t->on_spinBox_3_valueChanged(); break;
        case 34: _t->on_spinBox_7_valueChanged(); break;
        case 35: _t->on_spinBox_8_valueChanged(); break;
        case 36: _t->on_checkBox_11_clicked(); break;
        case 37: _t->on_spinBox_6_valueChanged(); break;
        case 38: _t->on_doubleSpinBox_18_valueChanged(); break;
        case 39: _t->on_doubleSpinBox_20_valueChanged(); break;
        case 40: _t->on_doubleSpinBox_21_valueChanged(); break;
        case 41: _t->on_actionClassical_2_triggered(); break;
        case 42: _t->on_doubleSpinBox_22_valueChanged(); break;
        case 43: _t->on_doubleSpinBox_23_valueChanged(); break;
        case 44: _t->on_doubleSpinBox_24_valueChanged(); break;
        case 45: _t->on_doubleSpinBox_25_valueChanged(); break;
        case 46: _t->on_doubleSpinBox_27_valueChanged(); break;
        case 47: _t->on_doubleSpinBox_28_valueChanged(); break;
        case 48: _t->on_doubleSpinBox_29_valueChanged(); break;
        case 49: _t->on_doubleSpinBox_26_valueChanged(); break;
        case 50: _t->on_action3D_Spectrograph_triggered(); break;
        case 51: _t->on_action3D_triggered(); break;
        case 52: _t->on_action3D_Frame_triggered(); break;
        case 53: _t->on_actionEchelle_Frame_triggered(); break;
        case 54: _t->on_pushButton_7_clicked(); break;
        case 55: _t->on_actionAbout_triggered(); break;
        case 56: _t->on_actionBug_Report_triggered(); break;
        case 57: _t->on_actionManual_triggered(); break;
        case 58: _t->on_pushButton_8_clicked(); break;
        case 59: _t->setvalues(); break;
        case 60: _t->on_actionBasics_triggered(); break;
        case 61: _t->on_actionVPHG_triggered(); break;
        case 62: _t->on_actionOptical_Fibres_triggered(); break;
        case 63: _t->on_comboBox_currentIndexChanged(); break;
        case 64: _t->on_comboBox_2_currentIndexChanged(); break;
        case 65: _t->on_spinBox_9_valueChanged(); break;
        case 66: _t->on_doubleSpinBox_33_valueChanged(); break;
        case 67: _t->on_spinBox_10_valueChanged(); break;
        case 68: _t->on_spinBox_11_valueChanged(); break;
        case 69: _t->on_doubleSpinBox_35_valueChanged(); break;
        case 70: _t->on_doubleSpinBox_34_valueChanged(); break;
        case 71: _t->on_actionClassical_Frame_triggered(); break;
        case 72: _t->on_actionTSI_triggered(); break;
        case 73: _t->warning1(); break;
        case 74: _t->on_actionNotes_triggered(); break;
        case 75: _t->on_actionNew_triggered(); break;
        case 76: _t->on_actionUndo_triggered(); break;
        case 77: _t->on_actionOpen_triggered(); break;
        case 78: _t->on_actionSave_AS_triggered(); break;
        case 79: _t->on_actionSave_triggered(); break;
        case 80: _t->showPointToolTip((*reinterpret_cast< QMouseEvent*(*)>(_a[1]))); break;
        case 81: _t->showPointToolTip_2((*reinterpret_cast< QMouseEvent*(*)>(_a[1]))); break;
        case 82: _t->showPointToolTip_3((*reinterpret_cast< QMouseEvent*(*)>(_a[1]))); break;
        case 83: _t->showPointToolTip_4((*reinterpret_cast< QMouseEvent*(*)>(_a[1]))); break;
        case 84: _t->showPointToolTip_5((*reinterpret_cast< QMouseEvent*(*)>(_a[1]))); break;
        case 85: _t->on_actionFPE_triggered(); break;
        case 86: _t->on_actionCzerny_Turner_triggered(); break;
        case 87: _t->on_actionPetzval_triggered(); break;
        case 88: _t->on_pushButton_9_clicked(); break;
        case 89: _t->on_comboBox_4_currentIndexChanged(); break;
        case 90: _t->on_pushButton_10_clicked(); break;
        case 91: _t->on_checkBox_2_clicked(); break;
        default: ;
        }
    }
}

const QMetaObject MainWindow::staticMetaObject = {
    { &QMainWindow::staticMetaObject, qt_meta_stringdata_MainWindow.data,
      qt_meta_data_MainWindow,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *MainWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_MainWindow.stringdata0))
        return static_cast<void*>(const_cast< MainWindow*>(this));
    return QMainWindow::qt_metacast(_clname);
}

int MainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 92)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 92;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 92)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 92;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
