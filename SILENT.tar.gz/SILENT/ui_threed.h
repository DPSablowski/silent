/********************************************************************************
** Form generated from reading UI file 'threed.ui'
**
** Created by: Qt User Interface Compiler version 5.8.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_THREED_H
#define UI_THREED_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDialog>
#include <QtWidgets/QDoubleSpinBox>
#include <QtWidgets/QFrame>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QProgressBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QScrollArea>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QSpinBox>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>
#include "qcustomplot.h"

QT_BEGIN_NAMESPACE

class Ui_threed
{
public:
    QGridLayout *gridLayout;
    QScrollArea *scrollArea;
    QWidget *scrollAreaWidgetContents;
    QHBoxLayout *horizontalLayout_43;
    QVBoxLayout *verticalLayout;
    QLabel *label;
    QHBoxLayout *horizontalLayout;
    QCheckBox *checkBox;
    QCheckBox *checkBox_2;
    QHBoxLayout *horizontalLayout_2;
    QLabel *label_2;
    QDoubleSpinBox *doubleSpinBox;
    QHBoxLayout *horizontalLayout_3;
    QLabel *label_3;
    QSpinBox *spinBox;
    QHBoxLayout *horizontalLayout_7;
    QLabel *label_7;
    QDoubleSpinBox *doubleSpinBox_5;
    QHBoxLayout *horizontalLayout_4;
    QLabel *label_4;
    QDoubleSpinBox *doubleSpinBox_2;
    QHBoxLayout *horizontalLayout_5;
    QLabel *label_5;
    QDoubleSpinBox *doubleSpinBox_3;
    QHBoxLayout *horizontalLayout_6;
    QLabel *label_6;
    QDoubleSpinBox *doubleSpinBox_4;
    QHBoxLayout *horizontalLayout_8;
    QLabel *label_8;
    QDoubleSpinBox *doubleSpinBox_6;
    QHBoxLayout *horizontalLayout_9;
    QLabel *label_9;
    QDoubleSpinBox *doubleSpinBox_7;
    QHBoxLayout *horizontalLayout_10;
    QLabel *label_10;
    QDoubleSpinBox *doubleSpinBox_8;
    QHBoxLayout *horizontalLayout_11;
    QLabel *label_11;
    QDoubleSpinBox *doubleSpinBox_9;
    QHBoxLayout *horizontalLayout_12;
    QLabel *label_12;
    QDoubleSpinBox *doubleSpinBox_10;
    QHBoxLayout *horizontalLayout_41;
    QLabel *label_45;
    QDoubleSpinBox *doubleSpinBox_29;
    QHBoxLayout *horizontalLayout_42;
    QComboBox *comboBox;
    QPushButton *pushButton_3;
    QPushButton *pushButton_4;
    QFrame *line_6;
    QHBoxLayout *horizontalLayout_46;
    QLabel *label_50;
    QLineEdit *lineEdit_3;
    QSpacerItem *verticalSpacer_2;
    QPushButton *pushButton;
    QFrame *line;
    QVBoxLayout *verticalLayout_2;
    QLabel *label_13;
    QHBoxLayout *horizontalLayout_13;
    QLabel *label_14;
    QDoubleSpinBox *doubleSpinBox_11;
    QHBoxLayout *horizontalLayout_14;
    QLabel *label_15;
    QDoubleSpinBox *doubleSpinBox_12;
    QHBoxLayout *horizontalLayout_15;
    QLabel *label_16;
    QDoubleSpinBox *doubleSpinBox_13;
    QFrame *line_2;
    QHBoxLayout *horizontalLayout_16;
    QLabel *label_17;
    QDoubleSpinBox *doubleSpinBox_14;
    QHBoxLayout *horizontalLayout_17;
    QLabel *label_18;
    QSpinBox *spinBox_2;
    QHBoxLayout *horizontalLayout_18;
    QLabel *label_19;
    QSpinBox *spinBox_3;
    QHBoxLayout *horizontalLayout_19;
    QLabel *label_20;
    QSpinBox *spinBox_4;
    QHBoxLayout *horizontalLayout_20;
    QLabel *label_21;
    QSpinBox *spinBox_5;
    QHBoxLayout *horizontalLayout_21;
    QLabel *label_22;
    QDoubleSpinBox *doubleSpinBox_15;
    QHBoxLayout *horizontalLayout_22;
    QLabel *label_23;
    QDoubleSpinBox *doubleSpinBox_16;
    QHBoxLayout *horizontalLayout_23;
    QLabel *label_24;
    QDoubleSpinBox *doubleSpinBox_17;
    QHBoxLayout *horizontalLayout_24;
    QLabel *label_25;
    QDoubleSpinBox *doubleSpinBox_18;
    QHBoxLayout *horizontalLayout_25;
    QLabel *label_26;
    QDoubleSpinBox *doubleSpinBox_19;
    QProgressBar *progressBar;
    QHBoxLayout *horizontalLayout_44;
    QLineEdit *lineEdit;
    QLabel *label_48;
    QPushButton *pushButton_5;
    QHBoxLayout *horizontalLayout_45;
    QLineEdit *lineEdit_2;
    QLabel *label_49;
    QPushButton *pushButton_6;
    QSpacerItem *verticalSpacer;
    QFrame *line_3;
    QVBoxLayout *verticalLayout_3;
    QLabel *label_27;
    QHBoxLayout *horizontalLayout_26;
    QCheckBox *checkBox_3;
    QCheckBox *checkBox_4;
    QCheckBox *checkBox_5;
    QHBoxLayout *horizontalLayout_27;
    QLabel *label_28;
    QSpinBox *spinBox_6;
    QHBoxLayout *horizontalLayout_28;
    QLabel *label_29;
    QDoubleSpinBox *doubleSpinBox_20;
    QLabel *label_30;
    QDoubleSpinBox *doubleSpinBox_21;
    QHBoxLayout *horizontalLayout_30;
    QLabel *label_32;
    QDoubleSpinBox *doubleSpinBox_23;
    QHBoxLayout *horizontalLayout_29;
    QPushButton *pushButton_2;
    QLabel *label_31;
    QDoubleSpinBox *doubleSpinBox_22;
    QFrame *line_4;
    QLabel *label_33;
    QHBoxLayout *horizontalLayout_31;
    QLabel *label_34;
    QSpinBox *spinBox_7;
    QHBoxLayout *horizontalLayout_32;
    QLabel *label_35;
    QSpinBox *spinBox_8;
    QHBoxLayout *horizontalLayout_33;
    QLabel *label_36;
    QSpinBox *spinBox_9;
    QHBoxLayout *horizontalLayout_34;
    QLabel *label_37;
    QSpinBox *spinBox_10;
    QHBoxLayout *horizontalLayout_35;
    QLabel *label_38;
    QSpinBox *spinBox_11;
    QLabel *label_39;
    QHBoxLayout *horizontalLayout_36;
    QLabel *label_40;
    QDoubleSpinBox *doubleSpinBox_24;
    QHBoxLayout *horizontalLayout_37;
    QLabel *label_41;
    QDoubleSpinBox *doubleSpinBox_25;
    QHBoxLayout *horizontalLayout_38;
    QLabel *label_42;
    QDoubleSpinBox *doubleSpinBox_26;
    QHBoxLayout *horizontalLayout_39;
    QLabel *label_43;
    QDoubleSpinBox *doubleSpinBox_27;
    QHBoxLayout *horizontalLayout_40;
    QLabel *label_44;
    QDoubleSpinBox *doubleSpinBox_28;
    QFrame *line_5;
    QVBoxLayout *verticalLayout_4;
    QLabel *label_46;
    QCustomPlot *customPlot;
    QLabel *label_47;
    QCustomPlot *customPlot_2;

    void setupUi(QDialog *threed)
    {
        if (threed->objectName().isEmpty())
            threed->setObjectName(QStringLiteral("threed"));
        threed->resize(1391, 708);
        QSizePolicy sizePolicy(QSizePolicy::MinimumExpanding, QSizePolicy::MinimumExpanding);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(threed->sizePolicy().hasHeightForWidth());
        threed->setSizePolicy(sizePolicy);
        QFont font;
        font.setFamily(QStringLiteral("Ubuntu Mono"));
        font.setBold(true);
        font.setItalic(true);
        font.setWeight(75);
        threed->setFont(font);
        threed->setMouseTracking(false);
        threed->setFocusPolicy(Qt::NoFocus);
        threed->setAutoFillBackground(false);
        threed->setStyleSheet(QStringLiteral(""));
        threed->setSizeGripEnabled(false);
        gridLayout = new QGridLayout(threed);
        gridLayout->setObjectName(QStringLiteral("gridLayout"));
        scrollArea = new QScrollArea(threed);
        scrollArea->setObjectName(QStringLiteral("scrollArea"));
        scrollArea->setFrameShape(QFrame::NoFrame);
        scrollArea->setWidgetResizable(true);
        scrollAreaWidgetContents = new QWidget();
        scrollAreaWidgetContents->setObjectName(QStringLiteral("scrollAreaWidgetContents"));
        scrollAreaWidgetContents->setGeometry(QRect(0, 0, 1705, 721));
        horizontalLayout_43 = new QHBoxLayout(scrollAreaWidgetContents);
        horizontalLayout_43->setObjectName(QStringLiteral("horizontalLayout_43"));
        verticalLayout = new QVBoxLayout();
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        label = new QLabel(scrollAreaWidgetContents);
        label->setObjectName(QStringLiteral("label"));

        verticalLayout->addWidget(label);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        checkBox = new QCheckBox(scrollAreaWidgetContents);
        checkBox->setObjectName(QStringLiteral("checkBox"));

        horizontalLayout->addWidget(checkBox);

        checkBox_2 = new QCheckBox(scrollAreaWidgetContents);
        checkBox_2->setObjectName(QStringLiteral("checkBox_2"));

        horizontalLayout->addWidget(checkBox_2);


        verticalLayout->addLayout(horizontalLayout);

        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setObjectName(QStringLiteral("horizontalLayout_2"));
        label_2 = new QLabel(scrollAreaWidgetContents);
        label_2->setObjectName(QStringLiteral("label_2"));

        horizontalLayout_2->addWidget(label_2);

        doubleSpinBox = new QDoubleSpinBox(scrollAreaWidgetContents);
        doubleSpinBox->setObjectName(QStringLiteral("doubleSpinBox"));
        QSizePolicy sizePolicy1(QSizePolicy::Maximum, QSizePolicy::Fixed);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(doubleSpinBox->sizePolicy().hasHeightForWidth());
        doubleSpinBox->setSizePolicy(sizePolicy1);
        doubleSpinBox->setMaximum(9999.99);

        horizontalLayout_2->addWidget(doubleSpinBox);


        verticalLayout->addLayout(horizontalLayout_2);

        horizontalLayout_3 = new QHBoxLayout();
        horizontalLayout_3->setObjectName(QStringLiteral("horizontalLayout_3"));
        label_3 = new QLabel(scrollAreaWidgetContents);
        label_3->setObjectName(QStringLiteral("label_3"));

        horizontalLayout_3->addWidget(label_3);

        spinBox = new QSpinBox(scrollAreaWidgetContents);
        spinBox->setObjectName(QStringLiteral("spinBox"));
        sizePolicy1.setHeightForWidth(spinBox->sizePolicy().hasHeightForWidth());
        spinBox->setSizePolicy(sizePolicy1);

        horizontalLayout_3->addWidget(spinBox);


        verticalLayout->addLayout(horizontalLayout_3);

        horizontalLayout_7 = new QHBoxLayout();
        horizontalLayout_7->setObjectName(QStringLiteral("horizontalLayout_7"));
        label_7 = new QLabel(scrollAreaWidgetContents);
        label_7->setObjectName(QStringLiteral("label_7"));

        horizontalLayout_7->addWidget(label_7);

        doubleSpinBox_5 = new QDoubleSpinBox(scrollAreaWidgetContents);
        doubleSpinBox_5->setObjectName(QStringLiteral("doubleSpinBox_5"));
        sizePolicy1.setHeightForWidth(doubleSpinBox_5->sizePolicy().hasHeightForWidth());
        doubleSpinBox_5->setSizePolicy(sizePolicy1);
        doubleSpinBox_5->setMinimum(-90);
        doubleSpinBox_5->setMaximum(90);

        horizontalLayout_7->addWidget(doubleSpinBox_5);


        verticalLayout->addLayout(horizontalLayout_7);

        horizontalLayout_4 = new QHBoxLayout();
        horizontalLayout_4->setObjectName(QStringLiteral("horizontalLayout_4"));
        label_4 = new QLabel(scrollAreaWidgetContents);
        label_4->setObjectName(QStringLiteral("label_4"));

        horizontalLayout_4->addWidget(label_4);

        doubleSpinBox_2 = new QDoubleSpinBox(scrollAreaWidgetContents);
        doubleSpinBox_2->setObjectName(QStringLiteral("doubleSpinBox_2"));
        sizePolicy1.setHeightForWidth(doubleSpinBox_2->sizePolicy().hasHeightForWidth());
        doubleSpinBox_2->setSizePolicy(sizePolicy1);

        horizontalLayout_4->addWidget(doubleSpinBox_2);


        verticalLayout->addLayout(horizontalLayout_4);

        horizontalLayout_5 = new QHBoxLayout();
        horizontalLayout_5->setObjectName(QStringLiteral("horizontalLayout_5"));
        label_5 = new QLabel(scrollAreaWidgetContents);
        label_5->setObjectName(QStringLiteral("label_5"));

        horizontalLayout_5->addWidget(label_5);

        doubleSpinBox_3 = new QDoubleSpinBox(scrollAreaWidgetContents);
        doubleSpinBox_3->setObjectName(QStringLiteral("doubleSpinBox_3"));
        sizePolicy1.setHeightForWidth(doubleSpinBox_3->sizePolicy().hasHeightForWidth());
        doubleSpinBox_3->setSizePolicy(sizePolicy1);
        doubleSpinBox_3->setDecimals(3);
        doubleSpinBox_3->setMaximum(1);

        horizontalLayout_5->addWidget(doubleSpinBox_3);


        verticalLayout->addLayout(horizontalLayout_5);

        horizontalLayout_6 = new QHBoxLayout();
        horizontalLayout_6->setObjectName(QStringLiteral("horizontalLayout_6"));
        label_6 = new QLabel(scrollAreaWidgetContents);
        label_6->setObjectName(QStringLiteral("label_6"));

        horizontalLayout_6->addWidget(label_6);

        doubleSpinBox_4 = new QDoubleSpinBox(scrollAreaWidgetContents);
        doubleSpinBox_4->setObjectName(QStringLiteral("doubleSpinBox_4"));
        sizePolicy1.setHeightForWidth(doubleSpinBox_4->sizePolicy().hasHeightForWidth());
        doubleSpinBox_4->setSizePolicy(sizePolicy1);
        doubleSpinBox_4->setMinimum(99);
        doubleSpinBox_4->setMaximum(999.99);

        horizontalLayout_6->addWidget(doubleSpinBox_4);


        verticalLayout->addLayout(horizontalLayout_6);

        horizontalLayout_8 = new QHBoxLayout();
        horizontalLayout_8->setObjectName(QStringLiteral("horizontalLayout_8"));
        label_8 = new QLabel(scrollAreaWidgetContents);
        label_8->setObjectName(QStringLiteral("label_8"));

        horizontalLayout_8->addWidget(label_8);

        doubleSpinBox_6 = new QDoubleSpinBox(scrollAreaWidgetContents);
        doubleSpinBox_6->setObjectName(QStringLiteral("doubleSpinBox_6"));
        sizePolicy1.setHeightForWidth(doubleSpinBox_6->sizePolicy().hasHeightForWidth());
        doubleSpinBox_6->setSizePolicy(sizePolicy1);

        horizontalLayout_8->addWidget(doubleSpinBox_6);


        verticalLayout->addLayout(horizontalLayout_8);

        horizontalLayout_9 = new QHBoxLayout();
        horizontalLayout_9->setObjectName(QStringLiteral("horizontalLayout_9"));
        label_9 = new QLabel(scrollAreaWidgetContents);
        label_9->setObjectName(QStringLiteral("label_9"));

        horizontalLayout_9->addWidget(label_9);

        doubleSpinBox_7 = new QDoubleSpinBox(scrollAreaWidgetContents);
        doubleSpinBox_7->setObjectName(QStringLiteral("doubleSpinBox_7"));
        sizePolicy1.setHeightForWidth(doubleSpinBox_7->sizePolicy().hasHeightForWidth());
        doubleSpinBox_7->setSizePolicy(sizePolicy1);
        doubleSpinBox_7->setDecimals(3);

        horizontalLayout_9->addWidget(doubleSpinBox_7);


        verticalLayout->addLayout(horizontalLayout_9);

        horizontalLayout_10 = new QHBoxLayout();
        horizontalLayout_10->setObjectName(QStringLiteral("horizontalLayout_10"));
        label_10 = new QLabel(scrollAreaWidgetContents);
        label_10->setObjectName(QStringLiteral("label_10"));

        horizontalLayout_10->addWidget(label_10);

        doubleSpinBox_8 = new QDoubleSpinBox(scrollAreaWidgetContents);
        doubleSpinBox_8->setObjectName(QStringLiteral("doubleSpinBox_8"));
        sizePolicy1.setHeightForWidth(doubleSpinBox_8->sizePolicy().hasHeightForWidth());
        doubleSpinBox_8->setSizePolicy(sizePolicy1);
        doubleSpinBox_8->setDecimals(4);

        horizontalLayout_10->addWidget(doubleSpinBox_8);


        verticalLayout->addLayout(horizontalLayout_10);

        horizontalLayout_11 = new QHBoxLayout();
        horizontalLayout_11->setObjectName(QStringLiteral("horizontalLayout_11"));
        label_11 = new QLabel(scrollAreaWidgetContents);
        label_11->setObjectName(QStringLiteral("label_11"));

        horizontalLayout_11->addWidget(label_11);

        doubleSpinBox_9 = new QDoubleSpinBox(scrollAreaWidgetContents);
        doubleSpinBox_9->setObjectName(QStringLiteral("doubleSpinBox_9"));
        sizePolicy1.setHeightForWidth(doubleSpinBox_9->sizePolicy().hasHeightForWidth());
        doubleSpinBox_9->setSizePolicy(sizePolicy1);
        doubleSpinBox_9->setMaximum(9999.99);

        horizontalLayout_11->addWidget(doubleSpinBox_9);


        verticalLayout->addLayout(horizontalLayout_11);

        horizontalLayout_12 = new QHBoxLayout();
        horizontalLayout_12->setObjectName(QStringLiteral("horizontalLayout_12"));
        label_12 = new QLabel(scrollAreaWidgetContents);
        label_12->setObjectName(QStringLiteral("label_12"));

        horizontalLayout_12->addWidget(label_12);

        doubleSpinBox_10 = new QDoubleSpinBox(scrollAreaWidgetContents);
        doubleSpinBox_10->setObjectName(QStringLiteral("doubleSpinBox_10"));
        sizePolicy1.setHeightForWidth(doubleSpinBox_10->sizePolicy().hasHeightForWidth());
        doubleSpinBox_10->setSizePolicy(sizePolicy1);
        doubleSpinBox_10->setMaximum(9999.99);

        horizontalLayout_12->addWidget(doubleSpinBox_10);


        verticalLayout->addLayout(horizontalLayout_12);

        horizontalLayout_41 = new QHBoxLayout();
        horizontalLayout_41->setObjectName(QStringLiteral("horizontalLayout_41"));
        label_45 = new QLabel(scrollAreaWidgetContents);
        label_45->setObjectName(QStringLiteral("label_45"));

        horizontalLayout_41->addWidget(label_45);

        doubleSpinBox_29 = new QDoubleSpinBox(scrollAreaWidgetContents);
        doubleSpinBox_29->setObjectName(QStringLiteral("doubleSpinBox_29"));
        sizePolicy1.setHeightForWidth(doubleSpinBox_29->sizePolicy().hasHeightForWidth());
        doubleSpinBox_29->setSizePolicy(sizePolicy1);
        doubleSpinBox_29->setMaximum(999.99);

        horizontalLayout_41->addWidget(doubleSpinBox_29);


        verticalLayout->addLayout(horizontalLayout_41);

        horizontalLayout_42 = new QHBoxLayout();
        horizontalLayout_42->setObjectName(QStringLiteral("horizontalLayout_42"));
        comboBox = new QComboBox(scrollAreaWidgetContents);
        comboBox->setObjectName(QStringLiteral("comboBox"));
        sizePolicy1.setHeightForWidth(comboBox->sizePolicy().hasHeightForWidth());
        comboBox->setSizePolicy(sizePolicy1);

        horizontalLayout_42->addWidget(comboBox);

        pushButton_3 = new QPushButton(scrollAreaWidgetContents);
        pushButton_3->setObjectName(QStringLiteral("pushButton_3"));
        sizePolicy1.setHeightForWidth(pushButton_3->sizePolicy().hasHeightForWidth());
        pushButton_3->setSizePolicy(sizePolicy1);

        horizontalLayout_42->addWidget(pushButton_3);

        pushButton_4 = new QPushButton(scrollAreaWidgetContents);
        pushButton_4->setObjectName(QStringLiteral("pushButton_4"));
        sizePolicy1.setHeightForWidth(pushButton_4->sizePolicy().hasHeightForWidth());
        pushButton_4->setSizePolicy(sizePolicy1);

        horizontalLayout_42->addWidget(pushButton_4);


        verticalLayout->addLayout(horizontalLayout_42);

        line_6 = new QFrame(scrollAreaWidgetContents);
        line_6->setObjectName(QStringLiteral("line_6"));
        line_6->setFrameShape(QFrame::HLine);
        line_6->setFrameShadow(QFrame::Sunken);

        verticalLayout->addWidget(line_6);

        horizontalLayout_46 = new QHBoxLayout();
        horizontalLayout_46->setObjectName(QStringLiteral("horizontalLayout_46"));
        label_50 = new QLabel(scrollAreaWidgetContents);
        label_50->setObjectName(QStringLiteral("label_50"));

        horizontalLayout_46->addWidget(label_50);

        lineEdit_3 = new QLineEdit(scrollAreaWidgetContents);
        lineEdit_3->setObjectName(QStringLiteral("lineEdit_3"));
        QSizePolicy sizePolicy2(QSizePolicy::Preferred, QSizePolicy::Fixed);
        sizePolicy2.setHorizontalStretch(0);
        sizePolicy2.setVerticalStretch(0);
        sizePolicy2.setHeightForWidth(lineEdit_3->sizePolicy().hasHeightForWidth());
        lineEdit_3->setSizePolicy(sizePolicy2);

        horizontalLayout_46->addWidget(lineEdit_3);


        verticalLayout->addLayout(horizontalLayout_46);

        verticalSpacer_2 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout->addItem(verticalSpacer_2);

        pushButton = new QPushButton(scrollAreaWidgetContents);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        sizePolicy1.setHeightForWidth(pushButton->sizePolicy().hasHeightForWidth());
        pushButton->setSizePolicy(sizePolicy1);

        verticalLayout->addWidget(pushButton);


        horizontalLayout_43->addLayout(verticalLayout);

        line = new QFrame(scrollAreaWidgetContents);
        line->setObjectName(QStringLiteral("line"));
        line->setFrameShadow(QFrame::Plain);
        line->setFrameShape(QFrame::VLine);

        horizontalLayout_43->addWidget(line);

        verticalLayout_2 = new QVBoxLayout();
        verticalLayout_2->setObjectName(QStringLiteral("verticalLayout_2"));
        label_13 = new QLabel(scrollAreaWidgetContents);
        label_13->setObjectName(QStringLiteral("label_13"));

        verticalLayout_2->addWidget(label_13);

        horizontalLayout_13 = new QHBoxLayout();
        horizontalLayout_13->setObjectName(QStringLiteral("horizontalLayout_13"));
        label_14 = new QLabel(scrollAreaWidgetContents);
        label_14->setObjectName(QStringLiteral("label_14"));

        horizontalLayout_13->addWidget(label_14);

        doubleSpinBox_11 = new QDoubleSpinBox(scrollAreaWidgetContents);
        doubleSpinBox_11->setObjectName(QStringLiteral("doubleSpinBox_11"));
        sizePolicy1.setHeightForWidth(doubleSpinBox_11->sizePolicy().hasHeightForWidth());
        doubleSpinBox_11->setSizePolicy(sizePolicy1);

        horizontalLayout_13->addWidget(doubleSpinBox_11);


        verticalLayout_2->addLayout(horizontalLayout_13);

        horizontalLayout_14 = new QHBoxLayout();
        horizontalLayout_14->setObjectName(QStringLiteral("horizontalLayout_14"));
        label_15 = new QLabel(scrollAreaWidgetContents);
        label_15->setObjectName(QStringLiteral("label_15"));

        horizontalLayout_14->addWidget(label_15);

        doubleSpinBox_12 = new QDoubleSpinBox(scrollAreaWidgetContents);
        doubleSpinBox_12->setObjectName(QStringLiteral("doubleSpinBox_12"));
        sizePolicy1.setHeightForWidth(doubleSpinBox_12->sizePolicy().hasHeightForWidth());
        doubleSpinBox_12->setSizePolicy(sizePolicy1);
        doubleSpinBox_12->setMaximum(9999.99);

        horizontalLayout_14->addWidget(doubleSpinBox_12);


        verticalLayout_2->addLayout(horizontalLayout_14);

        horizontalLayout_15 = new QHBoxLayout();
        horizontalLayout_15->setObjectName(QStringLiteral("horizontalLayout_15"));
        label_16 = new QLabel(scrollAreaWidgetContents);
        label_16->setObjectName(QStringLiteral("label_16"));

        horizontalLayout_15->addWidget(label_16);

        doubleSpinBox_13 = new QDoubleSpinBox(scrollAreaWidgetContents);
        doubleSpinBox_13->setObjectName(QStringLiteral("doubleSpinBox_13"));
        sizePolicy1.setHeightForWidth(doubleSpinBox_13->sizePolicy().hasHeightForWidth());
        doubleSpinBox_13->setSizePolicy(sizePolicy1);
        doubleSpinBox_13->setMaximum(9009.99);

        horizontalLayout_15->addWidget(doubleSpinBox_13);


        verticalLayout_2->addLayout(horizontalLayout_15);

        line_2 = new QFrame(scrollAreaWidgetContents);
        line_2->setObjectName(QStringLiteral("line_2"));
        line_2->setFrameShadow(QFrame::Plain);
        line_2->setFrameShape(QFrame::HLine);

        verticalLayout_2->addWidget(line_2);

        horizontalLayout_16 = new QHBoxLayout();
        horizontalLayout_16->setObjectName(QStringLiteral("horizontalLayout_16"));
        label_17 = new QLabel(scrollAreaWidgetContents);
        label_17->setObjectName(QStringLiteral("label_17"));

        horizontalLayout_16->addWidget(label_17);

        doubleSpinBox_14 = new QDoubleSpinBox(scrollAreaWidgetContents);
        doubleSpinBox_14->setObjectName(QStringLiteral("doubleSpinBox_14"));
        sizePolicy1.setHeightForWidth(doubleSpinBox_14->sizePolicy().hasHeightForWidth());
        doubleSpinBox_14->setSizePolicy(sizePolicy1);
        doubleSpinBox_14->setDecimals(4);
        doubleSpinBox_14->setMaximum(9.99);

        horizontalLayout_16->addWidget(doubleSpinBox_14);


        verticalLayout_2->addLayout(horizontalLayout_16);

        horizontalLayout_17 = new QHBoxLayout();
        horizontalLayout_17->setObjectName(QStringLiteral("horizontalLayout_17"));
        label_18 = new QLabel(scrollAreaWidgetContents);
        label_18->setObjectName(QStringLiteral("label_18"));

        horizontalLayout_17->addWidget(label_18);

        spinBox_2 = new QSpinBox(scrollAreaWidgetContents);
        spinBox_2->setObjectName(QStringLiteral("spinBox_2"));
        sizePolicy1.setHeightForWidth(spinBox_2->sizePolicy().hasHeightForWidth());
        spinBox_2->setSizePolicy(sizePolicy1);
        spinBox_2->setMaximum(9999);

        horizontalLayout_17->addWidget(spinBox_2);


        verticalLayout_2->addLayout(horizontalLayout_17);

        horizontalLayout_18 = new QHBoxLayout();
        horizontalLayout_18->setObjectName(QStringLiteral("horizontalLayout_18"));
        label_19 = new QLabel(scrollAreaWidgetContents);
        label_19->setObjectName(QStringLiteral("label_19"));

        horizontalLayout_18->addWidget(label_19);

        spinBox_3 = new QSpinBox(scrollAreaWidgetContents);
        spinBox_3->setObjectName(QStringLiteral("spinBox_3"));
        sizePolicy1.setHeightForWidth(spinBox_3->sizePolicy().hasHeightForWidth());
        spinBox_3->setSizePolicy(sizePolicy1);
        spinBox_3->setMaximum(9999);

        horizontalLayout_18->addWidget(spinBox_3);


        verticalLayout_2->addLayout(horizontalLayout_18);

        horizontalLayout_19 = new QHBoxLayout();
        horizontalLayout_19->setObjectName(QStringLiteral("horizontalLayout_19"));
        label_20 = new QLabel(scrollAreaWidgetContents);
        label_20->setObjectName(QStringLiteral("label_20"));

        horizontalLayout_19->addWidget(label_20);

        spinBox_4 = new QSpinBox(scrollAreaWidgetContents);
        spinBox_4->setObjectName(QStringLiteral("spinBox_4"));
        sizePolicy1.setHeightForWidth(spinBox_4->sizePolicy().hasHeightForWidth());
        spinBox_4->setSizePolicy(sizePolicy1);

        horizontalLayout_19->addWidget(spinBox_4);


        verticalLayout_2->addLayout(horizontalLayout_19);

        horizontalLayout_20 = new QHBoxLayout();
        horizontalLayout_20->setObjectName(QStringLiteral("horizontalLayout_20"));
        label_21 = new QLabel(scrollAreaWidgetContents);
        label_21->setObjectName(QStringLiteral("label_21"));

        horizontalLayout_20->addWidget(label_21);

        spinBox_5 = new QSpinBox(scrollAreaWidgetContents);
        spinBox_5->setObjectName(QStringLiteral("spinBox_5"));
        sizePolicy1.setHeightForWidth(spinBox_5->sizePolicy().hasHeightForWidth());
        spinBox_5->setSizePolicy(sizePolicy1);

        horizontalLayout_20->addWidget(spinBox_5);


        verticalLayout_2->addLayout(horizontalLayout_20);

        horizontalLayout_21 = new QHBoxLayout();
        horizontalLayout_21->setObjectName(QStringLiteral("horizontalLayout_21"));
        label_22 = new QLabel(scrollAreaWidgetContents);
        label_22->setObjectName(QStringLiteral("label_22"));

        horizontalLayout_21->addWidget(label_22);

        doubleSpinBox_15 = new QDoubleSpinBox(scrollAreaWidgetContents);
        doubleSpinBox_15->setObjectName(QStringLiteral("doubleSpinBox_15"));
        sizePolicy1.setHeightForWidth(doubleSpinBox_15->sizePolicy().hasHeightForWidth());
        doubleSpinBox_15->setSizePolicy(sizePolicy1);
        doubleSpinBox_15->setMaximum(999.99);

        horizontalLayout_21->addWidget(doubleSpinBox_15);


        verticalLayout_2->addLayout(horizontalLayout_21);

        horizontalLayout_22 = new QHBoxLayout();
        horizontalLayout_22->setObjectName(QStringLiteral("horizontalLayout_22"));
        label_23 = new QLabel(scrollAreaWidgetContents);
        label_23->setObjectName(QStringLiteral("label_23"));

        horizontalLayout_22->addWidget(label_23);

        doubleSpinBox_16 = new QDoubleSpinBox(scrollAreaWidgetContents);
        doubleSpinBox_16->setObjectName(QStringLiteral("doubleSpinBox_16"));
        sizePolicy1.setHeightForWidth(doubleSpinBox_16->sizePolicy().hasHeightForWidth());
        doubleSpinBox_16->setSizePolicy(sizePolicy1);

        horizontalLayout_22->addWidget(doubleSpinBox_16);


        verticalLayout_2->addLayout(horizontalLayout_22);

        horizontalLayout_23 = new QHBoxLayout();
        horizontalLayout_23->setObjectName(QStringLiteral("horizontalLayout_23"));
        label_24 = new QLabel(scrollAreaWidgetContents);
        label_24->setObjectName(QStringLiteral("label_24"));

        horizontalLayout_23->addWidget(label_24);

        doubleSpinBox_17 = new QDoubleSpinBox(scrollAreaWidgetContents);
        doubleSpinBox_17->setObjectName(QStringLiteral("doubleSpinBox_17"));
        sizePolicy1.setHeightForWidth(doubleSpinBox_17->sizePolicy().hasHeightForWidth());
        doubleSpinBox_17->setSizePolicy(sizePolicy1);

        horizontalLayout_23->addWidget(doubleSpinBox_17);


        verticalLayout_2->addLayout(horizontalLayout_23);

        horizontalLayout_24 = new QHBoxLayout();
        horizontalLayout_24->setObjectName(QStringLiteral("horizontalLayout_24"));
        label_25 = new QLabel(scrollAreaWidgetContents);
        label_25->setObjectName(QStringLiteral("label_25"));

        horizontalLayout_24->addWidget(label_25);

        doubleSpinBox_18 = new QDoubleSpinBox(scrollAreaWidgetContents);
        doubleSpinBox_18->setObjectName(QStringLiteral("doubleSpinBox_18"));
        sizePolicy1.setHeightForWidth(doubleSpinBox_18->sizePolicy().hasHeightForWidth());
        doubleSpinBox_18->setSizePolicy(sizePolicy1);
        doubleSpinBox_18->setMaximum(999.99);

        horizontalLayout_24->addWidget(doubleSpinBox_18);


        verticalLayout_2->addLayout(horizontalLayout_24);

        horizontalLayout_25 = new QHBoxLayout();
        horizontalLayout_25->setObjectName(QStringLiteral("horizontalLayout_25"));
        label_26 = new QLabel(scrollAreaWidgetContents);
        label_26->setObjectName(QStringLiteral("label_26"));

        horizontalLayout_25->addWidget(label_26);

        doubleSpinBox_19 = new QDoubleSpinBox(scrollAreaWidgetContents);
        doubleSpinBox_19->setObjectName(QStringLiteral("doubleSpinBox_19"));
        sizePolicy1.setHeightForWidth(doubleSpinBox_19->sizePolicy().hasHeightForWidth());
        doubleSpinBox_19->setSizePolicy(sizePolicy1);

        horizontalLayout_25->addWidget(doubleSpinBox_19);


        verticalLayout_2->addLayout(horizontalLayout_25);

        progressBar = new QProgressBar(scrollAreaWidgetContents);
        progressBar->setObjectName(QStringLiteral("progressBar"));
        sizePolicy2.setHeightForWidth(progressBar->sizePolicy().hasHeightForWidth());
        progressBar->setSizePolicy(sizePolicy2);
        progressBar->setValue(24);

        verticalLayout_2->addWidget(progressBar);

        horizontalLayout_44 = new QHBoxLayout();
        horizontalLayout_44->setObjectName(QStringLiteral("horizontalLayout_44"));
        lineEdit = new QLineEdit(scrollAreaWidgetContents);
        lineEdit->setObjectName(QStringLiteral("lineEdit"));
        sizePolicy1.setHeightForWidth(lineEdit->sizePolicy().hasHeightForWidth());
        lineEdit->setSizePolicy(sizePolicy1);

        horizontalLayout_44->addWidget(lineEdit);

        label_48 = new QLabel(scrollAreaWidgetContents);
        label_48->setObjectName(QStringLiteral("label_48"));

        horizontalLayout_44->addWidget(label_48);

        pushButton_5 = new QPushButton(scrollAreaWidgetContents);
        pushButton_5->setObjectName(QStringLiteral("pushButton_5"));
        sizePolicy1.setHeightForWidth(pushButton_5->sizePolicy().hasHeightForWidth());
        pushButton_5->setSizePolicy(sizePolicy1);

        horizontalLayout_44->addWidget(pushButton_5);


        verticalLayout_2->addLayout(horizontalLayout_44);

        horizontalLayout_45 = new QHBoxLayout();
        horizontalLayout_45->setObjectName(QStringLiteral("horizontalLayout_45"));
        lineEdit_2 = new QLineEdit(scrollAreaWidgetContents);
        lineEdit_2->setObjectName(QStringLiteral("lineEdit_2"));
        sizePolicy1.setHeightForWidth(lineEdit_2->sizePolicy().hasHeightForWidth());
        lineEdit_2->setSizePolicy(sizePolicy1);

        horizontalLayout_45->addWidget(lineEdit_2);

        label_49 = new QLabel(scrollAreaWidgetContents);
        label_49->setObjectName(QStringLiteral("label_49"));

        horizontalLayout_45->addWidget(label_49);

        pushButton_6 = new QPushButton(scrollAreaWidgetContents);
        pushButton_6->setObjectName(QStringLiteral("pushButton_6"));
        sizePolicy1.setHeightForWidth(pushButton_6->sizePolicy().hasHeightForWidth());
        pushButton_6->setSizePolicy(sizePolicy1);

        horizontalLayout_45->addWidget(pushButton_6);


        verticalLayout_2->addLayout(horizontalLayout_45);

        verticalSpacer = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_2->addItem(verticalSpacer);


        horizontalLayout_43->addLayout(verticalLayout_2);

        line_3 = new QFrame(scrollAreaWidgetContents);
        line_3->setObjectName(QStringLiteral("line_3"));
        line_3->setFrameShadow(QFrame::Plain);
        line_3->setFrameShape(QFrame::VLine);

        horizontalLayout_43->addWidget(line_3);

        verticalLayout_3 = new QVBoxLayout();
        verticalLayout_3->setObjectName(QStringLiteral("verticalLayout_3"));
        label_27 = new QLabel(scrollAreaWidgetContents);
        label_27->setObjectName(QStringLiteral("label_27"));

        verticalLayout_3->addWidget(label_27);

        horizontalLayout_26 = new QHBoxLayout();
        horizontalLayout_26->setObjectName(QStringLiteral("horizontalLayout_26"));
        checkBox_3 = new QCheckBox(scrollAreaWidgetContents);
        checkBox_3->setObjectName(QStringLiteral("checkBox_3"));

        horizontalLayout_26->addWidget(checkBox_3);

        checkBox_4 = new QCheckBox(scrollAreaWidgetContents);
        checkBox_4->setObjectName(QStringLiteral("checkBox_4"));

        horizontalLayout_26->addWidget(checkBox_4);

        checkBox_5 = new QCheckBox(scrollAreaWidgetContents);
        checkBox_5->setObjectName(QStringLiteral("checkBox_5"));

        horizontalLayout_26->addWidget(checkBox_5);


        verticalLayout_3->addLayout(horizontalLayout_26);

        horizontalLayout_27 = new QHBoxLayout();
        horizontalLayout_27->setObjectName(QStringLiteral("horizontalLayout_27"));
        label_28 = new QLabel(scrollAreaWidgetContents);
        label_28->setObjectName(QStringLiteral("label_28"));

        horizontalLayout_27->addWidget(label_28);

        spinBox_6 = new QSpinBox(scrollAreaWidgetContents);
        spinBox_6->setObjectName(QStringLiteral("spinBox_6"));
        sizePolicy1.setHeightForWidth(spinBox_6->sizePolicy().hasHeightForWidth());
        spinBox_6->setSizePolicy(sizePolicy1);
        spinBox_6->setMinimum(1);
        spinBox_6->setMaximum(9999);

        horizontalLayout_27->addWidget(spinBox_6);


        verticalLayout_3->addLayout(horizontalLayout_27);

        horizontalLayout_28 = new QHBoxLayout();
        horizontalLayout_28->setObjectName(QStringLiteral("horizontalLayout_28"));
        label_29 = new QLabel(scrollAreaWidgetContents);
        label_29->setObjectName(QStringLiteral("label_29"));

        horizontalLayout_28->addWidget(label_29);

        doubleSpinBox_20 = new QDoubleSpinBox(scrollAreaWidgetContents);
        doubleSpinBox_20->setObjectName(QStringLiteral("doubleSpinBox_20"));
        sizePolicy1.setHeightForWidth(doubleSpinBox_20->sizePolicy().hasHeightForWidth());
        doubleSpinBox_20->setSizePolicy(sizePolicy1);
        doubleSpinBox_20->setDecimals(3);

        horizontalLayout_28->addWidget(doubleSpinBox_20);

        label_30 = new QLabel(scrollAreaWidgetContents);
        label_30->setObjectName(QStringLiteral("label_30"));

        horizontalLayout_28->addWidget(label_30);

        doubleSpinBox_21 = new QDoubleSpinBox(scrollAreaWidgetContents);
        doubleSpinBox_21->setObjectName(QStringLiteral("doubleSpinBox_21"));
        sizePolicy1.setHeightForWidth(doubleSpinBox_21->sizePolicy().hasHeightForWidth());
        doubleSpinBox_21->setSizePolicy(sizePolicy1);
        doubleSpinBox_21->setDecimals(3);

        horizontalLayout_28->addWidget(doubleSpinBox_21);


        verticalLayout_3->addLayout(horizontalLayout_28);

        horizontalLayout_30 = new QHBoxLayout();
        horizontalLayout_30->setObjectName(QStringLiteral("horizontalLayout_30"));
        label_32 = new QLabel(scrollAreaWidgetContents);
        label_32->setObjectName(QStringLiteral("label_32"));

        horizontalLayout_30->addWidget(label_32);

        doubleSpinBox_23 = new QDoubleSpinBox(scrollAreaWidgetContents);
        doubleSpinBox_23->setObjectName(QStringLiteral("doubleSpinBox_23"));
        doubleSpinBox_23->setEnabled(false);
        sizePolicy1.setHeightForWidth(doubleSpinBox_23->sizePolicy().hasHeightForWidth());
        doubleSpinBox_23->setSizePolicy(sizePolicy1);
        doubleSpinBox_23->setFrame(false);
        doubleSpinBox_23->setKeyboardTracking(true);

        horizontalLayout_30->addWidget(doubleSpinBox_23);


        verticalLayout_3->addLayout(horizontalLayout_30);

        horizontalLayout_29 = new QHBoxLayout();
        horizontalLayout_29->setObjectName(QStringLiteral("horizontalLayout_29"));
        pushButton_2 = new QPushButton(scrollAreaWidgetContents);
        pushButton_2->setObjectName(QStringLiteral("pushButton_2"));
        sizePolicy1.setHeightForWidth(pushButton_2->sizePolicy().hasHeightForWidth());
        pushButton_2->setSizePolicy(sizePolicy1);

        horizontalLayout_29->addWidget(pushButton_2);

        label_31 = new QLabel(scrollAreaWidgetContents);
        label_31->setObjectName(QStringLiteral("label_31"));

        horizontalLayout_29->addWidget(label_31);

        doubleSpinBox_22 = new QDoubleSpinBox(scrollAreaWidgetContents);
        doubleSpinBox_22->setObjectName(QStringLiteral("doubleSpinBox_22"));
        doubleSpinBox_22->setEnabled(false);
        sizePolicy1.setHeightForWidth(doubleSpinBox_22->sizePolicy().hasHeightForWidth());
        doubleSpinBox_22->setSizePolicy(sizePolicy1);
        doubleSpinBox_22->setDecimals(2);
        doubleSpinBox_22->setMaximum(100);

        horizontalLayout_29->addWidget(doubleSpinBox_22);


        verticalLayout_3->addLayout(horizontalLayout_29);

        line_4 = new QFrame(scrollAreaWidgetContents);
        line_4->setObjectName(QStringLiteral("line_4"));
        line_4->setFrameShadow(QFrame::Plain);
        line_4->setFrameShape(QFrame::HLine);

        verticalLayout_3->addWidget(line_4);

        label_33 = new QLabel(scrollAreaWidgetContents);
        label_33->setObjectName(QStringLiteral("label_33"));

        verticalLayout_3->addWidget(label_33);

        horizontalLayout_31 = new QHBoxLayout();
        horizontalLayout_31->setObjectName(QStringLiteral("horizontalLayout_31"));
        label_34 = new QLabel(scrollAreaWidgetContents);
        label_34->setObjectName(QStringLiteral("label_34"));

        horizontalLayout_31->addWidget(label_34);

        spinBox_7 = new QSpinBox(scrollAreaWidgetContents);
        spinBox_7->setObjectName(QStringLiteral("spinBox_7"));
        sizePolicy1.setHeightForWidth(spinBox_7->sizePolicy().hasHeightForWidth());
        spinBox_7->setSizePolicy(sizePolicy1);

        horizontalLayout_31->addWidget(spinBox_7);


        verticalLayout_3->addLayout(horizontalLayout_31);

        horizontalLayout_32 = new QHBoxLayout();
        horizontalLayout_32->setObjectName(QStringLiteral("horizontalLayout_32"));
        label_35 = new QLabel(scrollAreaWidgetContents);
        label_35->setObjectName(QStringLiteral("label_35"));

        horizontalLayout_32->addWidget(label_35);

        spinBox_8 = new QSpinBox(scrollAreaWidgetContents);
        spinBox_8->setObjectName(QStringLiteral("spinBox_8"));
        sizePolicy1.setHeightForWidth(spinBox_8->sizePolicy().hasHeightForWidth());
        spinBox_8->setSizePolicy(sizePolicy1);

        horizontalLayout_32->addWidget(spinBox_8);


        verticalLayout_3->addLayout(horizontalLayout_32);

        horizontalLayout_33 = new QHBoxLayout();
        horizontalLayout_33->setObjectName(QStringLiteral("horizontalLayout_33"));
        label_36 = new QLabel(scrollAreaWidgetContents);
        label_36->setObjectName(QStringLiteral("label_36"));

        horizontalLayout_33->addWidget(label_36);

        spinBox_9 = new QSpinBox(scrollAreaWidgetContents);
        spinBox_9->setObjectName(QStringLiteral("spinBox_9"));
        sizePolicy1.setHeightForWidth(spinBox_9->sizePolicy().hasHeightForWidth());
        spinBox_9->setSizePolicy(sizePolicy1);

        horizontalLayout_33->addWidget(spinBox_9);


        verticalLayout_3->addLayout(horizontalLayout_33);

        horizontalLayout_34 = new QHBoxLayout();
        horizontalLayout_34->setObjectName(QStringLiteral("horizontalLayout_34"));
        label_37 = new QLabel(scrollAreaWidgetContents);
        label_37->setObjectName(QStringLiteral("label_37"));

        horizontalLayout_34->addWidget(label_37);

        spinBox_10 = new QSpinBox(scrollAreaWidgetContents);
        spinBox_10->setObjectName(QStringLiteral("spinBox_10"));
        sizePolicy1.setHeightForWidth(spinBox_10->sizePolicy().hasHeightForWidth());
        spinBox_10->setSizePolicy(sizePolicy1);

        horizontalLayout_34->addWidget(spinBox_10);


        verticalLayout_3->addLayout(horizontalLayout_34);

        horizontalLayout_35 = new QHBoxLayout();
        horizontalLayout_35->setObjectName(QStringLiteral("horizontalLayout_35"));
        label_38 = new QLabel(scrollAreaWidgetContents);
        label_38->setObjectName(QStringLiteral("label_38"));

        horizontalLayout_35->addWidget(label_38);

        spinBox_11 = new QSpinBox(scrollAreaWidgetContents);
        spinBox_11->setObjectName(QStringLiteral("spinBox_11"));
        sizePolicy1.setHeightForWidth(spinBox_11->sizePolicy().hasHeightForWidth());
        spinBox_11->setSizePolicy(sizePolicy1);

        horizontalLayout_35->addWidget(spinBox_11);


        verticalLayout_3->addLayout(horizontalLayout_35);

        label_39 = new QLabel(scrollAreaWidgetContents);
        label_39->setObjectName(QStringLiteral("label_39"));

        verticalLayout_3->addWidget(label_39);

        horizontalLayout_36 = new QHBoxLayout();
        horizontalLayout_36->setObjectName(QStringLiteral("horizontalLayout_36"));
        label_40 = new QLabel(scrollAreaWidgetContents);
        label_40->setObjectName(QStringLiteral("label_40"));

        horizontalLayout_36->addWidget(label_40);

        doubleSpinBox_24 = new QDoubleSpinBox(scrollAreaWidgetContents);
        doubleSpinBox_24->setObjectName(QStringLiteral("doubleSpinBox_24"));
        sizePolicy1.setHeightForWidth(doubleSpinBox_24->sizePolicy().hasHeightForWidth());
        doubleSpinBox_24->setSizePolicy(sizePolicy1);
        doubleSpinBox_24->setMaximum(99991);

        horizontalLayout_36->addWidget(doubleSpinBox_24);


        verticalLayout_3->addLayout(horizontalLayout_36);

        horizontalLayout_37 = new QHBoxLayout();
        horizontalLayout_37->setObjectName(QStringLiteral("horizontalLayout_37"));
        label_41 = new QLabel(scrollAreaWidgetContents);
        label_41->setObjectName(QStringLiteral("label_41"));

        horizontalLayout_37->addWidget(label_41);

        doubleSpinBox_25 = new QDoubleSpinBox(scrollAreaWidgetContents);
        doubleSpinBox_25->setObjectName(QStringLiteral("doubleSpinBox_25"));
        doubleSpinBox_25->setEnabled(false);
        sizePolicy1.setHeightForWidth(doubleSpinBox_25->sizePolicy().hasHeightForWidth());
        doubleSpinBox_25->setSizePolicy(sizePolicy1);
        doubleSpinBox_25->setMinimum(-99);

        horizontalLayout_37->addWidget(doubleSpinBox_25);


        verticalLayout_3->addLayout(horizontalLayout_37);

        horizontalLayout_38 = new QHBoxLayout();
        horizontalLayout_38->setObjectName(QStringLiteral("horizontalLayout_38"));
        label_42 = new QLabel(scrollAreaWidgetContents);
        label_42->setObjectName(QStringLiteral("label_42"));

        horizontalLayout_38->addWidget(label_42);

        doubleSpinBox_26 = new QDoubleSpinBox(scrollAreaWidgetContents);
        doubleSpinBox_26->setObjectName(QStringLiteral("doubleSpinBox_26"));
        sizePolicy1.setHeightForWidth(doubleSpinBox_26->sizePolicy().hasHeightForWidth());
        doubleSpinBox_26->setSizePolicy(sizePolicy1);
        doubleSpinBox_26->setMinimum(-2);

        horizontalLayout_38->addWidget(doubleSpinBox_26);


        verticalLayout_3->addLayout(horizontalLayout_38);

        horizontalLayout_39 = new QHBoxLayout();
        horizontalLayout_39->setObjectName(QStringLiteral("horizontalLayout_39"));
        label_43 = new QLabel(scrollAreaWidgetContents);
        label_43->setObjectName(QStringLiteral("label_43"));

        horizontalLayout_39->addWidget(label_43);

        doubleSpinBox_27 = new QDoubleSpinBox(scrollAreaWidgetContents);
        doubleSpinBox_27->setObjectName(QStringLiteral("doubleSpinBox_27"));
        sizePolicy1.setHeightForWidth(doubleSpinBox_27->sizePolicy().hasHeightForWidth());
        doubleSpinBox_27->setSizePolicy(sizePolicy1);
        doubleSpinBox_27->setMaximum(90);

        horizontalLayout_39->addWidget(doubleSpinBox_27);


        verticalLayout_3->addLayout(horizontalLayout_39);

        horizontalLayout_40 = new QHBoxLayout();
        horizontalLayout_40->setObjectName(QStringLiteral("horizontalLayout_40"));
        label_44 = new QLabel(scrollAreaWidgetContents);
        label_44->setObjectName(QStringLiteral("label_44"));

        horizontalLayout_40->addWidget(label_44);

        doubleSpinBox_28 = new QDoubleSpinBox(scrollAreaWidgetContents);
        doubleSpinBox_28->setObjectName(QStringLiteral("doubleSpinBox_28"));
        sizePolicy1.setHeightForWidth(doubleSpinBox_28->sizePolicy().hasHeightForWidth());
        doubleSpinBox_28->setSizePolicy(sizePolicy1);
        doubleSpinBox_28->setMaximum(999.99);

        horizontalLayout_40->addWidget(doubleSpinBox_28);


        verticalLayout_3->addLayout(horizontalLayout_40);


        horizontalLayout_43->addLayout(verticalLayout_3);

        line_5 = new QFrame(scrollAreaWidgetContents);
        line_5->setObjectName(QStringLiteral("line_5"));
        line_5->setFrameShadow(QFrame::Plain);
        line_5->setFrameShape(QFrame::VLine);

        horizontalLayout_43->addWidget(line_5);

        verticalLayout_4 = new QVBoxLayout();
        verticalLayout_4->setObjectName(QStringLiteral("verticalLayout_4"));
        label_46 = new QLabel(scrollAreaWidgetContents);
        label_46->setObjectName(QStringLiteral("label_46"));

        verticalLayout_4->addWidget(label_46);

        customPlot = new QCustomPlot(scrollAreaWidgetContents);
        customPlot->setObjectName(QStringLiteral("customPlot"));
        sizePolicy.setHeightForWidth(customPlot->sizePolicy().hasHeightForWidth());
        customPlot->setSizePolicy(sizePolicy);
        customPlot->setMinimumSize(QSize(400, 300));

        verticalLayout_4->addWidget(customPlot);

        label_47 = new QLabel(scrollAreaWidgetContents);
        label_47->setObjectName(QStringLiteral("label_47"));

        verticalLayout_4->addWidget(label_47);

        customPlot_2 = new QCustomPlot(scrollAreaWidgetContents);
        customPlot_2->setObjectName(QStringLiteral("customPlot_2"));
        sizePolicy.setHeightForWidth(customPlot_2->sizePolicy().hasHeightForWidth());
        customPlot_2->setSizePolicy(sizePolicy);
        customPlot_2->setMinimumSize(QSize(400, 300));

        verticalLayout_4->addWidget(customPlot_2);


        horizontalLayout_43->addLayout(verticalLayout_4);

        scrollArea->setWidget(scrollAreaWidgetContents);

        gridLayout->addWidget(scrollArea, 0, 0, 1, 1);


        retranslateUi(threed);
        QObject::connect(pushButton, SIGNAL(clicked()), threed, SLOT(close()));

        QMetaObject::connectSlotsByName(threed);
    } // setupUi

    void retranslateUi(QDialog *threed)
    {
        threed->setWindowTitle(QApplication::translate("threed", "Dialog", Q_NULLPTR));
        label->setText(QApplication::translate("threed", "<html><head/><body><p><span style=\" font-size:12pt; font-weight:600;\">Optical &amp; Geometrical Data</span></p></body></html>", Q_NULLPTR));
        checkBox->setText(QApplication::translate("threed", "Grating", Q_NULLPTR));
        checkBox_2->setText(QApplication::translate("threed", "VPH Grating", Q_NULLPTR));
        label_2->setText(QApplication::translate("threed", "<html><head/><body><p>Grating Line Density [l/mm]:</p></body></html>", Q_NULLPTR));
        label_3->setText(QApplication::translate("threed", "Diffraction Order:", Q_NULLPTR));
        label_7->setText(QApplication::translate("threed", "<html><head/><body><p>Total Angle [deg]:</p></body></html>", Q_NULLPTR));
        label_4->setText(QApplication::translate("threed", "<html><head/><body><p>Blaze Angle [deg]:</p></body></html>", Q_NULLPTR));
        label_5->setText(QApplication::translate("threed", "Blaze Efficiency:", Q_NULLPTR));
        label_6->setText(QApplication::translate("threed", "<html><head/><body><p>Central Wavelength [nm]:</p></body></html>", Q_NULLPTR));
        label_8->setText(QApplication::translate("threed", "Index DCG Layer:", Q_NULLPTR));
        label_9->setText(QApplication::translate("threed", "Semiamplitude of Modulation:", Q_NULLPTR));
        label_10->setText(QApplication::translate("threed", "<html><head/><body><p>Thickness of DCG Layer [mm]:</p></body></html>", Q_NULLPTR));
        label_11->setText(QApplication::translate("threed", "<html><head/><body><p>Focal Length Collimator [mm]:</p></body></html>", Q_NULLPTR));
        label_12->setText(QApplication::translate("threed", "<html><head/><body><p>Focal Length Camera [mm]:</p></body></html>", Q_NULLPTR));
        label_45->setText(QApplication::translate("threed", "<html><head/><body><p>Tune Wavelength [nm]:</p></body></html>", Q_NULLPTR));
        pushButton_3->setText(QApplication::translate("threed", "Parameters", Q_NULLPTR));
        pushButton_4->setText(QApplication::translate("threed", "Frame", Q_NULLPTR));
        label_50->setText(QApplication::translate("threed", "Work Path:", Q_NULLPTR));
        pushButton->setText(QApplication::translate("threed", "Close", Q_NULLPTR));
        label_13->setText(QApplication::translate("threed", "<html><head/><body><p><span style=\" font-size:12pt; font-weight:600;\">Telescope &amp; CCD Data</span></p></body></html>", Q_NULLPTR));
        label_14->setText(QApplication::translate("threed", "<html><head/><body><p>Seeing [arcsec]:</p></body></html>", Q_NULLPTR));
        label_15->setText(QApplication::translate("threed", "<html><head/><body><p>Telescope Focal Length [mm]:</p></body></html>", Q_NULLPTR));
        label_16->setText(QApplication::translate("threed", "<html><head/><body><p>Telescope Diameter [mm]:</p></body></html>", Q_NULLPTR));
        label_17->setText(QApplication::translate("threed", "<html><head/><body><p>Pixel Size [mm]:</p></body></html>", Q_NULLPTR));
        label_18->setText(QApplication::translate("threed", "Pixel in x:", Q_NULLPTR));
        label_19->setText(QApplication::translate("threed", "Pixel in y:", Q_NULLPTR));
        label_20->setText(QApplication::translate("threed", "Binning x:", Q_NULLPTR));
        label_21->setText(QApplication::translate("threed", "Binning y:", Q_NULLPTR));
        label_22->setText(QApplication::translate("threed", "<html><head/><body><p>CCD Bias [ADU]:</p></body></html>", Q_NULLPTR));
        label_23->setText(QApplication::translate("threed", "<html><head/><body><p>CCD Noise [ADU]:</p></body></html>", Q_NULLPTR));
        label_24->setText(QApplication::translate("threed", "<html><head/><body><p>CCD Gain [e/ADU]:</p></body></html>", Q_NULLPTR));
        label_25->setText(QApplication::translate("threed", "<html><head/><body><p>CCD Peak Wavelength [nm]:</p></body></html>", Q_NULLPTR));
        label_26->setText(QApplication::translate("threed", "CCD Peak Efficiency:", Q_NULLPTR));
        label_48->setText(QApplication::translate("threed", ".dconf", Q_NULLPTR));
        pushButton_5->setText(QApplication::translate("threed", "Save", Q_NULLPTR));
        label_49->setText(QApplication::translate("threed", ".dconf", Q_NULLPTR));
        pushButton_6->setText(QApplication::translate("threed", "Load", Q_NULLPTR));
        label_27->setText(QApplication::translate("threed", "<html><head/><body><p><span style=\" font-size:12pt; font-weight:600;\">Slit</span></p></body></html>", Q_NULLPTR));
        checkBox_3->setText(QApplication::translate("threed", "circular", Q_NULLPTR));
        checkBox_4->setText(QApplication::translate("threed", "rectangular", Q_NULLPTR));
        checkBox_5->setText(QApplication::translate("threed", "slitless", Q_NULLPTR));
        label_28->setText(QApplication::translate("threed", "# Slitlets:", Q_NULLPTR));
        label_29->setText(QApplication::translate("threed", "<html><head/><body><p>Width:</p></body></html>", Q_NULLPTR));
        label_30->setText(QApplication::translate("threed", "<html><head/><body><p>Length [mm]:</p></body></html>", Q_NULLPTR));
        label_32->setText(QApplication::translate("threed", "<html><head/><body><p>Width on Sky [arcsec]:</p></body></html>", Q_NULLPTR));
        pushButton_2->setText(QApplication::translate("threed", "Calculate", Q_NULLPTR));
        label_31->setText(QApplication::translate("threed", "<html><head/><body><p>Efficiency [%]:</p></body></html>", Q_NULLPTR));
        label_33->setText(QApplication::translate("threed", "<html><head/><body><p><span style=\" font-size:12pt; font-weight:600;\">Optical Surfaces</span></p></body></html>", Q_NULLPTR));
        label_34->setText(QApplication::translate("threed", "# Silver Surfaces:", Q_NULLPTR));
        label_35->setText(QApplication::translate("threed", "# Aluminium Surfaces:", Q_NULLPTR));
        label_36->setText(QApplication::translate("threed", "# Aluminium UV Surfaces:", Q_NULLPTR));
        label_37->setText(QApplication::translate("threed", "# Gold Surfaces:", Q_NULLPTR));
        label_38->setText(QApplication::translate("threed", "# VIS AR Surfaces:", Q_NULLPTR));
        label_39->setText(QApplication::translate("threed", "<html><head/><body><p><span style=\" font-size:12pt; font-weight:600;\">Object Data</span></p></body></html>", Q_NULLPTR));
        label_40->setText(QApplication::translate("threed", "<html><head/><body><p>Effective Temperature [K]:</p></body></html>", Q_NULLPTR));
        label_41->setText(QApplication::translate("threed", "<html><head/><body><p>BC [mag]:</p></body></html>", Q_NULLPTR));
        label_42->setText(QApplication::translate("threed", "<html><head/><body><p>Magnitude [mag]:</p></body></html>", Q_NULLPTR));
        label_43->setText(QApplication::translate("threed", "<html><head/><body><p>Zenith Distance [deg]:</p></body></html>", Q_NULLPTR));
        label_44->setText(QApplication::translate("threed", "<html><head/><body><p>Exposure Time [s]:</p></body></html>", Q_NULLPTR));
        label_46->setText(QApplication::translate("threed", "<html><head/><body><p><span style=\" font-size:12pt; font-weight:600;\">Frame</span></p></body></html>", Q_NULLPTR));
        label_47->setText(QApplication::translate("threed", "<html><head/><body><p><span style=\" font-size:12pt; font-weight:600;\">Single Spectrum</span></p></body></html>", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class threed: public Ui_threed {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_THREED_H
