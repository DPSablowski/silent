/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.8.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDoubleSpinBox>
#include <QtWidgets/QFrame>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenu>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QProgressBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QScrollArea>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QSpinBox>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTableWidget>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>
#include "qcustomplot.h"

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QAction *actionParameters;
    QAction *actionClassical;
    QAction *action3D_Spectrograph;
    QAction *actionClassical_2;
    QAction *action3D;
    QAction *action3D_Frame;
    QAction *actionEchelle_Frame;
    QAction *actionAbout;
    QAction *actionBug_Report;
    QAction *actionManual;
    QAction *actionBasics;
    QAction *actionVPHG;
    QAction *actionOptical_Fibres;
    QAction *actionClassical_Frame;
    QAction *actionTSI;
    QAction *actionNotes;
    QAction *actionNew;
    QAction *actionOpen;
    QAction *actionSave;
    QAction *actionSave_AS;
    QAction *actionUndo;
    QAction *actionRedo;
    QAction *actionFPE;
    QAction *actionCzerny_Turner;
    QAction *actionPetzval;
    QWidget *centralWidget;
    QGridLayout *gridLayout;
    QScrollArea *scrollArea;
    QWidget *scrollAreaWidgetContents;
    QHBoxLayout *horizontalLayout_61;
    QVBoxLayout *verticalLayout_7;
    QVBoxLayout *verticalLayout_6;
    QLabel *label;
    QHBoxLayout *horizontalLayout_2;
    QLabel *label_10;
    QDoubleSpinBox *doubleSpinBox_22;
    QHBoxLayout *horizontalLayout_52;
    QLabel *label_58;
    QDoubleSpinBox *doubleSpinBox_5;
    QHBoxLayout *horizontalLayout_3;
    QLabel *label_16;
    QDoubleSpinBox *doubleSpinBox_23;
    QHBoxLayout *horizontalLayout_4;
    QLabel *label_13;
    QDoubleSpinBox *doubleSpinBox_24;
    QHBoxLayout *horizontalLayout_26;
    QLabel *label_33;
    QDoubleSpinBox *doubleSpinBox;
    QLabel *label_34;
    QDoubleSpinBox *doubleSpinBox_2;
    QHBoxLayout *horizontalLayout_6;
    QLabel *label_11;
    QDoubleSpinBox *doubleSpinBox_25;
    QHBoxLayout *horizontalLayout_7;
    QLabel *label_12;
    QDoubleSpinBox *doubleSpinBox_26;
    QHBoxLayout *horizontalLayout_76;
    QCheckBox *checkBox_2;
    QCheckBox *checkBox_3;
    QHBoxLayout *horizontalLayout_75;
    QLabel *label_75;
    QDoubleSpinBox *doubleSpinBox_37;
    QHBoxLayout *horizontalLayout_70;
    QLabel *label_71;
    QDoubleSpinBox *doubleSpinBox_32;
    QFrame *line_2;
    QHBoxLayout *horizontalLayout;
    QLabel *label_2;
    QComboBox *comboBox_2;
    QVBoxLayout *verticalLayout_5;
    QHBoxLayout *horizontalLayout_5;
    QLabel *label_27;
    QDoubleSpinBox *doubleSpinBox_27;
    QHBoxLayout *horizontalLayout_24;
    QLabel *label_28;
    QDoubleSpinBox *doubleSpinBox_28;
    QHBoxLayout *horizontalLayout_53;
    QLabel *label_59;
    QDoubleSpinBox *doubleSpinBox_6;
    QHBoxLayout *horizontalLayout_54;
    QLabel *label_60;
    QDoubleSpinBox *doubleSpinBox_7;
    QHBoxLayout *horizontalLayout_63;
    QLabel *label_67;
    QDoubleSpinBox *doubleSpinBox_18;
    QHBoxLayout *horizontalLayout_65;
    QLabel *label_69;
    QDoubleSpinBox *doubleSpinBox_19;
    QHBoxLayout *horizontalLayout_66;
    QLabel *label_68;
    QDoubleSpinBox *doubleSpinBox_20;
    QHBoxLayout *horizontalLayout_64;
    QLabel *label_70;
    QDoubleSpinBox *doubleSpinBox_21;
    QHBoxLayout *horizontalLayout_25;
    QLabel *label_14;
    QComboBox *comboBox;
    QHBoxLayout *horizontalLayout_67;
    QLabel *label_35;
    QDoubleSpinBox *doubleSpinBox_36;
    QFrame *line_8;
    QSpacerItem *verticalSpacer_3;
    QHBoxLayout *horizontalLayout_71;
    QLabel *label_72;
    QLineEdit *lineEdit_3;
    QPushButton *pushButton_8;
    QHBoxLayout *horizontalLayout_69;
    QLabel *label_41;
    QLineEdit *lineEdit_2;
    QHBoxLayout *horizontalLayout_74;
    QPushButton *pushButton_10;
    QLineEdit *lineEdit_5;
    QHBoxLayout *horizontalLayout_13;
    QPushButton *pushButton;
    QFrame *line_3;
    QVBoxLayout *verticalLayout_2;
    QLabel *label_3;
    QHBoxLayout *horizontalLayout_12;
    QLabel *label_5;
    QSpinBox *spinBox;
    QHBoxLayout *horizontalLayout_11;
    QLabel *label_6;
    QSpinBox *spinBox_2;
    QHBoxLayout *horizontalLayout_59;
    QLabel *label_65;
    QSpinBox *spinBox_7;
    QHBoxLayout *horizontalLayout_60;
    QLabel *label_66;
    QSpinBox *spinBox_8;
    QHBoxLayout *horizontalLayout_10;
    QLabel *label_8;
    QSpinBox *spinBox_3;
    QHBoxLayout *horizontalLayout_9;
    QCheckBox *checkBox_11;
    QLineEdit *lineEdit;
    QHBoxLayout *horizontalLayout_30;
    QLabel *label_7;
    QSpinBox *spinBox_6;
    QTableWidget *tableWidget;
    QHBoxLayout *horizontalLayout_31;
    QPushButton *pushButton_2;
    QDoubleSpinBox *doubleSpinBox_13;
    QLabel *label_29;
    QHBoxLayout *horizontalLayout_29;
    QLabel *label_30;
    QDoubleSpinBox *doubleSpinBox_9;
    QHBoxLayout *horizontalLayout_57;
    QLabel *label_38;
    QDoubleSpinBox *doubleSpinBox_11;
    QHBoxLayout *horizontalLayout_28;
    QLabel *label_31;
    QDoubleSpinBox *doubleSpinBox_10;
    QHBoxLayout *horizontalLayout_27;
    QLabel *label_32;
    QDoubleSpinBox *doubleSpinBox_12;
    QHBoxLayout *horizontalLayout_55;
    QLabel *label_61;
    QDoubleSpinBox *doubleSpinBox_8;
    QFrame *line_4;
    QVBoxLayout *verticalLayout;
    QLabel *label_4;
    QHBoxLayout *horizontalLayout_23;
    QLabel *label_17;
    QDoubleSpinBox *doubleSpinBox_29;
    QHBoxLayout *horizontalLayout_22;
    QLabel *label_21;
    QDoubleSpinBox *doubleSpinBox_35;
    QHBoxLayout *horizontalLayout_21;
    QLabel *label_22;
    QDoubleSpinBox *doubleSpinBox_34;
    QFrame *line_5;
    QHBoxLayout *horizontalLayout_34;
    QLabel *label_15;
    QCheckBox *checkBox_8;
    QCheckBox *checkBox_9;
    QCheckBox *checkBox;
    QHBoxLayout *horizontalLayout_8;
    QDoubleSpinBox *doubleSpinBox_14;
    QLabel *label_40;
    QDoubleSpinBox *doubleSpinBox_15;
    QLabel *label_39;
    QHBoxLayout *horizontalLayout_35;
    QPushButton *pushButton_3;
    QDoubleSpinBox *doubleSpinBox_30;
    QHBoxLayout *horizontalLayout_51;
    QLabel *label_56;
    QDoubleSpinBox *doubleSpinBox_31;
    QFrame *line;
    QHBoxLayout *horizontalLayout_72;
    QLabel *label_73;
    QComboBox *comboBox_4;
    QHBoxLayout *horizontalLayout_20;
    QLabel *label_18;
    QDoubleSpinBox *doubleSpinBox_33;
    QHBoxLayout *horizontalLayout_19;
    QLabel *label_19;
    QSpinBox *spinBox_10;
    QHBoxLayout *horizontalLayout_18;
    QLabel *label_20;
    QSpinBox *spinBox_11;
    QHBoxLayout *horizontalLayout_17;
    QLabel *label_23;
    QSpinBox *spinBox_4;
    QHBoxLayout *horizontalLayout_16;
    QLabel *label_24;
    QSpinBox *spinBox_5;
    QHBoxLayout *horizontalLayout_15;
    QLabel *label_25;
    QSpinBox *spinBox_9;
    QHBoxLayout *horizontalLayout_14;
    QLabel *label_26;
    QDoubleSpinBox *doubleSpinBox_17;
    QHBoxLayout *horizontalLayout_32;
    QLabel *label_36;
    QDoubleSpinBox *doubleSpinBox_4;
    QHBoxLayout *horizontalLayout_33;
    QLabel *label_37;
    QDoubleSpinBox *doubleSpinBox_3;
    QHBoxLayout *horizontalLayout_36;
    QLabel *label_57;
    QDoubleSpinBox *doubleSpinBox_16;
    QHBoxLayout *horizontalLayout_73;
    QLabel *label_74;
    QLineEdit *lineEdit_4;
    QPushButton *pushButton_9;
    QProgressBar *progressBar;
    QSpacerItem *verticalSpacer;
    QFrame *line_6;
    QVBoxLayout *verticalLayout_4;
    QLabel *label_44;
    QHBoxLayout *horizontalLayout_37;
    QLabel *label_45;
    QLineEdit *lineEdit_25;
    QHBoxLayout *horizontalLayout_45;
    QLabel *label_46;
    QLineEdit *lineEdit_26;
    QHBoxLayout *horizontalLayout_44;
    QLabel *label_47;
    QLineEdit *lineEdit_27;
    QHBoxLayout *horizontalLayout_43;
    QLabel *label_48;
    QLineEdit *lineEdit_28;
    QHBoxLayout *horizontalLayout_42;
    QLabel *label_49;
    QLineEdit *lineEdit_29;
    QHBoxLayout *horizontalLayout_41;
    QLabel *label_50;
    QLineEdit *lineEdit_30;
    QHBoxLayout *horizontalLayout_40;
    QLabel *label_51;
    QLineEdit *lineEdit_31;
    QHBoxLayout *horizontalLayout_39;
    QLabel *label_52;
    QLineEdit *lineEdit_32;
    QHBoxLayout *horizontalLayout_38;
    QLabel *label_53;
    QLineEdit *lineEdit_33;
    QHBoxLayout *horizontalLayout_47;
    QPushButton *pushButton_4;
    QPushButton *pushButton_5;
    QPushButton *pushButton_6;
    QHBoxLayout *horizontalLayout_49;
    QLabel *label_54;
    QLineEdit *lineEdit_34;
    QHBoxLayout *horizontalLayout_50;
    QLabel *label_55;
    QLineEdit *lineEdit_35;
    QHBoxLayout *horizontalLayout_56;
    QLabel *label_62;
    QLineEdit *lineEdit_37;
    QHBoxLayout *horizontalLayout_68;
    QComboBox *comboBox_3;
    QPushButton *pushButton_7;
    QCustomPlot *customPlot;
    QFrame *line_7;
    QVBoxLayout *verticalLayout_3;
    QLabel *label_42;
    QHBoxLayout *horizontalLayout_46;
    QLabel *label_43;
    QSpacerItem *horizontalSpacer;
    QCustomPlot *customPlot_3;
    QHBoxLayout *horizontalLayout_48;
    QLabel *label_63;
    QSpacerItem *horizontalSpacer_2;
    QCustomPlot *customPlot_4;
    QHBoxLayout *horizontalLayout_58;
    QLabel *label_64;
    QSpacerItem *horizontalSpacer_3;
    QCustomPlot *customPlot_5;
    QHBoxLayout *horizontalLayout_62;
    QLabel *label_9;
    QSpacerItem *horizontalSpacer_4;
    QCustomPlot *customPlot_2;
    QMenuBar *menuBar;
    QMenu *menuClassical;
    QMenu *menuTools;
    QMenu *menuFrame;
    QMenu *menuHelp;
    QMenu *menuTools_2;
    QMenu *menuFile;
    QMenu *menuEdit;
    QToolBar *mainToolBar;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QStringLiteral("MainWindow"));
        MainWindow->resize(1612, 883);
        QPalette palette;
        QBrush brush(QColor(102, 21, 21, 255));
        brush.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::WindowText, brush);
        QBrush brush1(QColor(84, 176, 196, 255));
        brush1.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::Button, brush1);
        QBrush brush2(QColor(148, 236, 255, 255));
        brush2.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::Light, brush2);
        QBrush brush3(QColor(116, 206, 225, 255));
        brush3.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::Midlight, brush3);
        QBrush brush4(QColor(42, 88, 98, 255));
        brush4.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::Dark, brush4);
        QBrush brush5(QColor(56, 117, 131, 255));
        brush5.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::Mid, brush5);
        QBrush brush6(QColor(0, 0, 0, 255));
        brush6.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::Text, brush6);
        QBrush brush7(QColor(255, 255, 255, 255));
        brush7.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::BrightText, brush7);
        palette.setBrush(QPalette::Active, QPalette::ButtonText, brush6);
        QBrush brush8(QColor(147, 235, 254, 255));
        brush8.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::Base, brush8);
        palette.setBrush(QPalette::Active, QPalette::Window, brush1);
        palette.setBrush(QPalette::Active, QPalette::Shadow, brush6);
        QBrush brush9(QColor(169, 215, 225, 255));
        brush9.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::AlternateBase, brush9);
        QBrush brush10(QColor(255, 255, 220, 255));
        brush10.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::ToolTipBase, brush10);
        palette.setBrush(QPalette::Active, QPalette::ToolTipText, brush6);
        palette.setBrush(QPalette::Inactive, QPalette::WindowText, brush);
        palette.setBrush(QPalette::Inactive, QPalette::Button, brush1);
        palette.setBrush(QPalette::Inactive, QPalette::Light, brush2);
        palette.setBrush(QPalette::Inactive, QPalette::Midlight, brush3);
        palette.setBrush(QPalette::Inactive, QPalette::Dark, brush4);
        palette.setBrush(QPalette::Inactive, QPalette::Mid, brush5);
        palette.setBrush(QPalette::Inactive, QPalette::Text, brush6);
        palette.setBrush(QPalette::Inactive, QPalette::BrightText, brush7);
        palette.setBrush(QPalette::Inactive, QPalette::ButtonText, brush6);
        palette.setBrush(QPalette::Inactive, QPalette::Base, brush8);
        palette.setBrush(QPalette::Inactive, QPalette::Window, brush1);
        palette.setBrush(QPalette::Inactive, QPalette::Shadow, brush6);
        palette.setBrush(QPalette::Inactive, QPalette::AlternateBase, brush9);
        palette.setBrush(QPalette::Inactive, QPalette::ToolTipBase, brush10);
        palette.setBrush(QPalette::Inactive, QPalette::ToolTipText, brush6);
        palette.setBrush(QPalette::Disabled, QPalette::WindowText, brush4);
        palette.setBrush(QPalette::Disabled, QPalette::Button, brush1);
        palette.setBrush(QPalette::Disabled, QPalette::Light, brush2);
        palette.setBrush(QPalette::Disabled, QPalette::Midlight, brush3);
        palette.setBrush(QPalette::Disabled, QPalette::Dark, brush4);
        palette.setBrush(QPalette::Disabled, QPalette::Mid, brush5);
        palette.setBrush(QPalette::Disabled, QPalette::Text, brush4);
        palette.setBrush(QPalette::Disabled, QPalette::BrightText, brush7);
        palette.setBrush(QPalette::Disabled, QPalette::ButtonText, brush4);
        palette.setBrush(QPalette::Disabled, QPalette::Base, brush1);
        palette.setBrush(QPalette::Disabled, QPalette::Window, brush1);
        palette.setBrush(QPalette::Disabled, QPalette::Shadow, brush6);
        palette.setBrush(QPalette::Disabled, QPalette::AlternateBase, brush1);
        palette.setBrush(QPalette::Disabled, QPalette::ToolTipBase, brush10);
        palette.setBrush(QPalette::Disabled, QPalette::ToolTipText, brush6);
        MainWindow->setPalette(palette);
        QFont font;
        font.setFamily(QStringLiteral("Ubuntu Mono"));
        font.setPointSize(11);
        font.setBold(true);
        font.setItalic(true);
        font.setWeight(75);
        MainWindow->setFont(font);
        QIcon icon;
        icon.addFile(QStringLiteral(":/Images/Icons/ICON.png"), QSize(), QIcon::Normal, QIcon::Off);
        MainWindow->setWindowIcon(icon);
        MainWindow->setAutoFillBackground(false);
        actionParameters = new QAction(MainWindow);
        actionParameters->setObjectName(QStringLiteral("actionParameters"));
        actionClassical = new QAction(MainWindow);
        actionClassical->setObjectName(QStringLiteral("actionClassical"));
        action3D_Spectrograph = new QAction(MainWindow);
        action3D_Spectrograph->setObjectName(QStringLiteral("action3D_Spectrograph"));
        actionClassical_2 = new QAction(MainWindow);
        actionClassical_2->setObjectName(QStringLiteral("actionClassical_2"));
        action3D = new QAction(MainWindow);
        action3D->setObjectName(QStringLiteral("action3D"));
        action3D_Frame = new QAction(MainWindow);
        action3D_Frame->setObjectName(QStringLiteral("action3D_Frame"));
        actionEchelle_Frame = new QAction(MainWindow);
        actionEchelle_Frame->setObjectName(QStringLiteral("actionEchelle_Frame"));
        actionAbout = new QAction(MainWindow);
        actionAbout->setObjectName(QStringLiteral("actionAbout"));
        actionBug_Report = new QAction(MainWindow);
        actionBug_Report->setObjectName(QStringLiteral("actionBug_Report"));
        actionManual = new QAction(MainWindow);
        actionManual->setObjectName(QStringLiteral("actionManual"));
        actionBasics = new QAction(MainWindow);
        actionBasics->setObjectName(QStringLiteral("actionBasics"));
        actionVPHG = new QAction(MainWindow);
        actionVPHG->setObjectName(QStringLiteral("actionVPHG"));
        actionOptical_Fibres = new QAction(MainWindow);
        actionOptical_Fibres->setObjectName(QStringLiteral("actionOptical_Fibres"));
        actionClassical_Frame = new QAction(MainWindow);
        actionClassical_Frame->setObjectName(QStringLiteral("actionClassical_Frame"));
        actionTSI = new QAction(MainWindow);
        actionTSI->setObjectName(QStringLiteral("actionTSI"));
        actionNotes = new QAction(MainWindow);
        actionNotes->setObjectName(QStringLiteral("actionNotes"));
        actionNew = new QAction(MainWindow);
        actionNew->setObjectName(QStringLiteral("actionNew"));
        QIcon icon1;
        icon1.addFile(QStringLiteral(":/Images/Icons/new.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionNew->setIcon(icon1);
        actionOpen = new QAction(MainWindow);
        actionOpen->setObjectName(QStringLiteral("actionOpen"));
        QIcon icon2;
        icon2.addFile(QStringLiteral(":/Images/Icons/open.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionOpen->setIcon(icon2);
        actionSave = new QAction(MainWindow);
        actionSave->setObjectName(QStringLiteral("actionSave"));
        QIcon icon3;
        icon3.addFile(QStringLiteral(":/Images/Icons/Save.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionSave->setIcon(icon3);
        actionSave_AS = new QAction(MainWindow);
        actionSave_AS->setObjectName(QStringLiteral("actionSave_AS"));
        QIcon icon4;
        icon4.addFile(QStringLiteral(":/Images/Icons/saveas.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionSave_AS->setIcon(icon4);
        actionUndo = new QAction(MainWindow);
        actionUndo->setObjectName(QStringLiteral("actionUndo"));
        actionRedo = new QAction(MainWindow);
        actionRedo->setObjectName(QStringLiteral("actionRedo"));
        actionFPE = new QAction(MainWindow);
        actionFPE->setObjectName(QStringLiteral("actionFPE"));
        actionCzerny_Turner = new QAction(MainWindow);
        actionCzerny_Turner->setObjectName(QStringLiteral("actionCzerny_Turner"));
        actionPetzval = new QAction(MainWindow);
        actionPetzval->setObjectName(QStringLiteral("actionPetzval"));
        centralWidget = new QWidget(MainWindow);
        centralWidget->setObjectName(QStringLiteral("centralWidget"));
        gridLayout = new QGridLayout(centralWidget);
        gridLayout->setSpacing(6);
        gridLayout->setContentsMargins(11, 11, 11, 11);
        gridLayout->setObjectName(QStringLiteral("gridLayout"));
        scrollArea = new QScrollArea(centralWidget);
        scrollArea->setObjectName(QStringLiteral("scrollArea"));
        scrollArea->setFrameShape(QFrame::NoFrame);
        scrollArea->setLineWidth(0);
        scrollArea->setWidgetResizable(true);
        scrollAreaWidgetContents = new QWidget();
        scrollAreaWidgetContents->setObjectName(QStringLiteral("scrollAreaWidgetContents"));
        scrollAreaWidgetContents->setGeometry(QRect(0, 0, 1580, 855));
        horizontalLayout_61 = new QHBoxLayout(scrollAreaWidgetContents);
        horizontalLayout_61->setSpacing(6);
        horizontalLayout_61->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_61->setObjectName(QStringLiteral("horizontalLayout_61"));
        verticalLayout_7 = new QVBoxLayout();
        verticalLayout_7->setSpacing(6);
        verticalLayout_7->setObjectName(QStringLiteral("verticalLayout_7"));
        verticalLayout_6 = new QVBoxLayout();
        verticalLayout_6->setSpacing(6);
        verticalLayout_6->setObjectName(QStringLiteral("verticalLayout_6"));
        label = new QLabel(scrollAreaWidgetContents);
        label->setObjectName(QStringLiteral("label"));
        QFont font1;
        font1.setPointSize(14);
        font1.setItalic(false);
        label->setFont(font1);

        verticalLayout_6->addWidget(label);

        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setSpacing(6);
        horizontalLayout_2->setObjectName(QStringLiteral("horizontalLayout_2"));
        label_10 = new QLabel(scrollAreaWidgetContents);
        label_10->setObjectName(QStringLiteral("label_10"));
        QSizePolicy sizePolicy(QSizePolicy::Preferred, QSizePolicy::Preferred);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(label_10->sizePolicy().hasHeightForWidth());
        label_10->setSizePolicy(sizePolicy);

        horizontalLayout_2->addWidget(label_10);

        doubleSpinBox_22 = new QDoubleSpinBox(scrollAreaWidgetContents);
        doubleSpinBox_22->setObjectName(QStringLiteral("doubleSpinBox_22"));
        QSizePolicy sizePolicy1(QSizePolicy::Maximum, QSizePolicy::Maximum);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(doubleSpinBox_22->sizePolicy().hasHeightForWidth());
        doubleSpinBox_22->setSizePolicy(sizePolicy1);
        doubleSpinBox_22->setMaximum(999.99);

        horizontalLayout_2->addWidget(doubleSpinBox_22);


        verticalLayout_6->addLayout(horizontalLayout_2);

        horizontalLayout_52 = new QHBoxLayout();
        horizontalLayout_52->setSpacing(6);
        horizontalLayout_52->setObjectName(QStringLiteral("horizontalLayout_52"));
        label_58 = new QLabel(scrollAreaWidgetContents);
        label_58->setObjectName(QStringLiteral("label_58"));
        sizePolicy.setHeightForWidth(label_58->sizePolicy().hasHeightForWidth());
        label_58->setSizePolicy(sizePolicy);

        horizontalLayout_52->addWidget(label_58);

        doubleSpinBox_5 = new QDoubleSpinBox(scrollAreaWidgetContents);
        doubleSpinBox_5->setObjectName(QStringLiteral("doubleSpinBox_5"));
        QSizePolicy sizePolicy2(QSizePolicy::Fixed, QSizePolicy::Fixed);
        sizePolicy2.setHorizontalStretch(0);
        sizePolicy2.setVerticalStretch(0);
        sizePolicy2.setHeightForWidth(doubleSpinBox_5->sizePolicy().hasHeightForWidth());
        doubleSpinBox_5->setSizePolicy(sizePolicy2);
        doubleSpinBox_5->setMaximum(1);
        doubleSpinBox_5->setSingleStep(0.1);
        doubleSpinBox_5->setValue(0.75);

        horizontalLayout_52->addWidget(doubleSpinBox_5);


        verticalLayout_6->addLayout(horizontalLayout_52);

        horizontalLayout_3 = new QHBoxLayout();
        horizontalLayout_3->setSpacing(6);
        horizontalLayout_3->setObjectName(QStringLiteral("horizontalLayout_3"));
        label_16 = new QLabel(scrollAreaWidgetContents);
        label_16->setObjectName(QStringLiteral("label_16"));
        sizePolicy.setHeightForWidth(label_16->sizePolicy().hasHeightForWidth());
        label_16->setSizePolicy(sizePolicy);

        horizontalLayout_3->addWidget(label_16);

        doubleSpinBox_23 = new QDoubleSpinBox(scrollAreaWidgetContents);
        doubleSpinBox_23->setObjectName(QStringLiteral("doubleSpinBox_23"));
        QSizePolicy sizePolicy3(QSizePolicy::Maximum, QSizePolicy::Fixed);
        sizePolicy3.setHorizontalStretch(0);
        sizePolicy3.setVerticalStretch(0);
        sizePolicy3.setHeightForWidth(doubleSpinBox_23->sizePolicy().hasHeightForWidth());
        doubleSpinBox_23->setSizePolicy(sizePolicy3);
        doubleSpinBox_23->setDecimals(3);
        doubleSpinBox_23->setMaximum(90);

        horizontalLayout_3->addWidget(doubleSpinBox_23);


        verticalLayout_6->addLayout(horizontalLayout_3);

        horizontalLayout_4 = new QHBoxLayout();
        horizontalLayout_4->setSpacing(6);
        horizontalLayout_4->setObjectName(QStringLiteral("horizontalLayout_4"));
        label_13 = new QLabel(scrollAreaWidgetContents);
        label_13->setObjectName(QStringLiteral("label_13"));
        sizePolicy.setHeightForWidth(label_13->sizePolicy().hasHeightForWidth());
        label_13->setSizePolicy(sizePolicy);

        horizontalLayout_4->addWidget(label_13);

        doubleSpinBox_24 = new QDoubleSpinBox(scrollAreaWidgetContents);
        doubleSpinBox_24->setObjectName(QStringLiteral("doubleSpinBox_24"));
        sizePolicy3.setHeightForWidth(doubleSpinBox_24->sizePolicy().hasHeightForWidth());
        doubleSpinBox_24->setSizePolicy(sizePolicy3);
        doubleSpinBox_24->setMinimum(-90);
        doubleSpinBox_24->setMaximum(90);

        horizontalLayout_4->addWidget(doubleSpinBox_24);


        verticalLayout_6->addLayout(horizontalLayout_4);

        horizontalLayout_26 = new QHBoxLayout();
        horizontalLayout_26->setSpacing(6);
        horizontalLayout_26->setObjectName(QStringLiteral("horizontalLayout_26"));
        label_33 = new QLabel(scrollAreaWidgetContents);
        label_33->setObjectName(QStringLiteral("label_33"));
        QSizePolicy sizePolicy4(QSizePolicy::Maximum, QSizePolicy::Preferred);
        sizePolicy4.setHorizontalStretch(0);
        sizePolicy4.setVerticalStretch(0);
        sizePolicy4.setHeightForWidth(label_33->sizePolicy().hasHeightForWidth());
        label_33->setSizePolicy(sizePolicy4);

        horizontalLayout_26->addWidget(label_33);

        doubleSpinBox = new QDoubleSpinBox(scrollAreaWidgetContents);
        doubleSpinBox->setObjectName(QStringLiteral("doubleSpinBox"));
        sizePolicy2.setHeightForWidth(doubleSpinBox->sizePolicy().hasHeightForWidth());
        doubleSpinBox->setSizePolicy(sizePolicy2);
        doubleSpinBox->setMinimum(99);
        doubleSpinBox->setMaximum(999);
        doubleSpinBox->setValue(400);

        horizontalLayout_26->addWidget(doubleSpinBox);

        label_34 = new QLabel(scrollAreaWidgetContents);
        label_34->setObjectName(QStringLiteral("label_34"));
        sizePolicy.setHeightForWidth(label_34->sizePolicy().hasHeightForWidth());
        label_34->setSizePolicy(sizePolicy);

        horizontalLayout_26->addWidget(label_34);

        doubleSpinBox_2 = new QDoubleSpinBox(scrollAreaWidgetContents);
        doubleSpinBox_2->setObjectName(QStringLiteral("doubleSpinBox_2"));
        sizePolicy2.setHeightForWidth(doubleSpinBox_2->sizePolicy().hasHeightForWidth());
        doubleSpinBox_2->setSizePolicy(sizePolicy2);
        doubleSpinBox_2->setMinimum(99);
        doubleSpinBox_2->setMaximum(999);
        doubleSpinBox_2->setValue(700);

        horizontalLayout_26->addWidget(doubleSpinBox_2);


        verticalLayout_6->addLayout(horizontalLayout_26);

        horizontalLayout_6 = new QHBoxLayout();
        horizontalLayout_6->setSpacing(6);
        horizontalLayout_6->setObjectName(QStringLiteral("horizontalLayout_6"));
        label_11 = new QLabel(scrollAreaWidgetContents);
        label_11->setObjectName(QStringLiteral("label_11"));
        sizePolicy.setHeightForWidth(label_11->sizePolicy().hasHeightForWidth());
        label_11->setSizePolicy(sizePolicy);

        horizontalLayout_6->addWidget(label_11);

        doubleSpinBox_25 = new QDoubleSpinBox(scrollAreaWidgetContents);
        doubleSpinBox_25->setObjectName(QStringLiteral("doubleSpinBox_25"));
        sizePolicy3.setHeightForWidth(doubleSpinBox_25->sizePolicy().hasHeightForWidth());
        doubleSpinBox_25->setSizePolicy(sizePolicy3);
        doubleSpinBox_25->setMaximum(9999.99);

        horizontalLayout_6->addWidget(doubleSpinBox_25);


        verticalLayout_6->addLayout(horizontalLayout_6);

        horizontalLayout_7 = new QHBoxLayout();
        horizontalLayout_7->setSpacing(6);
        horizontalLayout_7->setObjectName(QStringLiteral("horizontalLayout_7"));
        label_12 = new QLabel(scrollAreaWidgetContents);
        label_12->setObjectName(QStringLiteral("label_12"));
        sizePolicy.setHeightForWidth(label_12->sizePolicy().hasHeightForWidth());
        label_12->setSizePolicy(sizePolicy);

        horizontalLayout_7->addWidget(label_12);

        doubleSpinBox_26 = new QDoubleSpinBox(scrollAreaWidgetContents);
        doubleSpinBox_26->setObjectName(QStringLiteral("doubleSpinBox_26"));
        sizePolicy3.setHeightForWidth(doubleSpinBox_26->sizePolicy().hasHeightForWidth());
        doubleSpinBox_26->setSizePolicy(sizePolicy3);
        doubleSpinBox_26->setMaximum(9999.99);

        horizontalLayout_7->addWidget(doubleSpinBox_26);


        verticalLayout_6->addLayout(horizontalLayout_7);

        horizontalLayout_76 = new QHBoxLayout();
        horizontalLayout_76->setSpacing(6);
        horizontalLayout_76->setObjectName(QStringLiteral("horizontalLayout_76"));
        checkBox_2 = new QCheckBox(scrollAreaWidgetContents);
        checkBox_2->setObjectName(QStringLiteral("checkBox_2"));
        QSizePolicy sizePolicy5(QSizePolicy::Preferred, QSizePolicy::Fixed);
        sizePolicy5.setHorizontalStretch(0);
        sizePolicy5.setVerticalStretch(0);
        sizePolicy5.setHeightForWidth(checkBox_2->sizePolicy().hasHeightForWidth());
        checkBox_2->setSizePolicy(sizePolicy5);

        horizontalLayout_76->addWidget(checkBox_2);

        checkBox_3 = new QCheckBox(scrollAreaWidgetContents);
        checkBox_3->setObjectName(QStringLiteral("checkBox_3"));
        sizePolicy3.setHeightForWidth(checkBox_3->sizePolicy().hasHeightForWidth());
        checkBox_3->setSizePolicy(sizePolicy3);

        horizontalLayout_76->addWidget(checkBox_3);


        verticalLayout_6->addLayout(horizontalLayout_76);

        horizontalLayout_75 = new QHBoxLayout();
        horizontalLayout_75->setSpacing(6);
        horizontalLayout_75->setObjectName(QStringLiteral("horizontalLayout_75"));
        label_75 = new QLabel(scrollAreaWidgetContents);
        label_75->setObjectName(QStringLiteral("label_75"));

        horizontalLayout_75->addWidget(label_75);

        doubleSpinBox_37 = new QDoubleSpinBox(scrollAreaWidgetContents);
        doubleSpinBox_37->setObjectName(QStringLiteral("doubleSpinBox_37"));
        sizePolicy3.setHeightForWidth(doubleSpinBox_37->sizePolicy().hasHeightForWidth());
        doubleSpinBox_37->setSizePolicy(sizePolicy3);
        doubleSpinBox_37->setMaximum(9999.99);

        horizontalLayout_75->addWidget(doubleSpinBox_37);


        verticalLayout_6->addLayout(horizontalLayout_75);

        horizontalLayout_70 = new QHBoxLayout();
        horizontalLayout_70->setSpacing(6);
        horizontalLayout_70->setObjectName(QStringLiteral("horizontalLayout_70"));
        label_71 = new QLabel(scrollAreaWidgetContents);
        label_71->setObjectName(QStringLiteral("label_71"));

        horizontalLayout_70->addWidget(label_71);

        doubleSpinBox_32 = new QDoubleSpinBox(scrollAreaWidgetContents);
        doubleSpinBox_32->setObjectName(QStringLiteral("doubleSpinBox_32"));
        sizePolicy3.setHeightForWidth(doubleSpinBox_32->sizePolicy().hasHeightForWidth());
        doubleSpinBox_32->setSizePolicy(sizePolicy3);
        QPalette palette1;
        QBrush brush11(QColor(138, 43, 43, 255));
        brush11.setStyle(Qt::SolidPattern);
        palette1.setBrush(QPalette::Active, QPalette::BrightText, brush11);
        QBrush brush12(QColor(65, 169, 74, 255));
        brush12.setStyle(Qt::SolidPattern);
        palette1.setBrush(QPalette::Active, QPalette::Highlight, brush12);
        palette1.setBrush(QPalette::Inactive, QPalette::BrightText, brush11);
        QBrush brush13(QColor(229, 227, 225, 255));
        brush13.setStyle(Qt::SolidPattern);
        palette1.setBrush(QPalette::Inactive, QPalette::Highlight, brush13);
        palette1.setBrush(QPalette::Disabled, QPalette::BrightText, brush11);
        QBrush brush14(QColor(240, 240, 240, 255));
        brush14.setStyle(Qt::SolidPattern);
        palette1.setBrush(QPalette::Disabled, QPalette::Highlight, brush14);
        doubleSpinBox_32->setPalette(palette1);
        doubleSpinBox_32->setMaximum(9999.99);

        horizontalLayout_70->addWidget(doubleSpinBox_32);


        verticalLayout_6->addLayout(horizontalLayout_70);

        line_2 = new QFrame(scrollAreaWidgetContents);
        line_2->setObjectName(QStringLiteral("line_2"));
        QSizePolicy sizePolicy6(QSizePolicy::Minimum, QSizePolicy::Fixed);
        sizePolicy6.setHorizontalStretch(0);
        sizePolicy6.setVerticalStretch(0);
        sizePolicy6.setHeightForWidth(line_2->sizePolicy().hasHeightForWidth());
        line_2->setSizePolicy(sizePolicy6);
        line_2->setFrameShadow(QFrame::Plain);
        line_2->setFrameShape(QFrame::HLine);

        verticalLayout_6->addWidget(line_2);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setSpacing(6);
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        label_2 = new QLabel(scrollAreaWidgetContents);
        label_2->setObjectName(QStringLiteral("label_2"));
        sizePolicy.setHeightForWidth(label_2->sizePolicy().hasHeightForWidth());
        label_2->setSizePolicy(sizePolicy);

        horizontalLayout->addWidget(label_2);

        comboBox_2 = new QComboBox(scrollAreaWidgetContents);
        comboBox_2->setObjectName(QStringLiteral("comboBox_2"));
        sizePolicy3.setHeightForWidth(comboBox_2->sizePolicy().hasHeightForWidth());
        comboBox_2->setSizePolicy(sizePolicy3);

        horizontalLayout->addWidget(comboBox_2);


        verticalLayout_6->addLayout(horizontalLayout);


        verticalLayout_7->addLayout(verticalLayout_6);

        verticalLayout_5 = new QVBoxLayout();
        verticalLayout_5->setSpacing(6);
        verticalLayout_5->setObjectName(QStringLiteral("verticalLayout_5"));
        horizontalLayout_5 = new QHBoxLayout();
        horizontalLayout_5->setSpacing(6);
        horizontalLayout_5->setObjectName(QStringLiteral("horizontalLayout_5"));
        label_27 = new QLabel(scrollAreaWidgetContents);
        label_27->setObjectName(QStringLiteral("label_27"));
        sizePolicy.setHeightForWidth(label_27->sizePolicy().hasHeightForWidth());
        label_27->setSizePolicy(sizePolicy);

        horizontalLayout_5->addWidget(label_27);

        doubleSpinBox_27 = new QDoubleSpinBox(scrollAreaWidgetContents);
        doubleSpinBox_27->setObjectName(QStringLiteral("doubleSpinBox_27"));
        sizePolicy3.setHeightForWidth(doubleSpinBox_27->sizePolicy().hasHeightForWidth());
        doubleSpinBox_27->setSizePolicy(sizePolicy3);
        doubleSpinBox_27->setMaximum(9999);

        horizontalLayout_5->addWidget(doubleSpinBox_27);


        verticalLayout_5->addLayout(horizontalLayout_5);

        horizontalLayout_24 = new QHBoxLayout();
        horizontalLayout_24->setSpacing(6);
        horizontalLayout_24->setObjectName(QStringLiteral("horizontalLayout_24"));
        label_28 = new QLabel(scrollAreaWidgetContents);
        label_28->setObjectName(QStringLiteral("label_28"));
        sizePolicy.setHeightForWidth(label_28->sizePolicy().hasHeightForWidth());
        label_28->setSizePolicy(sizePolicy);

        horizontalLayout_24->addWidget(label_28);

        doubleSpinBox_28 = new QDoubleSpinBox(scrollAreaWidgetContents);
        doubleSpinBox_28->setObjectName(QStringLiteral("doubleSpinBox_28"));
        sizePolicy3.setHeightForWidth(doubleSpinBox_28->sizePolicy().hasHeightForWidth());
        doubleSpinBox_28->setSizePolicy(sizePolicy3);
        doubleSpinBox_28->setMaximum(90);

        horizontalLayout_24->addWidget(doubleSpinBox_28);


        verticalLayout_5->addLayout(horizontalLayout_24);

        horizontalLayout_53 = new QHBoxLayout();
        horizontalLayout_53->setSpacing(6);
        horizontalLayout_53->setObjectName(QStringLiteral("horizontalLayout_53"));
        label_59 = new QLabel(scrollAreaWidgetContents);
        label_59->setObjectName(QStringLiteral("label_59"));
        sizePolicy.setHeightForWidth(label_59->sizePolicy().hasHeightForWidth());
        label_59->setSizePolicy(sizePolicy);

        horizontalLayout_53->addWidget(label_59);

        doubleSpinBox_6 = new QDoubleSpinBox(scrollAreaWidgetContents);
        doubleSpinBox_6->setObjectName(QStringLiteral("doubleSpinBox_6"));
        sizePolicy3.setHeightForWidth(doubleSpinBox_6->sizePolicy().hasHeightForWidth());
        doubleSpinBox_6->setSizePolicy(sizePolicy3);
        doubleSpinBox_6->setMaximum(90);

        horizontalLayout_53->addWidget(doubleSpinBox_6);


        verticalLayout_5->addLayout(horizontalLayout_53);

        horizontalLayout_54 = new QHBoxLayout();
        horizontalLayout_54->setSpacing(6);
        horizontalLayout_54->setObjectName(QStringLiteral("horizontalLayout_54"));
        label_60 = new QLabel(scrollAreaWidgetContents);
        label_60->setObjectName(QStringLiteral("label_60"));
        sizePolicy.setHeightForWidth(label_60->sizePolicy().hasHeightForWidth());
        label_60->setSizePolicy(sizePolicy);

        horizontalLayout_54->addWidget(label_60);

        doubleSpinBox_7 = new QDoubleSpinBox(scrollAreaWidgetContents);
        doubleSpinBox_7->setObjectName(QStringLiteral("doubleSpinBox_7"));
        sizePolicy3.setHeightForWidth(doubleSpinBox_7->sizePolicy().hasHeightForWidth());
        doubleSpinBox_7->setSizePolicy(sizePolicy3);
        doubleSpinBox_7->setMaximum(1);
        doubleSpinBox_7->setSingleStep(0.01);
        doubleSpinBox_7->setValue(0.75);

        horizontalLayout_54->addWidget(doubleSpinBox_7);


        verticalLayout_5->addLayout(horizontalLayout_54);

        horizontalLayout_63 = new QHBoxLayout();
        horizontalLayout_63->setSpacing(6);
        horizontalLayout_63->setObjectName(QStringLiteral("horizontalLayout_63"));
        label_67 = new QLabel(scrollAreaWidgetContents);
        label_67->setObjectName(QStringLiteral("label_67"));

        horizontalLayout_63->addWidget(label_67);

        doubleSpinBox_18 = new QDoubleSpinBox(scrollAreaWidgetContents);
        doubleSpinBox_18->setObjectName(QStringLiteral("doubleSpinBox_18"));
        sizePolicy3.setHeightForWidth(doubleSpinBox_18->sizePolicy().hasHeightForWidth());
        doubleSpinBox_18->setSizePolicy(sizePolicy3);
        doubleSpinBox_18->setDecimals(4);
        doubleSpinBox_18->setMinimum(1);
        doubleSpinBox_18->setMaximum(5);
        doubleSpinBox_18->setSingleStep(0.1);

        horizontalLayout_63->addWidget(doubleSpinBox_18);


        verticalLayout_5->addLayout(horizontalLayout_63);

        horizontalLayout_65 = new QHBoxLayout();
        horizontalLayout_65->setSpacing(6);
        horizontalLayout_65->setObjectName(QStringLiteral("horizontalLayout_65"));
        label_69 = new QLabel(scrollAreaWidgetContents);
        label_69->setObjectName(QStringLiteral("label_69"));

        horizontalLayout_65->addWidget(label_69);

        doubleSpinBox_19 = new QDoubleSpinBox(scrollAreaWidgetContents);
        doubleSpinBox_19->setObjectName(QStringLiteral("doubleSpinBox_19"));
        sizePolicy3.setHeightForWidth(doubleSpinBox_19->sizePolicy().hasHeightForWidth());
        doubleSpinBox_19->setSizePolicy(sizePolicy3);
        doubleSpinBox_19->setDecimals(4);
        doubleSpinBox_19->setSingleStep(0.001);

        horizontalLayout_65->addWidget(doubleSpinBox_19);


        verticalLayout_5->addLayout(horizontalLayout_65);

        horizontalLayout_66 = new QHBoxLayout();
        horizontalLayout_66->setSpacing(6);
        horizontalLayout_66->setObjectName(QStringLiteral("horizontalLayout_66"));
        label_68 = new QLabel(scrollAreaWidgetContents);
        label_68->setObjectName(QStringLiteral("label_68"));

        horizontalLayout_66->addWidget(label_68);

        doubleSpinBox_20 = new QDoubleSpinBox(scrollAreaWidgetContents);
        doubleSpinBox_20->setObjectName(QStringLiteral("doubleSpinBox_20"));
        sizePolicy3.setHeightForWidth(doubleSpinBox_20->sizePolicy().hasHeightForWidth());
        doubleSpinBox_20->setSizePolicy(sizePolicy3);
        QPalette palette2;
        QBrush brush15(QColor(240, 48, 48, 255));
        brush15.setStyle(Qt::SolidPattern);
        palette2.setBrush(QPalette::Active, QPalette::WindowText, brush15);
        palette2.setBrush(QPalette::Inactive, QPalette::WindowText, brush15);
        QBrush brush16(QColor(28, 10, 121, 255));
        brush16.setStyle(Qt::SolidPattern);
        palette2.setBrush(QPalette::Disabled, QPalette::WindowText, brush16);
        doubleSpinBox_20->setPalette(palette2);
        doubleSpinBox_20->setDecimals(3);
        doubleSpinBox_20->setMaximum(1);
        doubleSpinBox_20->setSingleStep(0.01);

        horizontalLayout_66->addWidget(doubleSpinBox_20);


        verticalLayout_5->addLayout(horizontalLayout_66);

        horizontalLayout_64 = new QHBoxLayout();
        horizontalLayout_64->setSpacing(6);
        horizontalLayout_64->setObjectName(QStringLiteral("horizontalLayout_64"));
        label_70 = new QLabel(scrollAreaWidgetContents);
        label_70->setObjectName(QStringLiteral("label_70"));

        horizontalLayout_64->addWidget(label_70);

        doubleSpinBox_21 = new QDoubleSpinBox(scrollAreaWidgetContents);
        doubleSpinBox_21->setObjectName(QStringLiteral("doubleSpinBox_21"));
        sizePolicy3.setHeightForWidth(doubleSpinBox_21->sizePolicy().hasHeightForWidth());
        doubleSpinBox_21->setSizePolicy(sizePolicy3);
        doubleSpinBox_21->setMinimum(99);
        doubleSpinBox_21->setMaximum(999);

        horizontalLayout_64->addWidget(doubleSpinBox_21);


        verticalLayout_5->addLayout(horizontalLayout_64);

        horizontalLayout_25 = new QHBoxLayout();
        horizontalLayout_25->setSpacing(6);
        horizontalLayout_25->setObjectName(QStringLiteral("horizontalLayout_25"));
        label_14 = new QLabel(scrollAreaWidgetContents);
        label_14->setObjectName(QStringLiteral("label_14"));
        sizePolicy.setHeightForWidth(label_14->sizePolicy().hasHeightForWidth());
        label_14->setSizePolicy(sizePolicy);

        horizontalLayout_25->addWidget(label_14);

        comboBox = new QComboBox(scrollAreaWidgetContents);
        comboBox->setObjectName(QStringLiteral("comboBox"));
        sizePolicy3.setHeightForWidth(comboBox->sizePolicy().hasHeightForWidth());
        comboBox->setSizePolicy(sizePolicy3);

        horizontalLayout_25->addWidget(comboBox);


        verticalLayout_5->addLayout(horizontalLayout_25);

        horizontalLayout_67 = new QHBoxLayout();
        horizontalLayout_67->setSpacing(6);
        horizontalLayout_67->setObjectName(QStringLiteral("horizontalLayout_67"));
        label_35 = new QLabel(scrollAreaWidgetContents);
        label_35->setObjectName(QStringLiteral("label_35"));

        horizontalLayout_67->addWidget(label_35);

        doubleSpinBox_36 = new QDoubleSpinBox(scrollAreaWidgetContents);
        doubleSpinBox_36->setObjectName(QStringLiteral("doubleSpinBox_36"));
        doubleSpinBox_36->setEnabled(false);
        sizePolicy3.setHeightForWidth(doubleSpinBox_36->sizePolicy().hasHeightForWidth());
        doubleSpinBox_36->setSizePolicy(sizePolicy3);
        doubleSpinBox_36->setMaximum(90);

        horizontalLayout_67->addWidget(doubleSpinBox_36);


        verticalLayout_5->addLayout(horizontalLayout_67);

        line_8 = new QFrame(scrollAreaWidgetContents);
        line_8->setObjectName(QStringLiteral("line_8"));
        line_8->setFrameShape(QFrame::HLine);
        line_8->setFrameShadow(QFrame::Sunken);

        verticalLayout_5->addWidget(line_8);

        verticalSpacer_3 = new QSpacerItem(20, 38, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_5->addItem(verticalSpacer_3);

        horizontalLayout_71 = new QHBoxLayout();
        horizontalLayout_71->setSpacing(6);
        horizontalLayout_71->setObjectName(QStringLiteral("horizontalLayout_71"));
        label_72 = new QLabel(scrollAreaWidgetContents);
        label_72->setObjectName(QStringLiteral("label_72"));

        horizontalLayout_71->addWidget(label_72);

        lineEdit_3 = new QLineEdit(scrollAreaWidgetContents);
        lineEdit_3->setObjectName(QStringLiteral("lineEdit_3"));
        sizePolicy5.setHeightForWidth(lineEdit_3->sizePolicy().hasHeightForWidth());
        lineEdit_3->setSizePolicy(sizePolicy5);

        horizontalLayout_71->addWidget(lineEdit_3);

        pushButton_8 = new QPushButton(scrollAreaWidgetContents);
        pushButton_8->setObjectName(QStringLiteral("pushButton_8"));
        sizePolicy3.setHeightForWidth(pushButton_8->sizePolicy().hasHeightForWidth());
        pushButton_8->setSizePolicy(sizePolicy3);

        horizontalLayout_71->addWidget(pushButton_8);


        verticalLayout_5->addLayout(horizontalLayout_71);

        horizontalLayout_69 = new QHBoxLayout();
        horizontalLayout_69->setSpacing(6);
        horizontalLayout_69->setObjectName(QStringLiteral("horizontalLayout_69"));
        label_41 = new QLabel(scrollAreaWidgetContents);
        label_41->setObjectName(QStringLiteral("label_41"));

        horizontalLayout_69->addWidget(label_41);

        lineEdit_2 = new QLineEdit(scrollAreaWidgetContents);
        lineEdit_2->setObjectName(QStringLiteral("lineEdit_2"));
        sizePolicy5.setHeightForWidth(lineEdit_2->sizePolicy().hasHeightForWidth());
        lineEdit_2->setSizePolicy(sizePolicy5);

        horizontalLayout_69->addWidget(lineEdit_2);


        verticalLayout_5->addLayout(horizontalLayout_69);

        horizontalLayout_74 = new QHBoxLayout();
        horizontalLayout_74->setSpacing(6);
        horizontalLayout_74->setObjectName(QStringLiteral("horizontalLayout_74"));
        pushButton_10 = new QPushButton(scrollAreaWidgetContents);
        pushButton_10->setObjectName(QStringLiteral("pushButton_10"));
        sizePolicy3.setHeightForWidth(pushButton_10->sizePolicy().hasHeightForWidth());
        pushButton_10->setSizePolicy(sizePolicy3);

        horizontalLayout_74->addWidget(pushButton_10);

        lineEdit_5 = new QLineEdit(scrollAreaWidgetContents);
        lineEdit_5->setObjectName(QStringLiteral("lineEdit_5"));
        sizePolicy5.setHeightForWidth(lineEdit_5->sizePolicy().hasHeightForWidth());
        lineEdit_5->setSizePolicy(sizePolicy5);

        horizontalLayout_74->addWidget(lineEdit_5);


        verticalLayout_5->addLayout(horizontalLayout_74);

        horizontalLayout_13 = new QHBoxLayout();
        horizontalLayout_13->setSpacing(6);
        horizontalLayout_13->setObjectName(QStringLiteral("horizontalLayout_13"));
        pushButton = new QPushButton(scrollAreaWidgetContents);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        sizePolicy2.setHeightForWidth(pushButton->sizePolicy().hasHeightForWidth());
        pushButton->setSizePolicy(sizePolicy2);

        horizontalLayout_13->addWidget(pushButton);


        verticalLayout_5->addLayout(horizontalLayout_13);


        verticalLayout_7->addLayout(verticalLayout_5);


        horizontalLayout_61->addLayout(verticalLayout_7);

        line_3 = new QFrame(scrollAreaWidgetContents);
        line_3->setObjectName(QStringLiteral("line_3"));
        line_3->setFrameShadow(QFrame::Plain);
        line_3->setFrameShape(QFrame::VLine);

        horizontalLayout_61->addWidget(line_3);

        verticalLayout_2 = new QVBoxLayout();
        verticalLayout_2->setSpacing(6);
        verticalLayout_2->setObjectName(QStringLiteral("verticalLayout_2"));
        label_3 = new QLabel(scrollAreaWidgetContents);
        label_3->setObjectName(QStringLiteral("label_3"));
        QFont font2;
        font2.setPointSize(14);
        label_3->setFont(font2);

        verticalLayout_2->addWidget(label_3);

        horizontalLayout_12 = new QHBoxLayout();
        horizontalLayout_12->setSpacing(6);
        horizontalLayout_12->setObjectName(QStringLiteral("horizontalLayout_12"));
        label_5 = new QLabel(scrollAreaWidgetContents);
        label_5->setObjectName(QStringLiteral("label_5"));
        sizePolicy.setHeightForWidth(label_5->sizePolicy().hasHeightForWidth());
        label_5->setSizePolicy(sizePolicy);

        horizontalLayout_12->addWidget(label_5);

        spinBox = new QSpinBox(scrollAreaWidgetContents);
        spinBox->setObjectName(QStringLiteral("spinBox"));
        sizePolicy3.setHeightForWidth(spinBox->sizePolicy().hasHeightForWidth());
        spinBox->setSizePolicy(sizePolicy3);

        horizontalLayout_12->addWidget(spinBox);


        verticalLayout_2->addLayout(horizontalLayout_12);

        horizontalLayout_11 = new QHBoxLayout();
        horizontalLayout_11->setSpacing(6);
        horizontalLayout_11->setObjectName(QStringLiteral("horizontalLayout_11"));
        label_6 = new QLabel(scrollAreaWidgetContents);
        label_6->setObjectName(QStringLiteral("label_6"));
        sizePolicy.setHeightForWidth(label_6->sizePolicy().hasHeightForWidth());
        label_6->setSizePolicy(sizePolicy);

        horizontalLayout_11->addWidget(label_6);

        spinBox_2 = new QSpinBox(scrollAreaWidgetContents);
        spinBox_2->setObjectName(QStringLiteral("spinBox_2"));
        sizePolicy3.setHeightForWidth(spinBox_2->sizePolicy().hasHeightForWidth());
        spinBox_2->setSizePolicy(sizePolicy3);

        horizontalLayout_11->addWidget(spinBox_2);


        verticalLayout_2->addLayout(horizontalLayout_11);

        horizontalLayout_59 = new QHBoxLayout();
        horizontalLayout_59->setSpacing(6);
        horizontalLayout_59->setObjectName(QStringLiteral("horizontalLayout_59"));
        label_65 = new QLabel(scrollAreaWidgetContents);
        label_65->setObjectName(QStringLiteral("label_65"));

        horizontalLayout_59->addWidget(label_65);

        spinBox_7 = new QSpinBox(scrollAreaWidgetContents);
        spinBox_7->setObjectName(QStringLiteral("spinBox_7"));
        sizePolicy3.setHeightForWidth(spinBox_7->sizePolicy().hasHeightForWidth());
        spinBox_7->setSizePolicy(sizePolicy3);

        horizontalLayout_59->addWidget(spinBox_7);


        verticalLayout_2->addLayout(horizontalLayout_59);

        horizontalLayout_60 = new QHBoxLayout();
        horizontalLayout_60->setSpacing(6);
        horizontalLayout_60->setObjectName(QStringLiteral("horizontalLayout_60"));
        label_66 = new QLabel(scrollAreaWidgetContents);
        label_66->setObjectName(QStringLiteral("label_66"));

        horizontalLayout_60->addWidget(label_66);

        spinBox_8 = new QSpinBox(scrollAreaWidgetContents);
        spinBox_8->setObjectName(QStringLiteral("spinBox_8"));
        sizePolicy3.setHeightForWidth(spinBox_8->sizePolicy().hasHeightForWidth());
        spinBox_8->setSizePolicy(sizePolicy3);
        QPalette palette3;
        QBrush brush17(QColor(218, 218, 49, 255));
        brush17.setStyle(Qt::SolidPattern);
        palette3.setBrush(QPalette::Active, QPalette::ToolTipBase, brush17);
        palette3.setBrush(QPalette::Inactive, QPalette::ToolTipBase, brush10);
        palette3.setBrush(QPalette::Disabled, QPalette::ToolTipBase, brush10);
        spinBox_8->setPalette(palette3);

        horizontalLayout_60->addWidget(spinBox_8);


        verticalLayout_2->addLayout(horizontalLayout_60);

        horizontalLayout_10 = new QHBoxLayout();
        horizontalLayout_10->setSpacing(6);
        horizontalLayout_10->setObjectName(QStringLiteral("horizontalLayout_10"));
        label_8 = new QLabel(scrollAreaWidgetContents);
        label_8->setObjectName(QStringLiteral("label_8"));
        sizePolicy.setHeightForWidth(label_8->sizePolicy().hasHeightForWidth());
        label_8->setSizePolicy(sizePolicy);

        horizontalLayout_10->addWidget(label_8);

        spinBox_3 = new QSpinBox(scrollAreaWidgetContents);
        spinBox_3->setObjectName(QStringLiteral("spinBox_3"));
        sizePolicy3.setHeightForWidth(spinBox_3->sizePolicy().hasHeightForWidth());
        spinBox_3->setSizePolicy(sizePolicy3);

        horizontalLayout_10->addWidget(spinBox_3);


        verticalLayout_2->addLayout(horizontalLayout_10);

        horizontalLayout_9 = new QHBoxLayout();
        horizontalLayout_9->setSpacing(6);
        horizontalLayout_9->setObjectName(QStringLiteral("horizontalLayout_9"));
        checkBox_11 = new QCheckBox(scrollAreaWidgetContents);
        checkBox_11->setObjectName(QStringLiteral("checkBox_11"));

        horizontalLayout_9->addWidget(checkBox_11);

        lineEdit = new QLineEdit(scrollAreaWidgetContents);
        lineEdit->setObjectName(QStringLiteral("lineEdit"));
        sizePolicy3.setHeightForWidth(lineEdit->sizePolicy().hasHeightForWidth());
        lineEdit->setSizePolicy(sizePolicy3);
        QPalette palette4;
        QBrush brush18(QColor(237, 237, 68, 255));
        brush18.setStyle(Qt::SolidPattern);
        palette4.setBrush(QPalette::Active, QPalette::ToolTipBase, brush18);
        palette4.setBrush(QPalette::Inactive, QPalette::ToolTipBase, brush18);
        palette4.setBrush(QPalette::Disabled, QPalette::ToolTipBase, brush18);
        lineEdit->setPalette(palette4);

        horizontalLayout_9->addWidget(lineEdit);


        verticalLayout_2->addLayout(horizontalLayout_9);

        horizontalLayout_30 = new QHBoxLayout();
        horizontalLayout_30->setSpacing(6);
        horizontalLayout_30->setObjectName(QStringLiteral("horizontalLayout_30"));
        label_7 = new QLabel(scrollAreaWidgetContents);
        label_7->setObjectName(QStringLiteral("label_7"));
        sizePolicy.setHeightForWidth(label_7->sizePolicy().hasHeightForWidth());
        label_7->setSizePolicy(sizePolicy);

        horizontalLayout_30->addWidget(label_7);

        spinBox_6 = new QSpinBox(scrollAreaWidgetContents);
        spinBox_6->setObjectName(QStringLiteral("spinBox_6"));
        sizePolicy3.setHeightForWidth(spinBox_6->sizePolicy().hasHeightForWidth());
        spinBox_6->setSizePolicy(sizePolicy3);

        horizontalLayout_30->addWidget(spinBox_6);


        verticalLayout_2->addLayout(horizontalLayout_30);

        tableWidget = new QTableWidget(scrollAreaWidgetContents);
        if (tableWidget->columnCount() < 2)
            tableWidget->setColumnCount(2);
        tableWidget->setObjectName(QStringLiteral("tableWidget"));
        QSizePolicy sizePolicy7(QSizePolicy::Preferred, QSizePolicy::MinimumExpanding);
        sizePolicy7.setHorizontalStretch(0);
        sizePolicy7.setVerticalStretch(0);
        sizePolicy7.setHeightForWidth(tableWidget->sizePolicy().hasHeightForWidth());
        tableWidget->setSizePolicy(sizePolicy7);
        tableWidget->setMinimumSize(QSize(0, 100));
        tableWidget->setColumnCount(2);
        tableWidget->horizontalHeader()->setDefaultSectionSize(100);

        verticalLayout_2->addWidget(tableWidget);

        horizontalLayout_31 = new QHBoxLayout();
        horizontalLayout_31->setSpacing(6);
        horizontalLayout_31->setObjectName(QStringLiteral("horizontalLayout_31"));
        pushButton_2 = new QPushButton(scrollAreaWidgetContents);
        pushButton_2->setObjectName(QStringLiteral("pushButton_2"));
        sizePolicy2.setHeightForWidth(pushButton_2->sizePolicy().hasHeightForWidth());
        pushButton_2->setSizePolicy(sizePolicy2);
        QPalette palette5;
        QBrush brush19(QColor(64, 61, 169, 255));
        brush19.setStyle(Qt::SolidPattern);
        palette5.setBrush(QPalette::Active, QPalette::Base, brush19);
        QBrush brush20(QColor(227, 57, 57, 255));
        brush20.setStyle(Qt::SolidPattern);
        palette5.setBrush(QPalette::Inactive, QPalette::Base, brush20);
        QBrush brush21(QColor(82, 73, 138, 255));
        brush21.setStyle(Qt::SolidPattern);
        palette5.setBrush(QPalette::Disabled, QPalette::Base, brush21);
        pushButton_2->setPalette(palette5);

        horizontalLayout_31->addWidget(pushButton_2);

        doubleSpinBox_13 = new QDoubleSpinBox(scrollAreaWidgetContents);
        doubleSpinBox_13->setObjectName(QStringLiteral("doubleSpinBox_13"));
        doubleSpinBox_13->setEnabled(false);
        sizePolicy2.setHeightForWidth(doubleSpinBox_13->sizePolicy().hasHeightForWidth());
        doubleSpinBox_13->setSizePolicy(sizePolicy2);
        doubleSpinBox_13->setMaximum(100);

        horizontalLayout_31->addWidget(doubleSpinBox_13);


        verticalLayout_2->addLayout(horizontalLayout_31);

        label_29 = new QLabel(scrollAreaWidgetContents);
        label_29->setObjectName(QStringLiteral("label_29"));

        verticalLayout_2->addWidget(label_29);

        horizontalLayout_29 = new QHBoxLayout();
        horizontalLayout_29->setSpacing(6);
        horizontalLayout_29->setObjectName(QStringLiteral("horizontalLayout_29"));
        label_30 = new QLabel(scrollAreaWidgetContents);
        label_30->setObjectName(QStringLiteral("label_30"));
        sizePolicy.setHeightForWidth(label_30->sizePolicy().hasHeightForWidth());
        label_30->setSizePolicy(sizePolicy);

        horizontalLayout_29->addWidget(label_30);

        doubleSpinBox_9 = new QDoubleSpinBox(scrollAreaWidgetContents);
        doubleSpinBox_9->setObjectName(QStringLiteral("doubleSpinBox_9"));
        sizePolicy3.setHeightForWidth(doubleSpinBox_9->sizePolicy().hasHeightForWidth());
        doubleSpinBox_9->setSizePolicy(sizePolicy3);
        doubleSpinBox_9->setAutoFillBackground(true);
        doubleSpinBox_9->setMaximum(100000);
        doubleSpinBox_9->setSingleStep(20);

        horizontalLayout_29->addWidget(doubleSpinBox_9);


        verticalLayout_2->addLayout(horizontalLayout_29);

        horizontalLayout_57 = new QHBoxLayout();
        horizontalLayout_57->setSpacing(6);
        horizontalLayout_57->setObjectName(QStringLiteral("horizontalLayout_57"));
        label_38 = new QLabel(scrollAreaWidgetContents);
        label_38->setObjectName(QStringLiteral("label_38"));
        sizePolicy.setHeightForWidth(label_38->sizePolicy().hasHeightForWidth());
        label_38->setSizePolicy(sizePolicy);

        horizontalLayout_57->addWidget(label_38);

        doubleSpinBox_11 = new QDoubleSpinBox(scrollAreaWidgetContents);
        doubleSpinBox_11->setObjectName(QStringLiteral("doubleSpinBox_11"));
        doubleSpinBox_11->setEnabled(false);
        sizePolicy2.setHeightForWidth(doubleSpinBox_11->sizePolicy().hasHeightForWidth());
        doubleSpinBox_11->setSizePolicy(sizePolicy2);
        doubleSpinBox_11->setMinimum(-99);

        horizontalLayout_57->addWidget(doubleSpinBox_11);


        verticalLayout_2->addLayout(horizontalLayout_57);

        horizontalLayout_28 = new QHBoxLayout();
        horizontalLayout_28->setSpacing(6);
        horizontalLayout_28->setObjectName(QStringLiteral("horizontalLayout_28"));
        label_31 = new QLabel(scrollAreaWidgetContents);
        label_31->setObjectName(QStringLiteral("label_31"));
        sizePolicy.setHeightForWidth(label_31->sizePolicy().hasHeightForWidth());
        label_31->setSizePolicy(sizePolicy);

        horizontalLayout_28->addWidget(label_31);

        doubleSpinBox_10 = new QDoubleSpinBox(scrollAreaWidgetContents);
        doubleSpinBox_10->setObjectName(QStringLiteral("doubleSpinBox_10"));
        sizePolicy2.setHeightForWidth(doubleSpinBox_10->sizePolicy().hasHeightForWidth());
        doubleSpinBox_10->setSizePolicy(sizePolicy2);

        horizontalLayout_28->addWidget(doubleSpinBox_10);


        verticalLayout_2->addLayout(horizontalLayout_28);

        horizontalLayout_27 = new QHBoxLayout();
        horizontalLayout_27->setSpacing(6);
        horizontalLayout_27->setObjectName(QStringLiteral("horizontalLayout_27"));
        label_32 = new QLabel(scrollAreaWidgetContents);
        label_32->setObjectName(QStringLiteral("label_32"));
        sizePolicy.setHeightForWidth(label_32->sizePolicy().hasHeightForWidth());
        label_32->setSizePolicy(sizePolicy);

        horizontalLayout_27->addWidget(label_32);

        doubleSpinBox_12 = new QDoubleSpinBox(scrollAreaWidgetContents);
        doubleSpinBox_12->setObjectName(QStringLiteral("doubleSpinBox_12"));
        sizePolicy2.setHeightForWidth(doubleSpinBox_12->sizePolicy().hasHeightForWidth());
        doubleSpinBox_12->setSizePolicy(sizePolicy2);
        doubleSpinBox_12->setMaximum(90);

        horizontalLayout_27->addWidget(doubleSpinBox_12);


        verticalLayout_2->addLayout(horizontalLayout_27);

        horizontalLayout_55 = new QHBoxLayout();
        horizontalLayout_55->setSpacing(6);
        horizontalLayout_55->setObjectName(QStringLiteral("horizontalLayout_55"));
        label_61 = new QLabel(scrollAreaWidgetContents);
        label_61->setObjectName(QStringLiteral("label_61"));
        sizePolicy.setHeightForWidth(label_61->sizePolicy().hasHeightForWidth());
        label_61->setSizePolicy(sizePolicy);

        horizontalLayout_55->addWidget(label_61);

        doubleSpinBox_8 = new QDoubleSpinBox(scrollAreaWidgetContents);
        doubleSpinBox_8->setObjectName(QStringLiteral("doubleSpinBox_8"));
        sizePolicy2.setHeightForWidth(doubleSpinBox_8->sizePolicy().hasHeightForWidth());
        doubleSpinBox_8->setSizePolicy(sizePolicy2);
        doubleSpinBox_8->setMaximum(999.99);

        horizontalLayout_55->addWidget(doubleSpinBox_8);


        verticalLayout_2->addLayout(horizontalLayout_55);


        horizontalLayout_61->addLayout(verticalLayout_2);

        line_4 = new QFrame(scrollAreaWidgetContents);
        line_4->setObjectName(QStringLiteral("line_4"));
        line_4->setFrameShadow(QFrame::Plain);
        line_4->setFrameShape(QFrame::VLine);

        horizontalLayout_61->addWidget(line_4);

        verticalLayout = new QVBoxLayout();
        verticalLayout->setSpacing(6);
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        label_4 = new QLabel(scrollAreaWidgetContents);
        label_4->setObjectName(QStringLiteral("label_4"));
        sizePolicy.setHeightForWidth(label_4->sizePolicy().hasHeightForWidth());
        label_4->setSizePolicy(sizePolicy);

        verticalLayout->addWidget(label_4);

        horizontalLayout_23 = new QHBoxLayout();
        horizontalLayout_23->setSpacing(6);
        horizontalLayout_23->setObjectName(QStringLiteral("horizontalLayout_23"));
        label_17 = new QLabel(scrollAreaWidgetContents);
        label_17->setObjectName(QStringLiteral("label_17"));
        sizePolicy.setHeightForWidth(label_17->sizePolicy().hasHeightForWidth());
        label_17->setSizePolicy(sizePolicy);

        horizontalLayout_23->addWidget(label_17);

        doubleSpinBox_29 = new QDoubleSpinBox(scrollAreaWidgetContents);
        doubleSpinBox_29->setObjectName(QStringLiteral("doubleSpinBox_29"));
        sizePolicy3.setHeightForWidth(doubleSpinBox_29->sizePolicy().hasHeightForWidth());
        doubleSpinBox_29->setSizePolicy(sizePolicy3);

        horizontalLayout_23->addWidget(doubleSpinBox_29);


        verticalLayout->addLayout(horizontalLayout_23);

        horizontalLayout_22 = new QHBoxLayout();
        horizontalLayout_22->setSpacing(6);
        horizontalLayout_22->setObjectName(QStringLiteral("horizontalLayout_22"));
        label_21 = new QLabel(scrollAreaWidgetContents);
        label_21->setObjectName(QStringLiteral("label_21"));
        sizePolicy.setHeightForWidth(label_21->sizePolicy().hasHeightForWidth());
        label_21->setSizePolicy(sizePolicy);

        horizontalLayout_22->addWidget(label_21);

        doubleSpinBox_35 = new QDoubleSpinBox(scrollAreaWidgetContents);
        doubleSpinBox_35->setObjectName(QStringLiteral("doubleSpinBox_35"));
        sizePolicy3.setHeightForWidth(doubleSpinBox_35->sizePolicy().hasHeightForWidth());
        doubleSpinBox_35->setSizePolicy(sizePolicy3);
        doubleSpinBox_35->setMaximum(1e+6);

        horizontalLayout_22->addWidget(doubleSpinBox_35);


        verticalLayout->addLayout(horizontalLayout_22);

        horizontalLayout_21 = new QHBoxLayout();
        horizontalLayout_21->setSpacing(6);
        horizontalLayout_21->setObjectName(QStringLiteral("horizontalLayout_21"));
        label_22 = new QLabel(scrollAreaWidgetContents);
        label_22->setObjectName(QStringLiteral("label_22"));
        sizePolicy.setHeightForWidth(label_22->sizePolicy().hasHeightForWidth());
        label_22->setSizePolicy(sizePolicy);

        horizontalLayout_21->addWidget(label_22);

        doubleSpinBox_34 = new QDoubleSpinBox(scrollAreaWidgetContents);
        doubleSpinBox_34->setObjectName(QStringLiteral("doubleSpinBox_34"));
        sizePolicy3.setHeightForWidth(doubleSpinBox_34->sizePolicy().hasHeightForWidth());
        doubleSpinBox_34->setSizePolicy(sizePolicy3);
        doubleSpinBox_34->setMaximum(1e+6);

        horizontalLayout_21->addWidget(doubleSpinBox_34);


        verticalLayout->addLayout(horizontalLayout_21);

        line_5 = new QFrame(scrollAreaWidgetContents);
        line_5->setObjectName(QStringLiteral("line_5"));
        line_5->setFrameShadow(QFrame::Plain);
        line_5->setFrameShape(QFrame::HLine);

        verticalLayout->addWidget(line_5);

        horizontalLayout_34 = new QHBoxLayout();
        horizontalLayout_34->setSpacing(6);
        horizontalLayout_34->setObjectName(QStringLiteral("horizontalLayout_34"));
        label_15 = new QLabel(scrollAreaWidgetContents);
        label_15->setObjectName(QStringLiteral("label_15"));
        sizePolicy5.setHeightForWidth(label_15->sizePolicy().hasHeightForWidth());
        label_15->setSizePolicy(sizePolicy5);

        horizontalLayout_34->addWidget(label_15);

        checkBox_8 = new QCheckBox(scrollAreaWidgetContents);
        checkBox_8->setObjectName(QStringLiteral("checkBox_8"));
        sizePolicy2.setHeightForWidth(checkBox_8->sizePolicy().hasHeightForWidth());
        checkBox_8->setSizePolicy(sizePolicy2);

        horizontalLayout_34->addWidget(checkBox_8);

        checkBox_9 = new QCheckBox(scrollAreaWidgetContents);
        checkBox_9->setObjectName(QStringLiteral("checkBox_9"));
        sizePolicy2.setHeightForWidth(checkBox_9->sizePolicy().hasHeightForWidth());
        checkBox_9->setSizePolicy(sizePolicy2);

        horizontalLayout_34->addWidget(checkBox_9);

        checkBox = new QCheckBox(scrollAreaWidgetContents);
        checkBox->setObjectName(QStringLiteral("checkBox"));
        sizePolicy5.setHeightForWidth(checkBox->sizePolicy().hasHeightForWidth());
        checkBox->setSizePolicy(sizePolicy5);

        horizontalLayout_34->addWidget(checkBox);


        verticalLayout->addLayout(horizontalLayout_34);

        horizontalLayout_8 = new QHBoxLayout();
        horizontalLayout_8->setSpacing(6);
        horizontalLayout_8->setObjectName(QStringLiteral("horizontalLayout_8"));
        doubleSpinBox_14 = new QDoubleSpinBox(scrollAreaWidgetContents);
        doubleSpinBox_14->setObjectName(QStringLiteral("doubleSpinBox_14"));
        sizePolicy3.setHeightForWidth(doubleSpinBox_14->sizePolicy().hasHeightForWidth());
        doubleSpinBox_14->setSizePolicy(sizePolicy3);
        doubleSpinBox_14->setDecimals(3);
        doubleSpinBox_14->setSingleStep(0.005);

        horizontalLayout_8->addWidget(doubleSpinBox_14);

        label_40 = new QLabel(scrollAreaWidgetContents);
        label_40->setObjectName(QStringLiteral("label_40"));
        QSizePolicy sizePolicy8(QSizePolicy::Fixed, QSizePolicy::Preferred);
        sizePolicy8.setHorizontalStretch(0);
        sizePolicy8.setVerticalStretch(0);
        sizePolicy8.setHeightForWidth(label_40->sizePolicy().hasHeightForWidth());
        label_40->setSizePolicy(sizePolicy8);

        horizontalLayout_8->addWidget(label_40);

        doubleSpinBox_15 = new QDoubleSpinBox(scrollAreaWidgetContents);
        doubleSpinBox_15->setObjectName(QStringLiteral("doubleSpinBox_15"));
        sizePolicy3.setHeightForWidth(doubleSpinBox_15->sizePolicy().hasHeightForWidth());
        doubleSpinBox_15->setSizePolicy(sizePolicy3);
        doubleSpinBox_15->setDecimals(3);
        doubleSpinBox_15->setSingleStep(0.005);

        horizontalLayout_8->addWidget(doubleSpinBox_15);

        label_39 = new QLabel(scrollAreaWidgetContents);
        label_39->setObjectName(QStringLiteral("label_39"));

        horizontalLayout_8->addWidget(label_39);


        verticalLayout->addLayout(horizontalLayout_8);

        horizontalLayout_35 = new QHBoxLayout();
        horizontalLayout_35->setSpacing(6);
        horizontalLayout_35->setObjectName(QStringLiteral("horizontalLayout_35"));
        pushButton_3 = new QPushButton(scrollAreaWidgetContents);
        pushButton_3->setObjectName(QStringLiteral("pushButton_3"));
        sizePolicy2.setHeightForWidth(pushButton_3->sizePolicy().hasHeightForWidth());
        pushButton_3->setSizePolicy(sizePolicy2);

        horizontalLayout_35->addWidget(pushButton_3);

        doubleSpinBox_30 = new QDoubleSpinBox(scrollAreaWidgetContents);
        doubleSpinBox_30->setObjectName(QStringLiteral("doubleSpinBox_30"));
        doubleSpinBox_30->setEnabled(false);
        sizePolicy3.setHeightForWidth(doubleSpinBox_30->sizePolicy().hasHeightForWidth());
        doubleSpinBox_30->setSizePolicy(sizePolicy3);
        doubleSpinBox_30->setMaximum(100);

        horizontalLayout_35->addWidget(doubleSpinBox_30);


        verticalLayout->addLayout(horizontalLayout_35);

        horizontalLayout_51 = new QHBoxLayout();
        horizontalLayout_51->setSpacing(6);
        horizontalLayout_51->setObjectName(QStringLiteral("horizontalLayout_51"));
        label_56 = new QLabel(scrollAreaWidgetContents);
        label_56->setObjectName(QStringLiteral("label_56"));
        sizePolicy.setHeightForWidth(label_56->sizePolicy().hasHeightForWidth());
        label_56->setSizePolicy(sizePolicy);

        horizontalLayout_51->addWidget(label_56);

        doubleSpinBox_31 = new QDoubleSpinBox(scrollAreaWidgetContents);
        doubleSpinBox_31->setObjectName(QStringLiteral("doubleSpinBox_31"));
        doubleSpinBox_31->setEnabled(false);
        sizePolicy3.setHeightForWidth(doubleSpinBox_31->sizePolicy().hasHeightForWidth());
        doubleSpinBox_31->setSizePolicy(sizePolicy3);

        horizontalLayout_51->addWidget(doubleSpinBox_31);


        verticalLayout->addLayout(horizontalLayout_51);

        line = new QFrame(scrollAreaWidgetContents);
        line->setObjectName(QStringLiteral("line"));
        line->setFrameShadow(QFrame::Plain);
        line->setFrameShape(QFrame::HLine);

        verticalLayout->addWidget(line);

        horizontalLayout_72 = new QHBoxLayout();
        horizontalLayout_72->setSpacing(6);
        horizontalLayout_72->setObjectName(QStringLiteral("horizontalLayout_72"));
        label_73 = new QLabel(scrollAreaWidgetContents);
        label_73->setObjectName(QStringLiteral("label_73"));

        horizontalLayout_72->addWidget(label_73);

        comboBox_4 = new QComboBox(scrollAreaWidgetContents);
        comboBox_4->setObjectName(QStringLiteral("comboBox_4"));
        sizePolicy3.setHeightForWidth(comboBox_4->sizePolicy().hasHeightForWidth());
        comboBox_4->setSizePolicy(sizePolicy3);

        horizontalLayout_72->addWidget(comboBox_4);


        verticalLayout->addLayout(horizontalLayout_72);

        horizontalLayout_20 = new QHBoxLayout();
        horizontalLayout_20->setSpacing(6);
        horizontalLayout_20->setObjectName(QStringLiteral("horizontalLayout_20"));
        label_18 = new QLabel(scrollAreaWidgetContents);
        label_18->setObjectName(QStringLiteral("label_18"));
        sizePolicy.setHeightForWidth(label_18->sizePolicy().hasHeightForWidth());
        label_18->setSizePolicy(sizePolicy);

        horizontalLayout_20->addWidget(label_18);

        doubleSpinBox_33 = new QDoubleSpinBox(scrollAreaWidgetContents);
        doubleSpinBox_33->setObjectName(QStringLiteral("doubleSpinBox_33"));
        sizePolicy3.setHeightForWidth(doubleSpinBox_33->sizePolicy().hasHeightForWidth());
        doubleSpinBox_33->setSizePolicy(sizePolicy3);
        doubleSpinBox_33->setDecimals(4);
        doubleSpinBox_33->setMaximum(0.99);
        doubleSpinBox_33->setSingleStep(0.001);

        horizontalLayout_20->addWidget(doubleSpinBox_33);


        verticalLayout->addLayout(horizontalLayout_20);

        horizontalLayout_19 = new QHBoxLayout();
        horizontalLayout_19->setSpacing(6);
        horizontalLayout_19->setObjectName(QStringLiteral("horizontalLayout_19"));
        label_19 = new QLabel(scrollAreaWidgetContents);
        label_19->setObjectName(QStringLiteral("label_19"));
        sizePolicy.setHeightForWidth(label_19->sizePolicy().hasHeightForWidth());
        label_19->setSizePolicy(sizePolicy);

        horizontalLayout_19->addWidget(label_19);

        spinBox_10 = new QSpinBox(scrollAreaWidgetContents);
        spinBox_10->setObjectName(QStringLiteral("spinBox_10"));
        sizePolicy3.setHeightForWidth(spinBox_10->sizePolicy().hasHeightForWidth());
        spinBox_10->setSizePolicy(sizePolicy3);
        spinBox_10->setMaximum(99999);

        horizontalLayout_19->addWidget(spinBox_10);


        verticalLayout->addLayout(horizontalLayout_19);

        horizontalLayout_18 = new QHBoxLayout();
        horizontalLayout_18->setSpacing(6);
        horizontalLayout_18->setObjectName(QStringLiteral("horizontalLayout_18"));
        label_20 = new QLabel(scrollAreaWidgetContents);
        label_20->setObjectName(QStringLiteral("label_20"));
        sizePolicy.setHeightForWidth(label_20->sizePolicy().hasHeightForWidth());
        label_20->setSizePolicy(sizePolicy);

        horizontalLayout_18->addWidget(label_20);

        spinBox_11 = new QSpinBox(scrollAreaWidgetContents);
        spinBox_11->setObjectName(QStringLiteral("spinBox_11"));
        sizePolicy3.setHeightForWidth(spinBox_11->sizePolicy().hasHeightForWidth());
        spinBox_11->setSizePolicy(sizePolicy3);
        spinBox_11->setMaximum(99999);

        horizontalLayout_18->addWidget(spinBox_11);


        verticalLayout->addLayout(horizontalLayout_18);

        horizontalLayout_17 = new QHBoxLayout();
        horizontalLayout_17->setSpacing(6);
        horizontalLayout_17->setObjectName(QStringLiteral("horizontalLayout_17"));
        label_23 = new QLabel(scrollAreaWidgetContents);
        label_23->setObjectName(QStringLiteral("label_23"));
        sizePolicy.setHeightForWidth(label_23->sizePolicy().hasHeightForWidth());
        label_23->setSizePolicy(sizePolicy);

        horizontalLayout_17->addWidget(label_23);

        spinBox_4 = new QSpinBox(scrollAreaWidgetContents);
        spinBox_4->setObjectName(QStringLiteral("spinBox_4"));
        sizePolicy3.setHeightForWidth(spinBox_4->sizePolicy().hasHeightForWidth());
        spinBox_4->setSizePolicy(sizePolicy3);
        spinBox_4->setMinimum(1);
        spinBox_4->setValue(1);

        horizontalLayout_17->addWidget(spinBox_4);


        verticalLayout->addLayout(horizontalLayout_17);

        horizontalLayout_16 = new QHBoxLayout();
        horizontalLayout_16->setSpacing(6);
        horizontalLayout_16->setObjectName(QStringLiteral("horizontalLayout_16"));
        label_24 = new QLabel(scrollAreaWidgetContents);
        label_24->setObjectName(QStringLiteral("label_24"));
        sizePolicy.setHeightForWidth(label_24->sizePolicy().hasHeightForWidth());
        label_24->setSizePolicy(sizePolicy);

        horizontalLayout_16->addWidget(label_24);

        spinBox_5 = new QSpinBox(scrollAreaWidgetContents);
        spinBox_5->setObjectName(QStringLiteral("spinBox_5"));
        sizePolicy3.setHeightForWidth(spinBox_5->sizePolicy().hasHeightForWidth());
        spinBox_5->setSizePolicy(sizePolicy3);
        spinBox_5->setMinimum(1);
        spinBox_5->setValue(1);

        horizontalLayout_16->addWidget(spinBox_5);


        verticalLayout->addLayout(horizontalLayout_16);

        horizontalLayout_15 = new QHBoxLayout();
        horizontalLayout_15->setSpacing(6);
        horizontalLayout_15->setObjectName(QStringLiteral("horizontalLayout_15"));
        label_25 = new QLabel(scrollAreaWidgetContents);
        label_25->setObjectName(QStringLiteral("label_25"));
        sizePolicy.setHeightForWidth(label_25->sizePolicy().hasHeightForWidth());
        label_25->setSizePolicy(sizePolicy);

        horizontalLayout_15->addWidget(label_25);

        spinBox_9 = new QSpinBox(scrollAreaWidgetContents);
        spinBox_9->setObjectName(QStringLiteral("spinBox_9"));
        sizePolicy3.setHeightForWidth(spinBox_9->sizePolicy().hasHeightForWidth());
        spinBox_9->setSizePolicy(sizePolicy3);
        spinBox_9->setMaximum(9999);

        horizontalLayout_15->addWidget(spinBox_9);


        verticalLayout->addLayout(horizontalLayout_15);

        horizontalLayout_14 = new QHBoxLayout();
        horizontalLayout_14->setSpacing(6);
        horizontalLayout_14->setObjectName(QStringLiteral("horizontalLayout_14"));
        label_26 = new QLabel(scrollAreaWidgetContents);
        label_26->setObjectName(QStringLiteral("label_26"));
        sizePolicy.setHeightForWidth(label_26->sizePolicy().hasHeightForWidth());
        label_26->setSizePolicy(sizePolicy);

        horizontalLayout_14->addWidget(label_26);

        doubleSpinBox_17 = new QDoubleSpinBox(scrollAreaWidgetContents);
        doubleSpinBox_17->setObjectName(QStringLiteral("doubleSpinBox_17"));
        sizePolicy2.setHeightForWidth(doubleSpinBox_17->sizePolicy().hasHeightForWidth());
        doubleSpinBox_17->setSizePolicy(sizePolicy2);

        horizontalLayout_14->addWidget(doubleSpinBox_17);


        verticalLayout->addLayout(horizontalLayout_14);

        horizontalLayout_32 = new QHBoxLayout();
        horizontalLayout_32->setSpacing(6);
        horizontalLayout_32->setObjectName(QStringLiteral("horizontalLayout_32"));
        label_36 = new QLabel(scrollAreaWidgetContents);
        label_36->setObjectName(QStringLiteral("label_36"));
        sizePolicy.setHeightForWidth(label_36->sizePolicy().hasHeightForWidth());
        label_36->setSizePolicy(sizePolicy);

        horizontalLayout_32->addWidget(label_36);

        doubleSpinBox_4 = new QDoubleSpinBox(scrollAreaWidgetContents);
        doubleSpinBox_4->setObjectName(QStringLiteral("doubleSpinBox_4"));
        sizePolicy3.setHeightForWidth(doubleSpinBox_4->sizePolicy().hasHeightForWidth());
        doubleSpinBox_4->setSizePolicy(sizePolicy3);
        doubleSpinBox_4->setMinimum(99);
        doubleSpinBox_4->setMaximum(999);
        doubleSpinBox_4->setValue(550);

        horizontalLayout_32->addWidget(doubleSpinBox_4);


        verticalLayout->addLayout(horizontalLayout_32);

        horizontalLayout_33 = new QHBoxLayout();
        horizontalLayout_33->setSpacing(6);
        horizontalLayout_33->setObjectName(QStringLiteral("horizontalLayout_33"));
        label_37 = new QLabel(scrollAreaWidgetContents);
        label_37->setObjectName(QStringLiteral("label_37"));
        sizePolicy.setHeightForWidth(label_37->sizePolicy().hasHeightForWidth());
        label_37->setSizePolicy(sizePolicy);

        horizontalLayout_33->addWidget(label_37);

        doubleSpinBox_3 = new QDoubleSpinBox(scrollAreaWidgetContents);
        doubleSpinBox_3->setObjectName(QStringLiteral("doubleSpinBox_3"));
        sizePolicy3.setHeightForWidth(doubleSpinBox_3->sizePolicy().hasHeightForWidth());
        doubleSpinBox_3->setSizePolicy(sizePolicy3);
        doubleSpinBox_3->setMaximum(1);
        doubleSpinBox_3->setSingleStep(0.05);

        horizontalLayout_33->addWidget(doubleSpinBox_3);


        verticalLayout->addLayout(horizontalLayout_33);

        horizontalLayout_36 = new QHBoxLayout();
        horizontalLayout_36->setSpacing(6);
        horizontalLayout_36->setObjectName(QStringLiteral("horizontalLayout_36"));
        label_57 = new QLabel(scrollAreaWidgetContents);
        label_57->setObjectName(QStringLiteral("label_57"));
        sizePolicy.setHeightForWidth(label_57->sizePolicy().hasHeightForWidth());
        label_57->setSizePolicy(sizePolicy);

        horizontalLayout_36->addWidget(label_57);

        doubleSpinBox_16 = new QDoubleSpinBox(scrollAreaWidgetContents);
        doubleSpinBox_16->setObjectName(QStringLiteral("doubleSpinBox_16"));
        sizePolicy3.setHeightForWidth(doubleSpinBox_16->sizePolicy().hasHeightForWidth());
        doubleSpinBox_16->setSizePolicy(sizePolicy3);
        doubleSpinBox_16->setDecimals(3);
        doubleSpinBox_16->setSingleStep(0.1);

        horizontalLayout_36->addWidget(doubleSpinBox_16);


        verticalLayout->addLayout(horizontalLayout_36);

        horizontalLayout_73 = new QHBoxLayout();
        horizontalLayout_73->setSpacing(6);
        horizontalLayout_73->setObjectName(QStringLiteral("horizontalLayout_73"));
        label_74 = new QLabel(scrollAreaWidgetContents);
        label_74->setObjectName(QStringLiteral("label_74"));

        horizontalLayout_73->addWidget(label_74);

        lineEdit_4 = new QLineEdit(scrollAreaWidgetContents);
        lineEdit_4->setObjectName(QStringLiteral("lineEdit_4"));
        sizePolicy3.setHeightForWidth(lineEdit_4->sizePolicy().hasHeightForWidth());
        lineEdit_4->setSizePolicy(sizePolicy3);

        horizontalLayout_73->addWidget(lineEdit_4);

        pushButton_9 = new QPushButton(scrollAreaWidgetContents);
        pushButton_9->setObjectName(QStringLiteral("pushButton_9"));

        horizontalLayout_73->addWidget(pushButton_9);


        verticalLayout->addLayout(horizontalLayout_73);

        progressBar = new QProgressBar(scrollAreaWidgetContents);
        progressBar->setObjectName(QStringLiteral("progressBar"));
        sizePolicy5.setHeightForWidth(progressBar->sizePolicy().hasHeightForWidth());
        progressBar->setSizePolicy(sizePolicy5);
        progressBar->setValue(24);

        verticalLayout->addWidget(progressBar);

        verticalSpacer = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout->addItem(verticalSpacer);


        horizontalLayout_61->addLayout(verticalLayout);

        line_6 = new QFrame(scrollAreaWidgetContents);
        line_6->setObjectName(QStringLiteral("line_6"));
        line_6->setFrameShadow(QFrame::Plain);
        line_6->setFrameShape(QFrame::VLine);

        horizontalLayout_61->addWidget(line_6);

        verticalLayout_4 = new QVBoxLayout();
        verticalLayout_4->setSpacing(6);
        verticalLayout_4->setObjectName(QStringLiteral("verticalLayout_4"));
        label_44 = new QLabel(scrollAreaWidgetContents);
        label_44->setObjectName(QStringLiteral("label_44"));

        verticalLayout_4->addWidget(label_44);

        horizontalLayout_37 = new QHBoxLayout();
        horizontalLayout_37->setSpacing(6);
        horizontalLayout_37->setObjectName(QStringLiteral("horizontalLayout_37"));
        label_45 = new QLabel(scrollAreaWidgetContents);
        label_45->setObjectName(QStringLiteral("label_45"));

        horizontalLayout_37->addWidget(label_45);

        lineEdit_25 = new QLineEdit(scrollAreaWidgetContents);
        lineEdit_25->setObjectName(QStringLiteral("lineEdit_25"));
        lineEdit_25->setEnabled(false);
        sizePolicy3.setHeightForWidth(lineEdit_25->sizePolicy().hasHeightForWidth());
        lineEdit_25->setSizePolicy(sizePolicy3);
        lineEdit_25->setMinimumSize(QSize(30, 0));

        horizontalLayout_37->addWidget(lineEdit_25);


        verticalLayout_4->addLayout(horizontalLayout_37);

        horizontalLayout_45 = new QHBoxLayout();
        horizontalLayout_45->setSpacing(6);
        horizontalLayout_45->setObjectName(QStringLiteral("horizontalLayout_45"));
        label_46 = new QLabel(scrollAreaWidgetContents);
        label_46->setObjectName(QStringLiteral("label_46"));

        horizontalLayout_45->addWidget(label_46);

        lineEdit_26 = new QLineEdit(scrollAreaWidgetContents);
        lineEdit_26->setObjectName(QStringLiteral("lineEdit_26"));
        lineEdit_26->setEnabled(false);
        sizePolicy3.setHeightForWidth(lineEdit_26->sizePolicy().hasHeightForWidth());
        lineEdit_26->setSizePolicy(sizePolicy3);

        horizontalLayout_45->addWidget(lineEdit_26);


        verticalLayout_4->addLayout(horizontalLayout_45);

        horizontalLayout_44 = new QHBoxLayout();
        horizontalLayout_44->setSpacing(6);
        horizontalLayout_44->setObjectName(QStringLiteral("horizontalLayout_44"));
        label_47 = new QLabel(scrollAreaWidgetContents);
        label_47->setObjectName(QStringLiteral("label_47"));

        horizontalLayout_44->addWidget(label_47);

        lineEdit_27 = new QLineEdit(scrollAreaWidgetContents);
        lineEdit_27->setObjectName(QStringLiteral("lineEdit_27"));
        lineEdit_27->setEnabled(false);
        sizePolicy3.setHeightForWidth(lineEdit_27->sizePolicy().hasHeightForWidth());
        lineEdit_27->setSizePolicy(sizePolicy3);

        horizontalLayout_44->addWidget(lineEdit_27);


        verticalLayout_4->addLayout(horizontalLayout_44);

        horizontalLayout_43 = new QHBoxLayout();
        horizontalLayout_43->setSpacing(6);
        horizontalLayout_43->setObjectName(QStringLiteral("horizontalLayout_43"));
        label_48 = new QLabel(scrollAreaWidgetContents);
        label_48->setObjectName(QStringLiteral("label_48"));
        sizePolicy.setHeightForWidth(label_48->sizePolicy().hasHeightForWidth());
        label_48->setSizePolicy(sizePolicy);

        horizontalLayout_43->addWidget(label_48);

        lineEdit_28 = new QLineEdit(scrollAreaWidgetContents);
        lineEdit_28->setObjectName(QStringLiteral("lineEdit_28"));
        lineEdit_28->setEnabled(false);
        sizePolicy3.setHeightForWidth(lineEdit_28->sizePolicy().hasHeightForWidth());
        lineEdit_28->setSizePolicy(sizePolicy3);

        horizontalLayout_43->addWidget(lineEdit_28);


        verticalLayout_4->addLayout(horizontalLayout_43);

        horizontalLayout_42 = new QHBoxLayout();
        horizontalLayout_42->setSpacing(6);
        horizontalLayout_42->setObjectName(QStringLiteral("horizontalLayout_42"));
        label_49 = new QLabel(scrollAreaWidgetContents);
        label_49->setObjectName(QStringLiteral("label_49"));
        sizePolicy.setHeightForWidth(label_49->sizePolicy().hasHeightForWidth());
        label_49->setSizePolicy(sizePolicy);

        horizontalLayout_42->addWidget(label_49);

        lineEdit_29 = new QLineEdit(scrollAreaWidgetContents);
        lineEdit_29->setObjectName(QStringLiteral("lineEdit_29"));
        lineEdit_29->setEnabled(false);
        sizePolicy3.setHeightForWidth(lineEdit_29->sizePolicy().hasHeightForWidth());
        lineEdit_29->setSizePolicy(sizePolicy3);

        horizontalLayout_42->addWidget(lineEdit_29);


        verticalLayout_4->addLayout(horizontalLayout_42);

        horizontalLayout_41 = new QHBoxLayout();
        horizontalLayout_41->setSpacing(6);
        horizontalLayout_41->setObjectName(QStringLiteral("horizontalLayout_41"));
        label_50 = new QLabel(scrollAreaWidgetContents);
        label_50->setObjectName(QStringLiteral("label_50"));

        horizontalLayout_41->addWidget(label_50);

        lineEdit_30 = new QLineEdit(scrollAreaWidgetContents);
        lineEdit_30->setObjectName(QStringLiteral("lineEdit_30"));
        lineEdit_30->setEnabled(false);
        sizePolicy3.setHeightForWidth(lineEdit_30->sizePolicy().hasHeightForWidth());
        lineEdit_30->setSizePolicy(sizePolicy3);

        horizontalLayout_41->addWidget(lineEdit_30);


        verticalLayout_4->addLayout(horizontalLayout_41);

        horizontalLayout_40 = new QHBoxLayout();
        horizontalLayout_40->setSpacing(6);
        horizontalLayout_40->setObjectName(QStringLiteral("horizontalLayout_40"));
        label_51 = new QLabel(scrollAreaWidgetContents);
        label_51->setObjectName(QStringLiteral("label_51"));

        horizontalLayout_40->addWidget(label_51);

        lineEdit_31 = new QLineEdit(scrollAreaWidgetContents);
        lineEdit_31->setObjectName(QStringLiteral("lineEdit_31"));
        lineEdit_31->setEnabled(false);
        sizePolicy3.setHeightForWidth(lineEdit_31->sizePolicy().hasHeightForWidth());
        lineEdit_31->setSizePolicy(sizePolicy3);

        horizontalLayout_40->addWidget(lineEdit_31);


        verticalLayout_4->addLayout(horizontalLayout_40);

        horizontalLayout_39 = new QHBoxLayout();
        horizontalLayout_39->setSpacing(6);
        horizontalLayout_39->setObjectName(QStringLiteral("horizontalLayout_39"));
        label_52 = new QLabel(scrollAreaWidgetContents);
        label_52->setObjectName(QStringLiteral("label_52"));

        horizontalLayout_39->addWidget(label_52);

        lineEdit_32 = new QLineEdit(scrollAreaWidgetContents);
        lineEdit_32->setObjectName(QStringLiteral("lineEdit_32"));
        lineEdit_32->setEnabled(false);
        sizePolicy3.setHeightForWidth(lineEdit_32->sizePolicy().hasHeightForWidth());
        lineEdit_32->setSizePolicy(sizePolicy3);

        horizontalLayout_39->addWidget(lineEdit_32);


        verticalLayout_4->addLayout(horizontalLayout_39);

        horizontalLayout_38 = new QHBoxLayout();
        horizontalLayout_38->setSpacing(6);
        horizontalLayout_38->setObjectName(QStringLiteral("horizontalLayout_38"));
        label_53 = new QLabel(scrollAreaWidgetContents);
        label_53->setObjectName(QStringLiteral("label_53"));

        horizontalLayout_38->addWidget(label_53);

        lineEdit_33 = new QLineEdit(scrollAreaWidgetContents);
        lineEdit_33->setObjectName(QStringLiteral("lineEdit_33"));
        lineEdit_33->setEnabled(false);
        sizePolicy3.setHeightForWidth(lineEdit_33->sizePolicy().hasHeightForWidth());
        lineEdit_33->setSizePolicy(sizePolicy3);

        horizontalLayout_38->addWidget(lineEdit_33);


        verticalLayout_4->addLayout(horizontalLayout_38);

        horizontalLayout_47 = new QHBoxLayout();
        horizontalLayout_47->setSpacing(6);
        horizontalLayout_47->setObjectName(QStringLiteral("horizontalLayout_47"));
        pushButton_4 = new QPushButton(scrollAreaWidgetContents);
        pushButton_4->setObjectName(QStringLiteral("pushButton_4"));
        sizePolicy3.setHeightForWidth(pushButton_4->sizePolicy().hasHeightForWidth());
        pushButton_4->setSizePolicy(sizePolicy3);

        horizontalLayout_47->addWidget(pushButton_4);

        pushButton_5 = new QPushButton(scrollAreaWidgetContents);
        pushButton_5->setObjectName(QStringLiteral("pushButton_5"));
        sizePolicy3.setHeightForWidth(pushButton_5->sizePolicy().hasHeightForWidth());
        pushButton_5->setSizePolicy(sizePolicy3);

        horizontalLayout_47->addWidget(pushButton_5);

        pushButton_6 = new QPushButton(scrollAreaWidgetContents);
        pushButton_6->setObjectName(QStringLiteral("pushButton_6"));
        sizePolicy3.setHeightForWidth(pushButton_6->sizePolicy().hasHeightForWidth());
        pushButton_6->setSizePolicy(sizePolicy3);

        horizontalLayout_47->addWidget(pushButton_6);


        verticalLayout_4->addLayout(horizontalLayout_47);

        horizontalLayout_49 = new QHBoxLayout();
        horizontalLayout_49->setSpacing(6);
        horizontalLayout_49->setObjectName(QStringLiteral("horizontalLayout_49"));
        label_54 = new QLabel(scrollAreaWidgetContents);
        label_54->setObjectName(QStringLiteral("label_54"));
        sizePolicy.setHeightForWidth(label_54->sizePolicy().hasHeightForWidth());
        label_54->setSizePolicy(sizePolicy);

        horizontalLayout_49->addWidget(label_54);

        lineEdit_34 = new QLineEdit(scrollAreaWidgetContents);
        lineEdit_34->setObjectName(QStringLiteral("lineEdit_34"));
        lineEdit_34->setEnabled(false);
        sizePolicy3.setHeightForWidth(lineEdit_34->sizePolicy().hasHeightForWidth());
        lineEdit_34->setSizePolicy(sizePolicy3);

        horizontalLayout_49->addWidget(lineEdit_34);


        verticalLayout_4->addLayout(horizontalLayout_49);

        horizontalLayout_50 = new QHBoxLayout();
        horizontalLayout_50->setSpacing(6);
        horizontalLayout_50->setObjectName(QStringLiteral("horizontalLayout_50"));
        label_55 = new QLabel(scrollAreaWidgetContents);
        label_55->setObjectName(QStringLiteral("label_55"));

        horizontalLayout_50->addWidget(label_55);

        lineEdit_35 = new QLineEdit(scrollAreaWidgetContents);
        lineEdit_35->setObjectName(QStringLiteral("lineEdit_35"));
        lineEdit_35->setEnabled(false);
        sizePolicy3.setHeightForWidth(lineEdit_35->sizePolicy().hasHeightForWidth());
        lineEdit_35->setSizePolicy(sizePolicy3);

        horizontalLayout_50->addWidget(lineEdit_35);


        verticalLayout_4->addLayout(horizontalLayout_50);

        horizontalLayout_56 = new QHBoxLayout();
        horizontalLayout_56->setSpacing(6);
        horizontalLayout_56->setObjectName(QStringLiteral("horizontalLayout_56"));
        label_62 = new QLabel(scrollAreaWidgetContents);
        label_62->setObjectName(QStringLiteral("label_62"));

        horizontalLayout_56->addWidget(label_62);

        lineEdit_37 = new QLineEdit(scrollAreaWidgetContents);
        lineEdit_37->setObjectName(QStringLiteral("lineEdit_37"));
        lineEdit_37->setEnabled(false);
        sizePolicy3.setHeightForWidth(lineEdit_37->sizePolicy().hasHeightForWidth());
        lineEdit_37->setSizePolicy(sizePolicy3);

        horizontalLayout_56->addWidget(lineEdit_37);


        verticalLayout_4->addLayout(horizontalLayout_56);

        horizontalLayout_68 = new QHBoxLayout();
        horizontalLayout_68->setSpacing(6);
        horizontalLayout_68->setObjectName(QStringLiteral("horizontalLayout_68"));
        comboBox_3 = new QComboBox(scrollAreaWidgetContents);
        comboBox_3->setObjectName(QStringLiteral("comboBox_3"));
        sizePolicy3.setHeightForWidth(comboBox_3->sizePolicy().hasHeightForWidth());
        comboBox_3->setSizePolicy(sizePolicy3);

        horizontalLayout_68->addWidget(comboBox_3);

        pushButton_7 = new QPushButton(scrollAreaWidgetContents);
        pushButton_7->setObjectName(QStringLiteral("pushButton_7"));
        sizePolicy3.setHeightForWidth(pushButton_7->sizePolicy().hasHeightForWidth());
        pushButton_7->setSizePolicy(sizePolicy3);

        horizontalLayout_68->addWidget(pushButton_7);


        verticalLayout_4->addLayout(horizontalLayout_68);

        customPlot = new QCustomPlot(scrollAreaWidgetContents);
        customPlot->setObjectName(QStringLiteral("customPlot"));
        sizePolicy7.setHeightForWidth(customPlot->sizePolicy().hasHeightForWidth());
        customPlot->setSizePolicy(sizePolicy7);
        customPlot->setMinimumSize(QSize(293, 150));

        verticalLayout_4->addWidget(customPlot);


        horizontalLayout_61->addLayout(verticalLayout_4);

        line_7 = new QFrame(scrollAreaWidgetContents);
        line_7->setObjectName(QStringLiteral("line_7"));
        line_7->setFrameShadow(QFrame::Plain);
        line_7->setFrameShape(QFrame::VLine);

        horizontalLayout_61->addWidget(line_7);

        verticalLayout_3 = new QVBoxLayout();
        verticalLayout_3->setSpacing(6);
        verticalLayout_3->setObjectName(QStringLiteral("verticalLayout_3"));
        label_42 = new QLabel(scrollAreaWidgetContents);
        label_42->setObjectName(QStringLiteral("label_42"));

        verticalLayout_3->addWidget(label_42);

        horizontalLayout_46 = new QHBoxLayout();
        horizontalLayout_46->setSpacing(6);
        horizontalLayout_46->setObjectName(QStringLiteral("horizontalLayout_46"));
        label_43 = new QLabel(scrollAreaWidgetContents);
        label_43->setObjectName(QStringLiteral("label_43"));

        horizontalLayout_46->addWidget(label_43);

        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_46->addItem(horizontalSpacer);


        verticalLayout_3->addLayout(horizontalLayout_46);

        customPlot_3 = new QCustomPlot(scrollAreaWidgetContents);
        customPlot_3->setObjectName(QStringLiteral("customPlot_3"));
        QSizePolicy sizePolicy9(QSizePolicy::MinimumExpanding, QSizePolicy::MinimumExpanding);
        sizePolicy9.setHorizontalStretch(0);
        sizePolicy9.setVerticalStretch(0);
        sizePolicy9.setHeightForWidth(customPlot_3->sizePolicy().hasHeightForWidth());
        customPlot_3->setSizePolicy(sizePolicy9);
        customPlot_3->setMinimumSize(QSize(200, 130));

        verticalLayout_3->addWidget(customPlot_3);

        horizontalLayout_48 = new QHBoxLayout();
        horizontalLayout_48->setSpacing(6);
        horizontalLayout_48->setObjectName(QStringLiteral("horizontalLayout_48"));
        label_63 = new QLabel(scrollAreaWidgetContents);
        label_63->setObjectName(QStringLiteral("label_63"));

        horizontalLayout_48->addWidget(label_63);

        horizontalSpacer_2 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_48->addItem(horizontalSpacer_2);


        verticalLayout_3->addLayout(horizontalLayout_48);

        customPlot_4 = new QCustomPlot(scrollAreaWidgetContents);
        customPlot_4->setObjectName(QStringLiteral("customPlot_4"));
        sizePolicy9.setHeightForWidth(customPlot_4->sizePolicy().hasHeightForWidth());
        customPlot_4->setSizePolicy(sizePolicy9);
        customPlot_4->setMinimumSize(QSize(200, 130));

        verticalLayout_3->addWidget(customPlot_4);

        horizontalLayout_58 = new QHBoxLayout();
        horizontalLayout_58->setSpacing(6);
        horizontalLayout_58->setObjectName(QStringLiteral("horizontalLayout_58"));
        label_64 = new QLabel(scrollAreaWidgetContents);
        label_64->setObjectName(QStringLiteral("label_64"));

        horizontalLayout_58->addWidget(label_64);

        horizontalSpacer_3 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_58->addItem(horizontalSpacer_3);


        verticalLayout_3->addLayout(horizontalLayout_58);

        customPlot_5 = new QCustomPlot(scrollAreaWidgetContents);
        customPlot_5->setObjectName(QStringLiteral("customPlot_5"));
        sizePolicy9.setHeightForWidth(customPlot_5->sizePolicy().hasHeightForWidth());
        customPlot_5->setSizePolicy(sizePolicy9);
        customPlot_5->setMinimumSize(QSize(200, 130));

        verticalLayout_3->addWidget(customPlot_5);

        horizontalLayout_62 = new QHBoxLayout();
        horizontalLayout_62->setSpacing(6);
        horizontalLayout_62->setObjectName(QStringLiteral("horizontalLayout_62"));
        label_9 = new QLabel(scrollAreaWidgetContents);
        label_9->setObjectName(QStringLiteral("label_9"));

        horizontalLayout_62->addWidget(label_9);

        horizontalSpacer_4 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_62->addItem(horizontalSpacer_4);


        verticalLayout_3->addLayout(horizontalLayout_62);

        customPlot_2 = new QCustomPlot(scrollAreaWidgetContents);
        customPlot_2->setObjectName(QStringLiteral("customPlot_2"));
        sizePolicy9.setHeightForWidth(customPlot_2->sizePolicy().hasHeightForWidth());
        customPlot_2->setSizePolicy(sizePolicy9);
        customPlot_2->setMinimumSize(QSize(200, 130));

        verticalLayout_3->addWidget(customPlot_2);


        horizontalLayout_61->addLayout(verticalLayout_3);

        scrollArea->setWidget(scrollAreaWidgetContents);

        gridLayout->addWidget(scrollArea, 0, 0, 1, 1);

        MainWindow->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(MainWindow);
        menuBar->setObjectName(QStringLiteral("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 1612, 20));
        menuClassical = new QMenu(menuBar);
        menuClassical->setObjectName(QStringLiteral("menuClassical"));
        menuTools = new QMenu(menuBar);
        menuTools->setObjectName(QStringLiteral("menuTools"));
        menuFrame = new QMenu(menuBar);
        menuFrame->setObjectName(QStringLiteral("menuFrame"));
        menuHelp = new QMenu(menuBar);
        menuHelp->setObjectName(QStringLiteral("menuHelp"));
        menuTools_2 = new QMenu(menuBar);
        menuTools_2->setObjectName(QStringLiteral("menuTools_2"));
        menuFile = new QMenu(menuBar);
        menuFile->setObjectName(QStringLiteral("menuFile"));
        menuEdit = new QMenu(menuBar);
        menuEdit->setObjectName(QStringLiteral("menuEdit"));
        MainWindow->setMenuBar(menuBar);
        mainToolBar = new QToolBar(MainWindow);
        mainToolBar->setObjectName(QStringLiteral("mainToolBar"));
        sizePolicy3.setHeightForWidth(mainToolBar->sizePolicy().hasHeightForWidth());
        mainToolBar->setSizePolicy(sizePolicy3);
        mainToolBar->setIconSize(QSize(22, 22));
        mainToolBar->setToolButtonStyle(Qt::ToolButtonIconOnly);
        MainWindow->addToolBar(Qt::TopToolBarArea, mainToolBar);
        statusBar = new QStatusBar(MainWindow);
        statusBar->setObjectName(QStringLiteral("statusBar"));
        MainWindow->setStatusBar(statusBar);

        menuBar->addAction(menuFile->menuAction());
        menuBar->addAction(menuEdit->menuAction());
        menuBar->addAction(menuClassical->menuAction());
        menuBar->addAction(menuTools->menuAction());
        menuBar->addAction(menuFrame->menuAction());
        menuBar->addAction(menuTools_2->menuAction());
        menuBar->addAction(menuHelp->menuAction());
        menuClassical->addAction(actionClassical);
        menuClassical->addAction(action3D_Spectrograph);
        menuTools->addAction(actionParameters);
        menuTools->addAction(actionClassical_2);
        menuTools->addAction(action3D);
        menuFrame->addAction(action3D_Frame);
        menuFrame->addAction(actionEchelle_Frame);
        menuFrame->addAction(actionClassical_Frame);
        menuHelp->addAction(actionAbout);
        menuHelp->addAction(actionBug_Report);
        menuHelp->addAction(actionManual);
        menuHelp->addAction(actionBasics);
        menuTools_2->addAction(actionVPHG);
        menuTools_2->addAction(actionOptical_Fibres);
        menuTools_2->addAction(actionTSI);
        menuTools_2->addAction(actionFPE);
        menuTools_2->addAction(actionCzerny_Turner);
        menuTools_2->addAction(actionPetzval);
        menuTools_2->addAction(actionNotes);
        menuFile->addAction(actionNew);
        menuFile->addAction(actionOpen);
        menuFile->addSeparator();
        menuFile->addAction(actionSave);
        menuFile->addAction(actionSave_AS);
        menuEdit->addAction(actionUndo);
        menuEdit->addAction(actionRedo);
        mainToolBar->addAction(actionSave);
        mainToolBar->addAction(actionSave_AS);
        mainToolBar->addSeparator();
        mainToolBar->addAction(actionOpen);
        mainToolBar->addAction(actionNew);

        retranslateUi(MainWindow);
        QObject::connect(pushButton, SIGNAL(clicked()), MainWindow, SLOT(close()));

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "MainWindow", Q_NULLPTR));
        actionParameters->setText(QApplication::translate("MainWindow", "Echelle", Q_NULLPTR));
        actionClassical->setText(QApplication::translate("MainWindow", "Classical", Q_NULLPTR));
        action3D_Spectrograph->setText(QApplication::translate("MainWindow", "3D", Q_NULLPTR));
        actionClassical_2->setText(QApplication::translate("MainWindow", "Classical", Q_NULLPTR));
        action3D->setText(QApplication::translate("MainWindow", "3D", Q_NULLPTR));
        action3D_Frame->setText(QApplication::translate("MainWindow", "3D Frame", Q_NULLPTR));
        actionEchelle_Frame->setText(QApplication::translate("MainWindow", "Echelle Frame", Q_NULLPTR));
        actionAbout->setText(QApplication::translate("MainWindow", "About", Q_NULLPTR));
        actionBug_Report->setText(QApplication::translate("MainWindow", "Bug Report", Q_NULLPTR));
        actionManual->setText(QApplication::translate("MainWindow", "Manual", Q_NULLPTR));
        actionBasics->setText(QApplication::translate("MainWindow", "Basics Astro. Spectrographs", Q_NULLPTR));
        actionVPHG->setText(QApplication::translate("MainWindow", "VPHG", Q_NULLPTR));
        actionOptical_Fibres->setText(QApplication::translate("MainWindow", "Optical Fibres", Q_NULLPTR));
        actionClassical_Frame->setText(QApplication::translate("MainWindow", "Classical Frame", Q_NULLPTR));
        actionTSI->setText(QApplication::translate("MainWindow", "TSI", Q_NULLPTR));
        actionNotes->setText(QApplication::translate("MainWindow", "Notes", Q_NULLPTR));
        actionNew->setText(QApplication::translate("MainWindow", "New", Q_NULLPTR));
        actionOpen->setText(QApplication::translate("MainWindow", "Open", Q_NULLPTR));
        actionSave->setText(QApplication::translate("MainWindow", "Save", Q_NULLPTR));
        actionSave_AS->setText(QApplication::translate("MainWindow", "Save AS", Q_NULLPTR));
        actionUndo->setText(QApplication::translate("MainWindow", "Undo", Q_NULLPTR));
        actionRedo->setText(QApplication::translate("MainWindow", "Redo", Q_NULLPTR));
        actionFPE->setText(QApplication::translate("MainWindow", "FPE", Q_NULLPTR));
        actionCzerny_Turner->setText(QApplication::translate("MainWindow", "Czerny-Turner", Q_NULLPTR));
        actionPetzval->setText(QApplication::translate("MainWindow", "Petzval", Q_NULLPTR));
        label->setText(QApplication::translate("MainWindow", "<html><head/><body><p><span style=\" font-size:12pt; font-style:italic; text-decoration: underline;\">Optical &amp; Geometrical Parameters</span></p></body></html>", Q_NULLPTR));
        label_10->setText(QApplication::translate("MainWindow", "Echelle Line Density [l/mm]:", Q_NULLPTR));
        label_58->setText(QApplication::translate("MainWindow", "Peak Efficiency:", Q_NULLPTR));
        label_16->setText(QApplication::translate("MainWindow", "Blaze Angle [deg]:", Q_NULLPTR));
        label_13->setText(QApplication::translate("MainWindow", "Total Angle [deg]:", Q_NULLPTR));
        label_33->setText(QApplication::translate("MainWindow", "Wavelength [nm]:", Q_NULLPTR));
        label_34->setText(QApplication::translate("MainWindow", "to", Q_NULLPTR));
        label_11->setText(QApplication::translate("MainWindow", "Focal Length Collimator [mm]:", Q_NULLPTR));
        label_12->setText(QApplication::translate("MainWindow", "Focal Length Camera [mm]:", Q_NULLPTR));
        checkBox_2->setText(QApplication::translate("MainWindow", "WP Configuration", Q_NULLPTR));
        checkBox_3->setText(QApplication::translate("MainWindow", "Double Prism", Q_NULLPTR));
        label_75->setText(QApplication::translate("MainWindow", "2nd Coll. Focal Length [mm]:", Q_NULLPTR));
        label_71->setText(QApplication::translate("MainWindow", "Trans. Coll Focal Length: [mm]:", Q_NULLPTR));
        label_2->setText(QApplication::translate("MainWindow", "X-Disperser:", Q_NULLPTR));
        label_27->setText(QApplication::translate("MainWindow", "XD Line Density [l/mm]:", Q_NULLPTR));
        label_28->setText(QApplication::translate("MainWindow", "Total Angle at XD [deg]:", Q_NULLPTR));
        label_59->setText(QApplication::translate("MainWindow", "Blaze Angle [deg]:", Q_NULLPTR));
        label_60->setText(QApplication::translate("MainWindow", "Peak Efficiency:", Q_NULLPTR));
        label_67->setText(QApplication::translate("MainWindow", "Index of DCG Layer:", Q_NULLPTR));
        label_69->setText(QApplication::translate("MainWindow", "Thickness of DCG Layer [mm]:", Q_NULLPTR));
        label_68->setText(QApplication::translate("MainWindow", "Semiamplitude of Modulation:", Q_NULLPTR));
        label_70->setText(QApplication::translate("MainWindow", "Tune Wavelength [nm]:", Q_NULLPTR));
        label_14->setText(QApplication::translate("MainWindow", "Material XD:", Q_NULLPTR));
        label_35->setText(QApplication::translate("MainWindow", "Grism Angle:", Q_NULLPTR));
        label_72->setText(QApplication::translate("MainWindow", "Glass Data:", Q_NULLPTR));
        pushButton_8->setText(QApplication::translate("MainWindow", "Reload", Q_NULLPTR));
        label_41->setText(QApplication::translate("MainWindow", "Work Path:", Q_NULLPTR));
        pushButton_10->setText(QApplication::translate("MainWindow", "Copy Files", Q_NULLPTR));
        pushButton->setText(QApplication::translate("MainWindow", "Close", Q_NULLPTR));
        label_3->setText(QApplication::translate("MainWindow", "<html><head/><body><p><span style=\" font-size:12pt; text-decoration: underline;\">Efficiency Data</span></p></body></html>", Q_NULLPTR));
        label_5->setText(QApplication::translate("MainWindow", "# Silver Surfaces:", Q_NULLPTR));
        label_6->setText(QApplication::translate("MainWindow", "# Aluminium Surfaces:", Q_NULLPTR));
        label_65->setText(QApplication::translate("MainWindow", "# Aluminium UV Surfaces:", Q_NULLPTR));
        label_66->setText(QApplication::translate("MainWindow", "# Gold Surfaces:", Q_NULLPTR));
        label_8->setText(QApplication::translate("MainWindow", "# VIS AR Coated Surfaces:", Q_NULLPTR));
        checkBox_11->setText(QApplication::translate("MainWindow", "Transmission File: ", Q_NULLPTR));
        label_7->setText(QApplication::translate("MainWindow", "Uncoated Glass Surfaces:", Q_NULLPTR));
        pushButton_2->setText(QApplication::translate("MainWindow", "Efficiency [%]:", Q_NULLPTR));
        label_29->setText(QApplication::translate("MainWindow", "<html><head/><body><p><span style=\" font-size:12pt; font-weight:600;\">Object Data</span></p></body></html>", Q_NULLPTR));
        label_30->setText(QApplication::translate("MainWindow", "Effective Temperature [K]:", Q_NULLPTR));
#ifndef QT_NO_TOOLTIP
        doubleSpinBox_9->setToolTip(QString());
#endif // QT_NO_TOOLTIP
#ifndef QT_NO_WHATSTHIS
        doubleSpinBox_9->setWhatsThis(QString());
#endif // QT_NO_WHATSTHIS
        label_38->setText(QApplication::translate("MainWindow", "BC [mag]:", Q_NULLPTR));
        label_31->setText(QApplication::translate("MainWindow", "Visual Magnitude [mag]:", Q_NULLPTR));
        label_32->setText(QApplication::translate("MainWindow", "Zenit Distance [deg]:", Q_NULLPTR));
        label_61->setText(QApplication::translate("MainWindow", "Exposure Time [s]:", Q_NULLPTR));
        label_4->setText(QApplication::translate("MainWindow", "<html><head/><body><p><span style=\" font-size:12pt; text-decoration: underline;\">Telescope, Slit &amp; CCD Data</span></p></body></html>", Q_NULLPTR));
        label_17->setText(QApplication::translate("MainWindow", "Seeing [arcsec]:", Q_NULLPTR));
        label_21->setText(QApplication::translate("MainWindow", "Focal Length [mm]:", Q_NULLPTR));
        label_22->setText(QApplication::translate("MainWindow", "Diameter [mm]:", Q_NULLPTR));
        label_15->setText(QApplication::translate("MainWindow", "Slit:", Q_NULLPTR));
        checkBox_8->setText(QApplication::translate("MainWindow", "circular", Q_NULLPTR));
        checkBox_9->setText(QApplication::translate("MainWindow", "rectangular", Q_NULLPTR));
        checkBox->setText(QApplication::translate("MainWindow", "slitless", Q_NULLPTR));
        label_40->setText(QApplication::translate("MainWindow", "mm x", Q_NULLPTR));
        label_39->setText(QApplication::translate("MainWindow", "mm", Q_NULLPTR));
        pushButton_3->setText(QApplication::translate("MainWindow", "Efficiency [%]:", Q_NULLPTR));
        label_56->setText(QApplication::translate("MainWindow", "Width on Sky [arcsec]:", Q_NULLPTR));
        label_73->setText(QApplication::translate("MainWindow", "CCD:", Q_NULLPTR));
        label_18->setText(QApplication::translate("MainWindow", "Pixel Size [mm]:", Q_NULLPTR));
        label_19->setText(QApplication::translate("MainWindow", "Pixel in x:", Q_NULLPTR));
        label_20->setText(QApplication::translate("MainWindow", "Pixel in y:", Q_NULLPTR));
        label_23->setText(QApplication::translate("MainWindow", "Binning x:", Q_NULLPTR));
        label_24->setText(QApplication::translate("MainWindow", "Binning y:", Q_NULLPTR));
        label_25->setText(QApplication::translate("MainWindow", "<html><head/><body><p>CCD Bias [ADU]:</p></body></html>", Q_NULLPTR));
        label_26->setText(QApplication::translate("MainWindow", "<html><head/><body><p>CCD Noise [ADU]:</p></body></html>", Q_NULLPTR));
        label_36->setText(QApplication::translate("MainWindow", "CCD Peak Wavelength [nm]:", Q_NULLPTR));
        label_37->setText(QApplication::translate("MainWindow", "CCD Peak Efficiency:", Q_NULLPTR));
        label_57->setText(QApplication::translate("MainWindow", "CCD  Gain [e/ADU]:", Q_NULLPTR));
        label_74->setText(QApplication::translate("MainWindow", "CCD Data Base:", Q_NULLPTR));
        pushButton_9->setText(QApplication::translate("MainWindow", "Reload", Q_NULLPTR));
        label_44->setText(QApplication::translate("MainWindow", "<html><head/><body><p><span style=\" font-size:12pt; text-decoration: underline; color:#16345e;\">System Output Overview</span></p></body></html>", Q_NULLPTR));
        label_45->setText(QApplication::translate("MainWindow", "Central Wavelength [nm]:", Q_NULLPTR));
        label_46->setText(QApplication::translate("MainWindow", "Angle of Incidence @ CD:", Q_NULLPTR));
        label_47->setText(QApplication::translate("MainWindow", "Angle of Diffraction @ CD:", Q_NULLPTR));
        label_48->setText(QApplication::translate("MainWindow", "Lower Central Wavelength [nm]:", Q_NULLPTR));
        label_49->setText(QApplication::translate("MainWindow", "Upper Central Wavelength [nm]:", Q_NULLPTR));
        label_50->setText(QApplication::translate("MainWindow", "Lower Wavelength [nm]:", Q_NULLPTR));
        label_51->setText(QApplication::translate("MainWindow", "Upper Wavelength [nm]:", Q_NULLPTR));
        label_52->setText(QApplication::translate("MainWindow", "Lower Diffraction Order:", Q_NULLPTR));
        label_53->setText(QApplication::translate("MainWindow", "Upper Diffraction Order:", Q_NULLPTR));
        pushButton_4->setText(QApplication::translate("MainWindow", "Overview", Q_NULLPTR));
        pushButton_5->setText(QApplication::translate("MainWindow", "Parameters", Q_NULLPTR));
        pushButton_6->setText(QApplication::translate("MainWindow", "\303\211chellogram", Q_NULLPTR));
        label_54->setText(QApplication::translate("MainWindow", "Upper Diffraction Order on CCD:", Q_NULLPTR));
        label_55->setText(QApplication::translate("MainWindow", "Upper Wavelength on CCD:", Q_NULLPTR));
        label_62->setText(QApplication::translate("MainWindow", "y of Upper Diffraction Order:", Q_NULLPTR));
        pushButton_7->setText(QApplication::translate("MainWindow", "Frame", Q_NULLPTR));
        label_42->setText(QApplication::translate("MainWindow", "<html><head/><body><p><span style=\" font-size:12pt; text-decoration: underline; color:#16345e;\">Outputs</span></p></body></html>", Q_NULLPTR));
        label_43->setText(QApplication::translate("MainWindow", "Averaged Efficiency", Q_NULLPTR));
        label_63->setText(QApplication::translate("MainWindow", "Signal", Q_NULLPTR));
        label_64->setText(QApplication::translate("MainWindow", "SNR", Q_NULLPTR));
        label_9->setText(QApplication::translate("MainWindow", "Order Separation", Q_NULLPTR));
        menuClassical->setTitle(QApplication::translate("MainWindow", "Spec", Q_NULLPTR));
        menuTools->setTitle(QApplication::translate("MainWindow", "Parameters", Q_NULLPTR));
        menuFrame->setTitle(QApplication::translate("MainWindow", "Frame", Q_NULLPTR));
        menuHelp->setTitle(QApplication::translate("MainWindow", "Help", Q_NULLPTR));
        menuTools_2->setTitle(QApplication::translate("MainWindow", "Tools", Q_NULLPTR));
        menuFile->setTitle(QApplication::translate("MainWindow", "File", Q_NULLPTR));
        menuEdit->setTitle(QApplication::translate("MainWindow", "Edit", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
