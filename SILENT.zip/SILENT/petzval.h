#ifndef PETZVAL_H
#define PETZVAL_H

#include <QDialog>

namespace Ui {
class Petzval;
}

class Petzval : public QDialog
{
    Q_OBJECT

public:
    explicit Petzval(QWidget *parent = 0);
    ~Petzval();

public slots:
    void seData(QString str);

private slots:
    void loadDatabase();

    void on_pushButton_3_clicked();

    void on_pushButton_clicked();

    void on_pushButton_4_clicked();

    void on_pushButton_5_clicked();

private:
    Ui::Petzval *ui;


};

#endif // PETZVAL_H
