/********************************************************************************
** Form generated from reading UI file 'czernyturner.ui'
**
** Created by: Qt User Interface Compiler version 5.8.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CZERNYTURNER_H
#define UI_CZERNYTURNER_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QDialog>
#include <QtWidgets/QDoubleSpinBox>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QSpinBox>
#include <QtWidgets/QVBoxLayout>

QT_BEGIN_NAMESPACE

class Ui_CzernyTurner
{
public:
    QGridLayout *gridLayout;
    QVBoxLayout *verticalLayout;
    QHBoxLayout *horizontalLayout;
    QLabel *label;
    QDoubleSpinBox *doubleSpinBox;
    QHBoxLayout *horizontalLayout_2;
    QLabel *label_4;
    QDoubleSpinBox *doubleSpinBox_2;
    QHBoxLayout *horizontalLayout_13;
    QLabel *label_12;
    QDoubleSpinBox *doubleSpinBox_10;
    QHBoxLayout *horizontalLayout_3;
    QLabel *label_5;
    QDoubleSpinBox *doubleSpinBox_3;
    QHBoxLayout *horizontalLayout_16;
    QLabel *label_15;
    QDoubleSpinBox *doubleSpinBox_13;
    QHBoxLayout *horizontalLayout_8;
    QLabel *label_7;
    QSpinBox *spinBox;
    QHBoxLayout *horizontalLayout_9;
    QLabel *label_8;
    QDoubleSpinBox *doubleSpinBox_7;
    QHBoxLayout *horizontalLayout_7;
    QLabel *label_6;
    QDoubleSpinBox *doubleSpinBox_6;
    QHBoxLayout *horizontalLayout_10;
    QCheckBox *checkBox;
    QCheckBox *checkBox_2;
    QHBoxLayout *horizontalLayout_14;
    QLabel *label_13;
    QDoubleSpinBox *doubleSpinBox_11;
    QHBoxLayout *horizontalLayout_4;
    QLabel *label_2;
    QDoubleSpinBox *doubleSpinBox_4;
    QHBoxLayout *horizontalLayout_5;
    QLabel *label_3;
    QDoubleSpinBox *doubleSpinBox_5;
    QHBoxLayout *horizontalLayout_15;
    QLabel *label_14;
    QDoubleSpinBox *doubleSpinBox_12;
    QHBoxLayout *horizontalLayout_11;
    QLabel *label_10;
    QDoubleSpinBox *doubleSpinBox_8;
    QHBoxLayout *horizontalLayout_12;
    QLabel *label_11;
    QDoubleSpinBox *doubleSpinBox_9;
    QHBoxLayout *horizontalLayout_19;
    QLabel *label_16;
    QDoubleSpinBox *doubleSpinBox_14;
    QHBoxLayout *horizontalLayout_18;
    QLabel *label_17;
    QDoubleSpinBox *doubleSpinBox_15;
    QHBoxLayout *horizontalLayout_20;
    QLabel *label_19;
    QDoubleSpinBox *doubleSpinBox_17;
    QHBoxLayout *horizontalLayout_17;
    QLabel *label_18;
    QDoubleSpinBox *doubleSpinBox_16;
    QSpacerItem *verticalSpacer;
    QHBoxLayout *horizontalLayout_6;
    QPushButton *pushButton;
    QPushButton *pushButton_2;
    QLabel *label_9;

    void setupUi(QDialog *CzernyTurner)
    {
        if (CzernyTurner->objectName().isEmpty())
            CzernyTurner->setObjectName(QStringLiteral("CzernyTurner"));
        CzernyTurner->resize(1080, 696);
        gridLayout = new QGridLayout(CzernyTurner);
        gridLayout->setObjectName(QStringLiteral("gridLayout"));
        verticalLayout = new QVBoxLayout();
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        label = new QLabel(CzernyTurner);
        label->setObjectName(QStringLiteral("label"));

        horizontalLayout->addWidget(label);

        doubleSpinBox = new QDoubleSpinBox(CzernyTurner);
        doubleSpinBox->setObjectName(QStringLiteral("doubleSpinBox"));
        doubleSpinBox->setMaximum(9999.99);

        horizontalLayout->addWidget(doubleSpinBox);


        verticalLayout->addLayout(horizontalLayout);

        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setObjectName(QStringLiteral("horizontalLayout_2"));
        label_4 = new QLabel(CzernyTurner);
        label_4->setObjectName(QStringLiteral("label_4"));

        horizontalLayout_2->addWidget(label_4);

        doubleSpinBox_2 = new QDoubleSpinBox(CzernyTurner);
        doubleSpinBox_2->setObjectName(QStringLiteral("doubleSpinBox_2"));
        doubleSpinBox_2->setMaximum(9999.99);

        horizontalLayout_2->addWidget(doubleSpinBox_2);


        verticalLayout->addLayout(horizontalLayout_2);

        horizontalLayout_13 = new QHBoxLayout();
        horizontalLayout_13->setObjectName(QStringLiteral("horizontalLayout_13"));
        label_12 = new QLabel(CzernyTurner);
        label_12->setObjectName(QStringLiteral("label_12"));

        horizontalLayout_13->addWidget(label_12);

        doubleSpinBox_10 = new QDoubleSpinBox(CzernyTurner);
        doubleSpinBox_10->setObjectName(QStringLiteral("doubleSpinBox_10"));

        horizontalLayout_13->addWidget(doubleSpinBox_10);


        verticalLayout->addLayout(horizontalLayout_13);

        horizontalLayout_3 = new QHBoxLayout();
        horizontalLayout_3->setObjectName(QStringLiteral("horizontalLayout_3"));
        label_5 = new QLabel(CzernyTurner);
        label_5->setObjectName(QStringLiteral("label_5"));

        horizontalLayout_3->addWidget(label_5);

        doubleSpinBox_3 = new QDoubleSpinBox(CzernyTurner);
        doubleSpinBox_3->setObjectName(QStringLiteral("doubleSpinBox_3"));
        doubleSpinBox_3->setMaximum(999.99);

        horizontalLayout_3->addWidget(doubleSpinBox_3);


        verticalLayout->addLayout(horizontalLayout_3);

        horizontalLayout_16 = new QHBoxLayout();
        horizontalLayout_16->setObjectName(QStringLiteral("horizontalLayout_16"));
        label_15 = new QLabel(CzernyTurner);
        label_15->setObjectName(QStringLiteral("label_15"));

        horizontalLayout_16->addWidget(label_15);

        doubleSpinBox_13 = new QDoubleSpinBox(CzernyTurner);
        doubleSpinBox_13->setObjectName(QStringLiteral("doubleSpinBox_13"));
        doubleSpinBox_13->setMaximum(999.99);

        horizontalLayout_16->addWidget(doubleSpinBox_13);


        verticalLayout->addLayout(horizontalLayout_16);

        horizontalLayout_8 = new QHBoxLayout();
        horizontalLayout_8->setObjectName(QStringLiteral("horizontalLayout_8"));
        label_7 = new QLabel(CzernyTurner);
        label_7->setObjectName(QStringLiteral("label_7"));

        horizontalLayout_8->addWidget(label_7);

        spinBox = new QSpinBox(CzernyTurner);
        spinBox->setObjectName(QStringLiteral("spinBox"));

        horizontalLayout_8->addWidget(spinBox);


        verticalLayout->addLayout(horizontalLayout_8);

        horizontalLayout_9 = new QHBoxLayout();
        horizontalLayout_9->setObjectName(QStringLiteral("horizontalLayout_9"));
        label_8 = new QLabel(CzernyTurner);
        label_8->setObjectName(QStringLiteral("label_8"));

        horizontalLayout_9->addWidget(label_8);

        doubleSpinBox_7 = new QDoubleSpinBox(CzernyTurner);
        doubleSpinBox_7->setObjectName(QStringLiteral("doubleSpinBox_7"));
        doubleSpinBox_7->setMaximum(9999.99);

        horizontalLayout_9->addWidget(doubleSpinBox_7);


        verticalLayout->addLayout(horizontalLayout_9);

        horizontalLayout_7 = new QHBoxLayout();
        horizontalLayout_7->setObjectName(QStringLiteral("horizontalLayout_7"));
        label_6 = new QLabel(CzernyTurner);
        label_6->setObjectName(QStringLiteral("label_6"));

        horizontalLayout_7->addWidget(label_6);

        doubleSpinBox_6 = new QDoubleSpinBox(CzernyTurner);
        doubleSpinBox_6->setObjectName(QStringLiteral("doubleSpinBox_6"));

        horizontalLayout_7->addWidget(doubleSpinBox_6);


        verticalLayout->addLayout(horizontalLayout_7);

        horizontalLayout_10 = new QHBoxLayout();
        horizontalLayout_10->setObjectName(QStringLiteral("horizontalLayout_10"));
        checkBox = new QCheckBox(CzernyTurner);
        checkBox->setObjectName(QStringLiteral("checkBox"));

        horizontalLayout_10->addWidget(checkBox);

        checkBox_2 = new QCheckBox(CzernyTurner);
        checkBox_2->setObjectName(QStringLiteral("checkBox_2"));

        horizontalLayout_10->addWidget(checkBox_2);


        verticalLayout->addLayout(horizontalLayout_10);

        horizontalLayout_14 = new QHBoxLayout();
        horizontalLayout_14->setObjectName(QStringLiteral("horizontalLayout_14"));
        label_13 = new QLabel(CzernyTurner);
        label_13->setObjectName(QStringLiteral("label_13"));

        horizontalLayout_14->addWidget(label_13);

        doubleSpinBox_11 = new QDoubleSpinBox(CzernyTurner);
        doubleSpinBox_11->setObjectName(QStringLiteral("doubleSpinBox_11"));
        doubleSpinBox_11->setMaximum(9999.99);

        horizontalLayout_14->addWidget(doubleSpinBox_11);


        verticalLayout->addLayout(horizontalLayout_14);

        horizontalLayout_4 = new QHBoxLayout();
        horizontalLayout_4->setObjectName(QStringLiteral("horizontalLayout_4"));
        label_2 = new QLabel(CzernyTurner);
        label_2->setObjectName(QStringLiteral("label_2"));

        horizontalLayout_4->addWidget(label_2);

        doubleSpinBox_4 = new QDoubleSpinBox(CzernyTurner);
        doubleSpinBox_4->setObjectName(QStringLiteral("doubleSpinBox_4"));
        doubleSpinBox_4->setEnabled(false);

        horizontalLayout_4->addWidget(doubleSpinBox_4);


        verticalLayout->addLayout(horizontalLayout_4);

        horizontalLayout_5 = new QHBoxLayout();
        horizontalLayout_5->setObjectName(QStringLiteral("horizontalLayout_5"));
        label_3 = new QLabel(CzernyTurner);
        label_3->setObjectName(QStringLiteral("label_3"));

        horizontalLayout_5->addWidget(label_3);

        doubleSpinBox_5 = new QDoubleSpinBox(CzernyTurner);
        doubleSpinBox_5->setObjectName(QStringLiteral("doubleSpinBox_5"));
        doubleSpinBox_5->setEnabled(false);

        horizontalLayout_5->addWidget(doubleSpinBox_5);


        verticalLayout->addLayout(horizontalLayout_5);

        horizontalLayout_15 = new QHBoxLayout();
        horizontalLayout_15->setObjectName(QStringLiteral("horizontalLayout_15"));
        label_14 = new QLabel(CzernyTurner);
        label_14->setObjectName(QStringLiteral("label_14"));

        horizontalLayout_15->addWidget(label_14);

        doubleSpinBox_12 = new QDoubleSpinBox(CzernyTurner);
        doubleSpinBox_12->setObjectName(QStringLiteral("doubleSpinBox_12"));
        doubleSpinBox_12->setEnabled(false);
        doubleSpinBox_12->setBaseSize(QSize(0, 0));
        doubleSpinBox_12->setMinimum(-1e+7);
        doubleSpinBox_12->setMaximum(1e+6);

        horizontalLayout_15->addWidget(doubleSpinBox_12);


        verticalLayout->addLayout(horizontalLayout_15);

        horizontalLayout_11 = new QHBoxLayout();
        horizontalLayout_11->setObjectName(QStringLiteral("horizontalLayout_11"));
        label_10 = new QLabel(CzernyTurner);
        label_10->setObjectName(QStringLiteral("label_10"));

        horizontalLayout_11->addWidget(label_10);

        doubleSpinBox_8 = new QDoubleSpinBox(CzernyTurner);
        doubleSpinBox_8->setObjectName(QStringLiteral("doubleSpinBox_8"));
        doubleSpinBox_8->setEnabled(false);

        horizontalLayout_11->addWidget(doubleSpinBox_8);


        verticalLayout->addLayout(horizontalLayout_11);

        horizontalLayout_12 = new QHBoxLayout();
        horizontalLayout_12->setObjectName(QStringLiteral("horizontalLayout_12"));
        label_11 = new QLabel(CzernyTurner);
        label_11->setObjectName(QStringLiteral("label_11"));

        horizontalLayout_12->addWidget(label_11);

        doubleSpinBox_9 = new QDoubleSpinBox(CzernyTurner);
        doubleSpinBox_9->setObjectName(QStringLiteral("doubleSpinBox_9"));
        doubleSpinBox_9->setEnabled(false);

        horizontalLayout_12->addWidget(doubleSpinBox_9);


        verticalLayout->addLayout(horizontalLayout_12);

        horizontalLayout_19 = new QHBoxLayout();
        horizontalLayout_19->setObjectName(QStringLiteral("horizontalLayout_19"));
        label_16 = new QLabel(CzernyTurner);
        label_16->setObjectName(QStringLiteral("label_16"));

        horizontalLayout_19->addWidget(label_16);

        doubleSpinBox_14 = new QDoubleSpinBox(CzernyTurner);
        doubleSpinBox_14->setObjectName(QStringLiteral("doubleSpinBox_14"));
        doubleSpinBox_14->setEnabled(false);
        doubleSpinBox_14->setMaximum(9999.99);

        horizontalLayout_19->addWidget(doubleSpinBox_14);


        verticalLayout->addLayout(horizontalLayout_19);

        horizontalLayout_18 = new QHBoxLayout();
        horizontalLayout_18->setObjectName(QStringLiteral("horizontalLayout_18"));
        label_17 = new QLabel(CzernyTurner);
        label_17->setObjectName(QStringLiteral("label_17"));

        horizontalLayout_18->addWidget(label_17);

        doubleSpinBox_15 = new QDoubleSpinBox(CzernyTurner);
        doubleSpinBox_15->setObjectName(QStringLiteral("doubleSpinBox_15"));
        doubleSpinBox_15->setEnabled(false);
        doubleSpinBox_15->setMaximum(9999.99);

        horizontalLayout_18->addWidget(doubleSpinBox_15);


        verticalLayout->addLayout(horizontalLayout_18);

        horizontalLayout_20 = new QHBoxLayout();
        horizontalLayout_20->setObjectName(QStringLiteral("horizontalLayout_20"));
        label_19 = new QLabel(CzernyTurner);
        label_19->setObjectName(QStringLiteral("label_19"));

        horizontalLayout_20->addWidget(label_19);

        doubleSpinBox_17 = new QDoubleSpinBox(CzernyTurner);
        doubleSpinBox_17->setObjectName(QStringLiteral("doubleSpinBox_17"));
        doubleSpinBox_17->setEnabled(false);
        doubleSpinBox_17->setMaximum(9999.99);

        horizontalLayout_20->addWidget(doubleSpinBox_17);


        verticalLayout->addLayout(horizontalLayout_20);

        horizontalLayout_17 = new QHBoxLayout();
        horizontalLayout_17->setObjectName(QStringLiteral("horizontalLayout_17"));
        label_18 = new QLabel(CzernyTurner);
        label_18->setObjectName(QStringLiteral("label_18"));

        horizontalLayout_17->addWidget(label_18);

        doubleSpinBox_16 = new QDoubleSpinBox(CzernyTurner);
        doubleSpinBox_16->setObjectName(QStringLiteral("doubleSpinBox_16"));
        doubleSpinBox_16->setEnabled(false);
        doubleSpinBox_16->setMaximum(9999.99);

        horizontalLayout_17->addWidget(doubleSpinBox_16);


        verticalLayout->addLayout(horizontalLayout_17);

        verticalSpacer = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout->addItem(verticalSpacer);

        horizontalLayout_6 = new QHBoxLayout();
        horizontalLayout_6->setObjectName(QStringLiteral("horizontalLayout_6"));
        pushButton = new QPushButton(CzernyTurner);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        QSizePolicy sizePolicy(QSizePolicy::Maximum, QSizePolicy::Fixed);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(pushButton->sizePolicy().hasHeightForWidth());
        pushButton->setSizePolicy(sizePolicy);

        horizontalLayout_6->addWidget(pushButton);

        pushButton_2 = new QPushButton(CzernyTurner);
        pushButton_2->setObjectName(QStringLiteral("pushButton_2"));
        sizePolicy.setHeightForWidth(pushButton_2->sizePolicy().hasHeightForWidth());
        pushButton_2->setSizePolicy(sizePolicy);

        horizontalLayout_6->addWidget(pushButton_2);


        verticalLayout->addLayout(horizontalLayout_6);


        gridLayout->addLayout(verticalLayout, 0, 0, 1, 1);

        label_9 = new QLabel(CzernyTurner);
        label_9->setObjectName(QStringLiteral("label_9"));
        label_9->setPixmap(QPixmap(QString::fromUtf8("Icons/Monochromator_vek.png")));

        gridLayout->addWidget(label_9, 0, 1, 1, 1);


        retranslateUi(CzernyTurner);
        QObject::connect(pushButton, SIGNAL(clicked()), CzernyTurner, SLOT(close()));

        QMetaObject::connectSlotsByName(CzernyTurner);
    } // setupUi

    void retranslateUi(QDialog *CzernyTurner)
    {
        CzernyTurner->setWindowTitle(QApplication::translate("CzernyTurner", "Dialog", Q_NULLPTR));
        label->setText(QApplication::translate("CzernyTurner", "Focal Length Collimator [mm]:", Q_NULLPTR));
        label_4->setText(QApplication::translate("CzernyTurner", "Focal Length Camera [mm]:", Q_NULLPTR));
        label_12->setText(QApplication::translate("CzernyTurner", "Diameter Collimator [mm]:", Q_NULLPTR));
        label_5->setText(QApplication::translate("CzernyTurner", "Wavelength [nm]:", Q_NULLPTR));
        label_15->setText(QApplication::translate("CzernyTurner", "Bandwidth [nm]:", Q_NULLPTR));
        label_7->setText(QApplication::translate("CzernyTurner", "Diffraction Order:", Q_NULLPTR));
        label_8->setText(QApplication::translate("CzernyTurner", "Grating Frequency [l/mm]:", Q_NULLPTR));
        label_6->setText(QApplication::translate("CzernyTurner", "Total Angle:", Q_NULLPTR));
        checkBox->setText(QApplication::translate("CzernyTurner", "Flat-Field", Q_NULLPTR));
        checkBox_2->setText(QApplication::translate("CzernyTurner", "Coma-Correction", Q_NULLPTR));
        label_13->setText(QApplication::translate("CzernyTurner", "Grating - Mirror [mm]:", Q_NULLPTR));
        label_2->setText(QApplication::translate("CzernyTurner", "Theta 1:", Q_NULLPTR));
        label_3->setText(QApplication::translate("CzernyTurner", "Theta 2:", Q_NULLPTR));
        label_14->setText(QApplication::translate("CzernyTurner", "Radius of Curvature:", Q_NULLPTR));
        label_10->setText(QApplication::translate("CzernyTurner", "Alpha:", Q_NULLPTR));
        label_11->setText(QApplication::translate("CzernyTurner", "Beta:", Q_NULLPTR));
        label_16->setText(QApplication::translate("CzernyTurner", "Transverse Astigmatism [um]:", Q_NULLPTR));
        label_17->setText(QApplication::translate("CzernyTurner", "Transverse Coma upper [um]:", Q_NULLPTR));
        label_19->setText(QApplication::translate("CzernyTurner", "Transverse Coma low [um]:", Q_NULLPTR));
        label_18->setText(QApplication::translate("CzernyTurner", "Transverse Spherical [um]:", Q_NULLPTR));
        pushButton->setText(QApplication::translate("CzernyTurner", "Close", Q_NULLPTR));
        pushButton_2->setText(QApplication::translate("CzernyTurner", "Calculate", Q_NULLPTR));
        label_9->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class CzernyTurner: public Ui_CzernyTurner {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CZERNYTURNER_H
