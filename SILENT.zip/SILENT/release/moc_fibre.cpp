/****************************************************************************
** Meta object code from reading C++ file 'fibre.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.9.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../fibre.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'fibre.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.9.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_Fibre_t {
    QByteArrayData data[32];
    char stringdata0[620];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_Fibre_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_Fibre_t qt_meta_stringdata_Fibre = {
    {
QT_MOC_LITERAL(0, 0, 5), // "Fibre"
QT_MOC_LITERAL(1, 6, 11), // "reflections"
QT_MOC_LITERAL(2, 18, 0), // ""
QT_MOC_LITERAL(3, 19, 29), // "on_doubleSpinBox_valueChanged"
QT_MOC_LITERAL(4, 49, 31), // "on_doubleSpinBox_2_valueChanged"
QT_MOC_LITERAL(5, 81, 31), // "on_doubleSpinBox_4_valueChanged"
QT_MOC_LITERAL(6, 113, 31), // "on_doubleSpinBox_5_valueChanged"
QT_MOC_LITERAL(7, 145, 31), // "on_doubleSpinBox_6_valueChanged"
QT_MOC_LITERAL(8, 177, 23), // "on_pushButton_2_clicked"
QT_MOC_LITERAL(9, 201, 31), // "on_doubleSpinBox_7_valueChanged"
QT_MOC_LITERAL(10, 233, 3), // "OPL"
QT_MOC_LITERAL(11, 237, 12), // "transmission"
QT_MOC_LITERAL(12, 250, 7), // "bending"
QT_MOC_LITERAL(13, 258, 7), // "IndexCo"
QT_MOC_LITERAL(14, 266, 9), // "naperture"
QT_MOC_LITERAL(15, 276, 10), // "evanescent"
QT_MOC_LITERAL(16, 287, 6), // "nmodes"
QT_MOC_LITERAL(17, 294, 5), // "modes"
QT_MOC_LITERAL(18, 300, 6), // "mnoise"
QT_MOC_LITERAL(19, 307, 19), // "on_checkBox_clicked"
QT_MOC_LITERAL(20, 327, 21), // "on_checkBox_2_clicked"
QT_MOC_LITERAL(21, 349, 21), // "on_checkBox_3_clicked"
QT_MOC_LITERAL(22, 371, 21), // "on_checkBox_4_clicked"
QT_MOC_LITERAL(23, 393, 21), // "on_checkBox_5_clicked"
QT_MOC_LITERAL(24, 415, 21), // "on_checkBox_6_clicked"
QT_MOC_LITERAL(25, 437, 31), // "on_comboBox_currentIndexChanged"
QT_MOC_LITERAL(26, 469, 21), // "on_checkBox_7_clicked"
QT_MOC_LITERAL(27, 491, 31), // "on_doubleSpinBox_9_valueChanged"
QT_MOC_LITERAL(28, 523, 23), // "on_spinBox_valueChanged"
QT_MOC_LITERAL(29, 547, 25), // "on_spinBox_2_valueChanged"
QT_MOC_LITERAL(30, 573, 23), // "on_pushButton_3_clicked"
QT_MOC_LITERAL(31, 597, 22) // "on_checkBox_10_clicked"

    },
    "Fibre\0reflections\0\0on_doubleSpinBox_valueChanged\0"
    "on_doubleSpinBox_2_valueChanged\0"
    "on_doubleSpinBox_4_valueChanged\0"
    "on_doubleSpinBox_5_valueChanged\0"
    "on_doubleSpinBox_6_valueChanged\0"
    "on_pushButton_2_clicked\0"
    "on_doubleSpinBox_7_valueChanged\0OPL\0"
    "transmission\0bending\0IndexCo\0naperture\0"
    "evanescent\0nmodes\0modes\0mnoise\0"
    "on_checkBox_clicked\0on_checkBox_2_clicked\0"
    "on_checkBox_3_clicked\0on_checkBox_4_clicked\0"
    "on_checkBox_5_clicked\0on_checkBox_6_clicked\0"
    "on_comboBox_currentIndexChanged\0"
    "on_checkBox_7_clicked\0"
    "on_doubleSpinBox_9_valueChanged\0"
    "on_spinBox_valueChanged\0"
    "on_spinBox_2_valueChanged\0"
    "on_pushButton_3_clicked\0on_checkBox_10_clicked"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_Fibre[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      30,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,  164,    2, 0x08 /* Private */,
       3,    0,  165,    2, 0x08 /* Private */,
       4,    0,  166,    2, 0x08 /* Private */,
       5,    0,  167,    2, 0x08 /* Private */,
       6,    0,  168,    2, 0x08 /* Private */,
       7,    0,  169,    2, 0x08 /* Private */,
       8,    0,  170,    2, 0x08 /* Private */,
       9,    0,  171,    2, 0x08 /* Private */,
      10,    0,  172,    2, 0x08 /* Private */,
      11,    0,  173,    2, 0x08 /* Private */,
      12,    0,  174,    2, 0x08 /* Private */,
      13,    0,  175,    2, 0x08 /* Private */,
      14,    0,  176,    2, 0x08 /* Private */,
      15,    0,  177,    2, 0x08 /* Private */,
      16,    0,  178,    2, 0x08 /* Private */,
      17,    0,  179,    2, 0x08 /* Private */,
      18,    0,  180,    2, 0x08 /* Private */,
      19,    0,  181,    2, 0x08 /* Private */,
      20,    0,  182,    2, 0x08 /* Private */,
      21,    0,  183,    2, 0x08 /* Private */,
      22,    0,  184,    2, 0x08 /* Private */,
      23,    0,  185,    2, 0x08 /* Private */,
      24,    0,  186,    2, 0x08 /* Private */,
      25,    0,  187,    2, 0x08 /* Private */,
      26,    0,  188,    2, 0x08 /* Private */,
      27,    0,  189,    2, 0x08 /* Private */,
      28,    0,  190,    2, 0x08 /* Private */,
      29,    0,  191,    2, 0x08 /* Private */,
      30,    0,  192,    2, 0x08 /* Private */,
      31,    0,  193,    2, 0x08 /* Private */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void Fibre::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Fibre *_t = static_cast<Fibre *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->reflections(); break;
        case 1: _t->on_doubleSpinBox_valueChanged(); break;
        case 2: _t->on_doubleSpinBox_2_valueChanged(); break;
        case 3: _t->on_doubleSpinBox_4_valueChanged(); break;
        case 4: _t->on_doubleSpinBox_5_valueChanged(); break;
        case 5: _t->on_doubleSpinBox_6_valueChanged(); break;
        case 6: _t->on_pushButton_2_clicked(); break;
        case 7: _t->on_doubleSpinBox_7_valueChanged(); break;
        case 8: _t->OPL(); break;
        case 9: _t->transmission(); break;
        case 10: _t->bending(); break;
        case 11: _t->IndexCo(); break;
        case 12: _t->naperture(); break;
        case 13: _t->evanescent(); break;
        case 14: _t->nmodes(); break;
        case 15: _t->modes(); break;
        case 16: _t->mnoise(); break;
        case 17: _t->on_checkBox_clicked(); break;
        case 18: _t->on_checkBox_2_clicked(); break;
        case 19: _t->on_checkBox_3_clicked(); break;
        case 20: _t->on_checkBox_4_clicked(); break;
        case 21: _t->on_checkBox_5_clicked(); break;
        case 22: _t->on_checkBox_6_clicked(); break;
        case 23: _t->on_comboBox_currentIndexChanged(); break;
        case 24: _t->on_checkBox_7_clicked(); break;
        case 25: _t->on_doubleSpinBox_9_valueChanged(); break;
        case 26: _t->on_spinBox_valueChanged(); break;
        case 27: _t->on_spinBox_2_valueChanged(); break;
        case 28: _t->on_pushButton_3_clicked(); break;
        case 29: _t->on_checkBox_10_clicked(); break;
        default: ;
        }
    }
    Q_UNUSED(_a);
}

const QMetaObject Fibre::staticMetaObject = {
    { &QDialog::staticMetaObject, qt_meta_stringdata_Fibre.data,
      qt_meta_data_Fibre,  qt_static_metacall, nullptr, nullptr}
};


const QMetaObject *Fibre::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *Fibre::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_Fibre.stringdata0))
        return static_cast<void*>(const_cast< Fibre*>(this));
    return QDialog::qt_metacast(_clname);
}

int Fibre::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QDialog::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 30)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 30;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 30)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 30;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
